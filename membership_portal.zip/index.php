<?php
/**
 * Membership Portal.
 * Public Homepage.
 *
 * Displays the main landing page for the membership portal.
 * Redirects to setup wizard if no admin exists.
 * For logged‑in admins, shows the admin navbar with avatar dropdown.
 * For visitors, shows registration links and mission statement.
 *
 * @package    MembershipPortal.
 * @author     Heshan Shibry <heshan.shib@gmail.com>
 * @copyright  2026 HESHAN SHIBRY.
 * @license    Proprietary - All rights reserved.
 * @version    1.0.0.
 */
require_once 'includes/functions.php';
require_once 'includes/auth.php';
$pdo = getDB();
$baseUrl = BASE_URL; // defined in config/database.php

if (!hasAdmin($pdo)) {
    header('Location: ' . BASE_URL . 'setup');
    exit;
}

// For logged-in admin, fetch profile picture for avatar
$avatarPic = null;
if (isset($_SESSION['user_id'])) {
    $stmt = $pdo->prepare("SELECT profile_pic FROM admins WHERE id = ?");
    $stmt->execute([$_SESSION['user_id']]);
    $avatarPic = $stmt->fetchColumn();
}

// Variables required by shared navbar
$isLoggedIn = isset($_SESSION['user_id']);
$fullName = $_SESSION['full_name'] ?? '';
$userId = $_SESSION['user_id'] ?? 0;
$userRole = $_SESSION['role'] ?? '';
$isSuperAdmin = ($_SESSION['is_super_admin'] ?? 0) == 1;
$hasGenerateReports = function_exists('hasPermission') ? hasPermission('generate_reports') : false;
$hasRestoreUsers = function_exists('hasPermission') ? hasPermission('restore_users') : false;
$hideAdminLinks = true;
$currentPage = 'home';
?>
<?php
// Set page title and optional custom styles
$page_title = 'Membership Portal';
$page_styles = '
    <style>
    body { display: flex; flex-direction: column; min-height: 100vh; }
    main { flex: 1 0 auto; }
    footer { flex-shrink: 0; }
    /* Fix vertical alignment of user avatar in navbar */
    .navbar .dropdown-toggle {
          display: flex !important;
          align-items: center !important;
          gap: 3px !important;
          line-height: 1 !important;
      }
      .navbar .dropdown-toggle img,
      .navbar .dropdown-toggle i {
          display: inline-block;
          vertical-align: middle;
      }
    </style>
';

// Include the global header
include 'includes/header.php';
?>

    <!-- Shared navbar (public) -->
    <?php
      $currentPage = 'home'; // or any value not matching the public links (they won't highlight)
      include 'includes/navbar.php';
    ?>

    <main class="container my-5">
        <div class="card shadow-sm border-0 rounded-4">
            <div class="card-body p-5 text-center">
                <h1 class="display-4 fw-bold text-dark">Join the Movement for a Better Sri Lanka</h1>
                <p class="lead mt-3">Empower communities, uphold nonviolence, and shape the future.</p>
                <?php if (!isset($_SESSION['user_id'])): ?>
                    <div class="mt-4">
                        <a href="<?= $baseUrl ?>register" class="btn btn-warning btn-lg">Become a Member →</a>
                    </div>
                <?php endif; ?>
                <div class="row mt-5 g-4">
                    <div class="col-md-6">
                        <h3>📢 OUR MISSION</h3>
                        <p>Increase global impact of nonviolence, human rights, and grassroots democracy.</p>
                    </div>
                    <div class="col-md-6">
                        <h3>📰 LATEST NEWS</h3>
                        <p>New project to support women & children affected by conflict — join our relief efforts.</p>
                    </div>
                </div>
            </div>
        </div>
    </main>

    <!-- footer (public) includes report issue modal -->
    <?php include 'includes/footer_public.php'; ?>
