<?php
/**
 * Membership Portal – Registration Form
 *
 * - All fields required (profile picture, document, gender)
 * - Geographic cascade: Province (trilingual) → District → City (trilingual)
 * - Phone number with country code + local digits
 * - Email live validation + server‑side
 * - Self‑learning political mapping (city‑level via geo_political_mapping)
 * - Master address verification (street‑level) with fuzzy matching (Levenshtein)
 *   → If street+city matches a verified master address → auto‑approve
 *   → Else create a pending master address for admin review
 * - Immediate email (Brevo API) with fallback queue
 * - All timestamps stored in UTC
 *
 * @package    MembershipPortal.
 * @author     Heshan Shibry <heshan.shib@gmail.com>
 * @copyright  2026 HESHAN SHIBRY.
 * @license    Proprietary - All rights reserved.
 * @version    1.0.0.
 */
session_start();
require_once 'includes/functions.php';
$pdo = getDB();

// Navbar variables
$isLoggedIn = isset($_SESSION['user_id']);
$fullName = $_SESSION['full_name'] ?? '';
$userId = $_SESSION['user_id'] ?? 0;
$userRole = $_SESSION['role'] ?? '';
$isSuperAdmin = ($_SESSION['is_super_admin'] ?? 0) == 1;
$hasGenerateReports = function_exists('hasPermission') ? hasPermission('generate_reports') : false;
$hasRestoreUsers = function_exists('hasPermission') ? hasPermission('restore_users') : false;
$baseUrl = BASE_URL;

// If no admin exists, redirect to setup
if (!hasAdmin($pdo)) {
    header('Location: ' . BASE_URL . 'setup');
    exit;
}

$error = '';
$success = '';

// Helper function for trilingual province names (same as used for districts/cities)
function formatTrilingual($name_en, $name_si, $name_ta) {
    $text = $name_en;
    if (!empty($name_si) && !empty($name_ta)) {
        $text .= " ($name_si / $name_ta)";
    } elseif (!empty($name_si)) {
        $text .= " ($name_si)";
    } elseif (!empty($name_ta)) {
        $text .= " ($name_ta)";
    }
    return htmlspecialchars($text);
}

// Fetch provinces with all three language columns
$provinces = $pdo->query("SELECT id, name_en, name_si, name_ta FROM provinces ORDER BY name_en")->fetchAll();

// Process registration form
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Sanitize inputs
    $full_name = sanitize($_POST['full_name']);
    $email = sanitize($_POST['email']);
    $province_id = isset($_POST['province']) ? (int)$_POST['province'] : 0;
    $district_id = isset($_POST['district']) ? (int)$_POST['district'] : 0;
    $city_id     = isset($_POST['city']) ? (int)$_POST['city'] : 0;

    $phone_code = sanitize($_POST['phone_code']);
    $phone_number = sanitize($_POST['phone_number']);
    $phone = $phone_code . ' ' . $phone_number;
    $address = sanitize($_POST['address']);

    // ----- Gender handling -----
    $gender = sanitize($_POST['gender'] ?? '');
    $gender_custom = sanitize($_POST['gender_custom'] ?? '');
    $allowedGenders = ['Male', 'Female', 'Prefer not to say', 'Other'];
    if (!in_array($gender, $allowedGenders)) {
        $gender = null;
    }
    if ($gender !== 'Other') {
        $gender_custom = null;
    } else {
        $gender_custom = trim($gender_custom);
        if (strlen($gender_custom) > 50) {
            $gender_custom = substr($gender_custom, 0, 50);
        }
        // If the custom text is empty, set an error
        if (empty($gender_custom)) {
            $error = "Please specify your gender when selecting 'Other'.";
        }
    }
    // --------------------------

    // Get English names for the selected IDs (stored for simple display)
    $province_name = '';
    $district_name = '';
    $city_name = '';
    if ($province_id) {
        $stmt = $pdo->prepare("SELECT name_en FROM provinces WHERE id = ?");
        $stmt->execute([$province_id]);
        $province_name = $stmt->fetchColumn();
    }
    if ($district_id) {
        $stmt = $pdo->prepare("SELECT name_en FROM districts WHERE id = ?");
        $stmt->execute([$district_id]);
        $district_name = $stmt->fetchColumn();
    }
    if ($city_id) {
        $stmt = $pdo->prepare("SELECT name_en FROM cities WHERE id = ?");
        $stmt->execute([$city_id]);
        $city_name = $stmt->fetchColumn();
    }

    // --- Master address matching with fuzzy similarity (auto‑approval) ---
    $master_address_id = null;
    $verification_status = 'pending_verification';
    $polling_division = 'Pending';
    $gn_division = 'Pending';
    $assigned_booth = 'Pending';

    if (!empty($address) && $city_id) {
        $normalized_input = normalizeAddress($address); // from functions.php

        // Try fuzzy match against verified master addresses (90% similarity)
        $bestMatch = findBestMatchingAddress($pdo, $normalized_input, $city_id, 90);

        if ($bestMatch) {
            // Auto‑approve: link to existing verified master address
            $master_address_id = $bestMatch['id'];
            $verification_status = 'auto_approved';
            $polling_division = $bestMatch['polling_division'];
            $gn_division = $bestMatch['gn_division'];
            $assigned_booth = $bestMatch['assigned_polling_booth'];
        } else {
            // No match – create a new pending master address
            // Fallback to city‑level political mapping from geo_political_mapping
            $stmtMap = $pdo->prepare("SELECT polling_division_name, gn_division_default FROM geo_political_mapping WHERE city_id = ?");
            $stmtMap->execute([$city_id]);
            $map = $stmtMap->fetch();
            if ($map) {
                $polling_division = $map['polling_division_name'];
                $gn_division = $map['gn_division_default'] ?? 'Pending';
            }

            $stmtIns = $pdo->prepare("
                INSERT INTO master_addresses (street_address, city_id, normalized_street, polling_division, gn_division, assigned_polling_booth, status)
                VALUES (?, ?, ?, ?, ?, ?, 'pending')
            ");
            $stmtIns->execute([$address, $city_id, $normalized_input, $polling_division, $gn_division, $assigned_booth]);
            $master_address_id = $pdo->lastInsertId();
            $verification_status = 'pending_verification';
        }
    } else {
        // If address is empty (should not happen because field is required), fallback to city‑level mapping
        $stmt = $pdo->prepare("SELECT polling_division_name, gn_division_default FROM geo_political_mapping WHERE city_id = ?");
        $stmt->execute([$city_id]);
        $mapping = $stmt->fetch();
        if ($mapping) {
            $polling_division = $mapping['polling_division_name'];
            $gn_division = $mapping['gn_division_default'] ?? 'Pending';
        }
    }

    // --- Validation ---
    if (empty($error)) { // only proceed if no error from gender custom
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $error = "Invalid email format. Please enter a valid email address.";
        } elseif (empty($full_name)) {
            $error = "Full name is required.";
        } elseif (empty($province_id) || empty($district_id) || empty($city_id)) {
            $error = "Province, District, and City/Town are required.";
        } elseif (empty($phone_code) || empty($phone_number)) {
            $error = "Phone number (country code and local number) is required.";
        } elseif (empty($address)) {
            $error = "Address is required.";
        } elseif (empty($gender)) {
            $error = "Please select a gender.";
        } else {
            $errors = [];

            // Profile picture validation
            if (!isset($_FILES['profile_pic']) || $_FILES['profile_pic']['error'] !== UPLOAD_ERR_OK) {
                $errors[] = "Profile picture is required. Please upload a JPG or PNG image (max 2MB).";
            } else {
                $pic = $_FILES['profile_pic'];
                $pic_ext = strtolower(pathinfo($pic['name'], PATHINFO_EXTENSION));
                if (!in_array($pic_ext, ['jpg', 'jpeg', 'png'])) {
                    $errors[] = "Profile picture must be a JPG or PNG image.";
                }
                if ($pic['size'] > 2 * 1024 * 1024) {
                    $errors[] = "Profile picture exceeds 2MB limit.";
                    logError("Profile picture too large: {$pic['size']} bytes", 'user_upload');
                }
            }

            // Document validation
            if (!isset($_FILES['document']) || $_FILES['document']['error'] !== UPLOAD_ERR_OK) {
                $errors[] = "Document (ID card / proof) is required. Please upload a JPG, PNG or PDF (max 5MB).";
            } else {
                $doc = $_FILES['document'];
                $doc_ext = strtolower(pathinfo($doc['name'], PATHINFO_EXTENSION));
                if (!in_array($doc_ext, ['jpg', 'jpeg', 'png', 'pdf'])) {
                    $errors[] = "Document must be a JPG, PNG or PDF file.";
                }
                if ($doc['size'] > 5 * 1024 * 1024) {
                    $errors[] = "Document exceeds 5MB limit.";
                    logError("Document too large: {$doc['size']} bytes", 'user_upload');
                }
            }

            if (!empty($errors)) {
                $error = implode('<br>', $errors);
            } else {
                // Check email uniqueness
                $stmt = $pdo->prepare("SELECT id FROM members WHERE email = ?");
                $stmt->execute([$email]);
                if ($stmt->fetch()) {
                    $error = "Email already registered.";
                    logError("Registration failed: Email already exists - $email", 'member_reg');
                } else {
                    $member_id = generateMemberId($pdo);
                    $utcNow = utcNow();

                    // Insert member with all columns (including gender)
                    $stmt = $pdo->prepare("INSERT INTO members
                        (member_id, full_name, email, province, district, city, city_id,
                         phone, address, created_at, polling_division, gn_division, assigned_polling_booth,
                         master_address_id, verification_status, gender, gender_custom)
                        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
                    if ($stmt->execute([
                        $member_id, $full_name, $email,
                        $province_name, $district_name, $city_name, $city_id,
                        $phone, $address, $utcNow,
                        $polling_division, $gn_division, $assigned_booth,
                        $master_address_id, $verification_status,
                        $gender, $gender_custom
                    ])) {
                        $memberId = $pdo->lastInsertId();

                        // Upload profile picture
                        $uploadPath = uploadFile('profile_pic', 'uploads/', ['jpg','jpeg','png'], 2*1024*1024);
                        if ($uploadPath) {
                            $pdo->prepare("UPDATE members SET profile_pic = ? WHERE id = ?")->execute([$uploadPath, $memberId]);
                        } else {
                            $error = "Profile picture upload failed. Please try again later.";
                            $pdo->prepare("DELETE FROM members WHERE id = ?")->execute([$memberId]);
                        }

                        // Upload document
                        if (empty($error)) {
                            $docPath = uploadFile('document', 'uploads/', ['jpg','jpeg','png','pdf'], 5*1024*1024);
                            if ($docPath) {
                                $docType = sanitize($_POST['doc_type'] ?? 'general');
                                $stmtDoc = $pdo->prepare("INSERT INTO documents (member_id, document_name, document_path, document_type, uploaded_at) VALUES (?, ?, ?, ?, ?)");
                                $stmtDoc->execute([$memberId, $_FILES['document']['name'], $docPath, $docType, $utcNow]);
                            } else {
                                $error = "Document upload failed. Please try again later.";
                                $pdo->prepare("DELETE FROM members WHERE id = ?")->execute([$memberId]);
                                if (!empty($uploadPath) && file_exists($uploadPath)) unlink($uploadPath);
                            }
                        }

                        // Send confirmation email (immediate or queue)
                        if (empty($error)) {
                            $confirmSubject = "Membership Application Received – National Movement";
                            $confirmMessage = "Dear $full_name,\n\n";
                            $confirmMessage .= "Thank you for applying to join the National Movement.\n\n";
                            $confirmMessage .= "Your application has been received successfully.\n";
                            $confirmMessage .= "Your Member ID is: $member_id\n\n";
                            $confirmMessage .= "We will review your application and contact you via the phone number or email you provided.\n";
                            $confirmMessage .= "If you have any questions, please feel free to reach out to us at: +94 11 234 5678\n\n";
                            $confirmMessage .= "The membership portal is coming soon – you will be notified when it is ready.\n\n";
                            $confirmMessage .= "Thank you for your interest.\n";
                            $confirmMessage .= "National Movement Team";

                            $result = sendEmail($email, $confirmSubject, $confirmMessage, $full_name);
                            if ($result['success']) {
                                $success = "Registration successful! Your member ID is $member_id. A confirmation email has been sent.";
                            } else {
                                queueEmail($email, $confirmSubject, $confirmMessage, $full_name);
                                $success = "Registration successful! Your member ID is $member_id. A confirmation email will be sent shortly.";
                            }
                        }
                    } else {
                        $error = "Registration failed. Please try again.";
                        logError("Database insert failed for new member: $email", 'db');
                    }
                }
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registration | National Movement</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="assets/css/style.css">
    <style>
        body { display: flex; flex-direction: column; min-height: 100vh; }
        main { flex: 1 0 auto; }
        footer { flex-shrink: 0; }
        select.form-select {
          cursor: pointer
        }
        /* Truncate long text with dots (...) inside form controls */
        .form-select, .form-select option {
            text-overflow: ellipsis;
            overflow: hidden;
            white-space: nowrap;
        }
        #genderSpecifyWrapper {
            display: none;
        }
    </style>
</head>
<body class="bg-light d-flex flex-column min-vh-100">

    <?php include 'includes/navbar.php'; ?>

    <main class="container my-5">
        <div class="row justify-content-center">
            <div class="col-md-8 col-lg-7">
                <div class="card shadow-sm border-0 rounded-4">
                    <div class="card-body p-4 p-md-5">
                        <h2 class="card-title text-center mb-4">✍️ Become a Member</h2>
                        
                        <?php if ($error): ?>
                              <div class="alert alert-danger d-flex align-items-center border-0 border-start border-4 border-danger shadow-sm mb-4" role="alert">
                                  <!-- Modern Bootstrap SVG Exclamation Warning Icon -->
                                  <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="currentColor" class="bi bi-exclamation-triangle-fill me-3 flex-shrink-0" viewBox="0 0 16 16">
                                      <path d="M8.982 1.566a1.13 1.13 0 0 0-1.96 0L.165 13.233c-.457.778.091 1.767.98 1.767h13.713c.889 0 1.438-.99.98-1.767zM8 5c.535 0 .954.462.9.995l-.35 3.507a.552.552 0 0 1-1.1 0L7.1 5.995A.905.905 0 0 1 8 5m.002 6a1 1 0 1 1 0 2 1 1 0 0 1 0-2"/>
                                  </svg>
                                  <div class="small fw-semibold"><?= $error ?></div>
                              </div>
                          <?php endif; ?>

                          <?php if ($success): ?>
                              <div class="alert alert-success d-flex align-items-center alert-dismissible fade show border-0 border-start border-4 border-success shadow-sm mb-4" role="alert">
                                  <!-- Modern Bootstrap SVG Check Circle Icon -->
                                  <svg xmlns="http://www.w3.org/2000/svg" width="22" height="22" fill="currentColor" class="bi bi-check-circle-fill me-3 flex-shrink-0" viewBox="0 0 16 16">
                                      <path d="M16 8A8 8 0 1 1 0 8a8 8 0 0 1 16 0m-3.97-3.03a.75.75 0 0 0-1.08.022L7.477 9.417 5.384 7.323a.75.75 0 0 0-1.06 1.06L6.97 11.03a.75.75 0 0 0 1.079-.02l3.992-4.99a.75.75 0 0 0-.01-1.05z"/>
                                  </svg>
                                  <div class="small fw-semibold"><?= $success ?></div>
                                  <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                              </div>

                              <!-- Your Unaltered Return Home Container Elements -->
                              <div class="text-center mt-3">
                                  <a href="<?= BASE_URL ?>" class="btn btn-dark">Return Home</a>
                              </div>
                          <?php else: ?>

                            <form method="POST" enctype="multipart/form-data">
                                <div class="row">
                                    <div class="col-md-6 mb-3">
                                        <label class="form-label fw-semibold">Full Name *</label>
                                        <input type="text" name="full_name" class="form-control" required>
                                    </div>
                                    <div class="col-md-6 mb-3">
                                        <label class="form-label fw-semibold">Email *</label>
                                        <input type="email" name="email" class="form-control" required>
                                    </div>
                                </div>

                                <!-- Geographic hierarchy with trilingual province -->
                                <div class="row align-items-end g-3">
                                    <div class="col-md-4 mb-3 mb-md-0">
                                        <label class="form-label fw-semibold">Province *</label>
                                        <select id="provinceSelect" name="province" class="form-select" required>
                                            <option value="">Select Province</option>
                                            <?php foreach ($provinces as $p): ?>
                                                <option value="<?= $p['id'] ?>">
                                                    <?= formatTrilingual($p['name_en'], $p['name_si'], $p['name_ta']) ?>
                                                </option>
                                            <?php endforeach; ?>
                                        </select>
                                    </div>
                                    <div class="col-md-4 mb-3 mb-md-0">
                                        <label class="form-label fw-semibold">District *</label>
                                        <select id="districtSelect" name="district" class="form-select" disabled required>
                                            <option value="">Select...</option>
                                        </select>
                                    </div>
                                    <div class="col-md-4 mb-3 mb-md-0">
                                        <label class="form-label fw-semibold">City / Nearest Town *</label>
                                        <select id="citySelect" name="city" class="form-select" disabled required>
                                            <option value="">Select...</option>
                                        </select>
                                    </div>
                                </div>

                                <div class="col-md-6 mb-4 mt-3">
                                    <label class="form-label fw-semibold">Phone Number *</label>
                                    <div class="row g-2">
                                        <div class="col-4">
                                            <select name="phone_code" class="form-select" required>
                                                <option value="+94">+94</option>
                                                <option value="+91">+91</option>
                                                <option value="+1">+1</option>
                                                <option value="+44">+44</option>
                                                <option value="+61">+61</option>
                                                <option value="+971">+971</option>
                                            </select>
                                        </div>
                                        <div class="col-8">
                                            <input type="tel" name="phone_number" class="form-control" placeholder="712345678" pattern="[0-9]{7,10}" title="7 to 10 digits" required>
                                        </div>
                                    </div>
                                    <small class="text-muted">Select country code and enter local number (without leading zero).</small>
                                </div>
                                <div class="col-md-7 mb-3">
                                    <label class="form-label fw-semibold">Address *</label>
                                    <textarea name="address" rows="2" class="form-control" required></textarea>
                                </div>

                                <!-- Gender Field (required) -->
                                <div class="row mb-3">
                                    <div class="col-md-6">
                                        <label class="form-label fw-semibold">Gender *</label>
                                        <select id="genderSelect" name="gender" class="form-select" required>
                                            <option value="" selected>Select...</option>
                                            <option value="Male">Male</option>
                                            <option value="Female">Female</option>
                                            <option value="Prefer not to say">Prefer not to say</option>
                                            <option value="Other">Other</option>
                                        </select>
                                    </div>
                                    <div class="col-md-6" id="genderSpecifyWrapper">
                                        <label class="form-label fw-semibold">Please specify *</label>
                                        <input type="text" id="genderSpecifyInput" name="gender_custom" class="form-control" placeholder="e.g., Non-binary">
                                    </div>
                                </div>

                                <div class="col-md-6 mb-3">
                                    <label class="form-label fw-semibold">Profile Picture * (jpg/png, max 2MB)</label>
                                    <input type="file" name="profile_pic" class="form-control" accept="image/jpeg,image/png" required>
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label class="form-label fw-semibold">Upload Document * (jpg/png/pdf, max 5MB)</label>
                                    <select name="doc_type" class="form-select mb-2">
                                        <option value="id_card">ID Card</option>
                                        <option value="address_proof">Address Proof</option>
                                        <option value="other">Other</option>
                                    </select>
                                    <input type="file" name="document" class="form-control" accept=".jpg,.jpeg,.png,.pdf" required>
                                </div>
                                <button type="submit" class="btn btn-dark w-100 py-2">Register</button>
                            </form>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </main>

    <footer class="bg-dark text-white-50 text-center py-4 mt-auto">
        <p class="mb-0">National Movement – Membership Registration Form</p>
        <p class="mb-0 mt-2 small">&copy; <?= date('Y') ?> National Movement. All rights reserved.</p>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Restrict phone number to digits only
        const phoneInput = document.querySelector('input[name="phone_number"]');
        if (phoneInput) {
            phoneInput.addEventListener('input', function() {
                this.value = this.value.replace(/[^0-9]/g, '');
            });
        }

        // Email live validation
        const emailEl = document.querySelector('input[name="email"]');
        if (emailEl) {
            let fb = document.getElementById('emailFeedback');
            if (!fb) {
                fb = document.createElement('div');
                fb.id = 'emailFeedback';
                fb.className = 'invalid-feedback';
                emailEl.parentNode.appendChild(fb);
            }
            emailEl.addEventListener('input', function() {
                const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
                if (!re.test(this.value) && this.value.length > 0) {
                    this.classList.add('is-invalid');
                    fb.textContent = 'Please enter a valid email address (e.g., name@example.com).';
                } else {
                    this.classList.remove('is-invalid');
                    fb.textContent = '';
                }
            });
        }

        // Close mobile navbar when clicking outside
        document.addEventListener('click', function(e) {
            if (window.innerWidth < 992) {
                const nav = document.getElementById('navbarNav');
                const tog = document.querySelector('.navbar-toggler');
                if (nav && tog && nav.classList.contains('show') && !nav.contains(e.target) && !tog.contains(e.target)) {
                    const bs = bootstrap.Collapse.getInstance(nav);
                    if (bs) bs.hide();
                }
            }
        });

        // Province → District → City cascade (trilingual)
        document.addEventListener('DOMContentLoaded', function () {
            const provinceSelect = document.getElementById('provinceSelect');
            const districtSelect = document.getElementById('districtSelect');
            const citySelect = document.getElementById('citySelect');

            function formatOption(name_en, name_si, name_ta) {
                let text = name_en;
                if (name_si && name_ta) text += ` (${name_si} / ${name_ta})`;
                else if (name_si) text += ` (${name_si})`;
                else if (name_ta) text += ` (${name_ta})`;
                return text;
            }

            provinceSelect.addEventListener('change', function() {
                const provinceId = this.value;
                districtSelect.innerHTML = '<option value="">Loading...</option>';
                districtSelect.disabled = true;
                citySelect.innerHTML = '<option value="">Select...</option>';
                citySelect.disabled = true;
                if (!provinceId) { districtSelect.innerHTML = '<option value="">Select...</option>'; return; }
                fetch(`get_locations.php?type=districts&province_id=${provinceId}`)
                    .then(res => res.json())
                    .then(data => {
                        districtSelect.innerHTML = '<option value="">Select District</option>';
                        data.forEach(item => {
                            districtSelect.innerHTML += `<option value="${item.id}">${formatOption(item.name_en, item.name_si, item.name_ta)}</option>`;
                        });
                        districtSelect.disabled = false;
                    })
                    .catch(err => { districtSelect.innerHTML = '<option value="">Error...</option>'; console.error(err); });
            });

            districtSelect.addEventListener('change', function() {
                const districtId = this.value;
                citySelect.innerHTML = '<option value="">Loading...</option>';
                citySelect.disabled = true;
                if (!districtId) { citySelect.innerHTML = '<option value="">Select...</option>'; return; }
                fetch(`get_locations.php?type=cities&district_id=${districtId}`)
                    .then(res => res.json())
                    .then(data => {
                        citySelect.innerHTML = '<option value="">Select City/Town</option>';
                        data.forEach(item => {
                            citySelect.innerHTML += `<option value="${item.id}">${formatOption(item.name_en, item.name_si, item.name_ta)}</option>`;
                        });
                        citySelect.disabled = false;
                    })
                    .catch(err => { citySelect.innerHTML = '<option value="">Error...</option>'; console.error(err); });
            });
        });

        // Gender toggle: show/hide custom text field when "Other" is selected
        (function() {
            const genderSelect = document.getElementById('genderSelect');
            const genderWrapper = document.getElementById('genderSpecifyWrapper');
            const genderInput = document.getElementById('genderSpecifyInput');

            function toggleGenderSpecify() {
                if (genderSelect && genderSelect.value === 'Other') {
                    genderWrapper.style.display = 'block';
                    if (genderInput) genderInput.required = true;
                } else {
                    genderWrapper.style.display = 'none';
                    if (genderInput) {
                        genderInput.value = '';
                        genderInput.required = false;
                    }
                }
            }

            if (genderSelect) {
                genderSelect.addEventListener('change', toggleGenderSpecify);
                toggleGenderSpecify(); // initialise on load
            }
        })();

        // File size instant validation
        function showFileError(input, msg) {
            let err = input.parentNode.querySelector('.file-instant-error');
            if (!err) {
                err = document.createElement('span');
                err.className = 'file-instant-error small mt-1';
                err.style.color = '#dc3545';
                err.style.display = 'block';
                input.parentNode.appendChild(err);
            }
            err.innerText = msg;
        }
        function clearFileError(input) {
            let err = input.parentNode.querySelector('.file-instant-error');
            if (err) err.innerText = '';
            input.style.borderColor = '';
        }
        function validateFileOnline(input, maxMB) {
            setTimeout(() => {
                if (!input.files || input.files.length === 0) {
                    clearFileError(input);
                    return;
                }
                const file = input.files[0];
                const limit = maxMB * 1024 * 1024;
                if (file.size > limit) {
                    const sz = (file.size / (1024*1024)).toFixed(2);
                    showFileError(input, `⚠️ Too large: ${sz}MB (Max ${maxMB}MB)`);
                    input.value = "";
                    input.style.borderColor = '#dc3545';
                } else {
                    clearFileError(input);
                }
            }, 100);
        }

        document.addEventListener('DOMContentLoaded', function() {
            const form = document.querySelector('form');
            const submitBtn = document.querySelector('button[type="submit"]');
            const profilePic = document.querySelector('input[name="profile_pic"]');
            const documentFile = document.querySelector('input[name="document"]');

            if (profilePic) profilePic.addEventListener('change', function() { validateFileOnline(this, 2); });
            if (documentFile) documentFile.addEventListener('change', function() { validateFileOnline(this, 5); });

            if (form && submitBtn) {
                form.addEventListener('submit', function() {
                    setTimeout(function() {
                        submitBtn.innerText = "Registering...";
                        submitBtn.style.opacity = "0.5";
                        submitBtn.style.pointerEvents = "none";
                    }, 0);
                });
            }
        });
    </script>
</body>
</html>
