<?php
/**
 * Membership Portal.
 * Global helper functions.
 *
 * Provides common utilities:
 * - Input sanitization, redirection, ID generation, file upload, error logging,
 * - Email queue system with UTC timestamps.
 *
 * @package    MembershipPortal.
 * @author     Heshan Shibry <heshan.shib@gmail.com>
 * @copyright  2026 HESHAN SHIBRY.
 * @license    Proprietary - All rights reserved.
 * @version    1.0.0.
 */
require_once __DIR__ . '/../vendor/autoload.php';
$dotenv = Dotenv\Dotenv::createImmutable(__DIR__ . '/../');
$dotenv->load();

require_once __DIR__ . '/../config/database.php';

// ============================================================
// PERMISSION CONSTANTS
// ============================================================
define('PERM_VIEW_MEMBERS', 'view_members');
define('PERM_EDIT_MEMBERS', 'edit_members');
define('PERM_DELETE_MEMBERS', 'delete_members');
define('PERM_MANAGE_ADMINS', 'manage_admins');
define('PERM_ALL', 'all');

// ============================================================
// UTC HELPER
// ============================================================
/**
 * Generate current UTC timestamp in MySQL datetime format.
 * Used everywhere to store times in UTC, independent of server timezone.
 *
 * @return string UTC datetime (Y-m-d H:i:s)
 */
function utcNow() {
    return (new DateTime('now', new DateTimeZone('UTC')))->format('Y-m-d H:i:s');
}

// ============================================================
// ERROR LOGGING & AGGREGATED ALERTS
// ============================================================
/**
 * Write a message to the error log and increment counters for critical types.
 * For upload/db/email errors, aggregated alerts may be sent.
 *
 * @param string $message Error message to log
 * @param string $type    Category (e.g., 'general', 'upload', 'db', 'email')
 */
function logError($message, $type = 'general') {
    $logDir = __DIR__ . '/../logs/';
    if (!is_dir($logDir)) mkdir($logDir, 0755, true);
    $logFile = $logDir . 'error.log';
    $timestamp = date('Y-m-d H:i:s');
    $formatted = "[$timestamp] [$type] $message" . PHP_EOL;
    @file_put_contents($logFile, $formatted, FILE_APPEND | LOCK_EX);
    $critical_types = ['upload', 'db', 'email'];
    if (in_array($type, $critical_types)) {
        global $pdo;
        if (isset($pdo)) {
            $counterFile = $logDir . 'error_counter_' . $type . '.txt';
            $count = file_exists($counterFile) ? (int)file_get_contents($counterFile) : 0;
            file_put_contents($counterFile, (string)($count + 1));
            sendAggregatedErrorAlert($type, $pdo);
        }
    }
}

/**
 * Send aggregated error alert email (once per hour per error type) to all admins.
 *
 * @param string $type Error type (upload/db/email)
 * @param PDO    $pdo  Database connection
 */
function sendAggregatedErrorAlert($type, $pdo) {
    static $sending = false;
    if ($sending) return;
    $sending = true;
    $logDir = __DIR__ . '/../logs/';
    $counterFile = $logDir . 'error_counter_' . $type . '.txt';
    $lastSentFile = $logDir . 'last_sent_' . $type . '.txt';
    $count = file_exists($counterFile) ? (int)file_get_contents($counterFile) : 0;
    $lastSent = file_exists($lastSentFile) ? (int)file_get_contents($lastSentFile) : 0;
    $now = time();
    if ($count === 0) { $sending = false; return; }
    if (($now - $lastSent) >= 3600) {
        $subject = "⚠️ Error Alert on Membership Portal ($type)";
        $body = "The following error type occurred $count time(s) in the last hour:\n\n";
        $body .= "Error Type: $type\nTotal occurrences: $count\nLast error recorded at: " . date('Y-m-d H:i:s') . "\n\nPlease check the error log for details.\n";
        $stmt = $pdo->prepare("SELECT email, full_name FROM admins");
        $stmt->execute();
        $admins = $stmt->fetchAll();
        foreach ($admins as $admin) {
            // Use the generic sendEmail function
            sendEmail($admin['email'], $subject, $body, $admin['full_name']);
        }
        file_put_contents($counterFile, '0');
        file_put_contents($lastSentFile, (string)$now);
    }
    $sending = false;
}

// ============================================================
// DELETION NOTIFICATION
// ============================================================
/**
 * Send deletion notification email to all super admins (primary + secondary).
 *
 * @param string $itemType   'Member' or 'Admin'
 * @param string $itemName   Full name of deleted entity
 * @param string $itemId     Member ID or Admin ID
 * @param string $deletedBy  Name of the admin who performed deletion
 * @param string $reason     Deletion reason (required on deletion form)
 */
function sendDeletionNotification($itemType, $itemName, $itemId, $deletedBy, $reason = '', $tzOffset = null, $deletedType = null) {
    global $pdo;
    // Fetch all super admins (primary + secondary)
    $stmt = $pdo->prepare("SELECT email, full_name FROM admins WHERE id = 1 OR is_super_admin = 1");
    $stmt->execute();
    $admins = $stmt->fetchAll();

    // Get the deleter's own admin type
    $deleterType = '';
    $stmt2 = $pdo->prepare("SELECT is_super_admin FROM admins WHERE full_name = ?");
    $stmt2->execute([$deletedBy]);
    $row = $stmt2->fetch();
    if ($row) {
        $deleterType = $row['is_super_admin'] ? 'Super Admin' : 'Regular Admin';
    }

    $subject = "🗑️ $itemType Deleted: $itemName ($itemId)";

    // Generate deletion timestamp with local time if offset provided
    $utcNow = new DateTime('now', new DateTimeZone('UTC'));
    if ($tzOffset !== null) {
        $local = clone $utcNow;
        $local->modify("-{$tzOffset} minutes");
        $deletionTime = $local->format('d M Y, H:i:s');
    } else {
        $deletionTime = $utcNow->format('d M Y, H:i:s') . ' UTC';
    }

    $body = "The following $itemType was deleted by $deletedBy ($deleterType) on $deletionTime.\n\n";
    $body .= "Name: $itemName\n";
    $body .= "ID: $itemId\n";
    if ($itemType === 'Admin' && $deletedType !== null) {
        $body .= "Type: $deletedType\n";
    }
    if (!empty($reason)) $body .= "Reason: $reason\n\n";
    $body .= "To restore, please log in and use the Restore page.\n";

    foreach ($admins as $admin) {
        sendEmail($admin['email'], $subject, $body, $admin['full_name']);
    }
}

// ============================================================
// GENERIC EMAIL SENDER (provider‑agnostic)
// ============================================================
/**
 * Send an email using the configured provider (currently Brevo).
 * Logs successes to email_success.log (no alerts) and failures to error.log.
 *
 * @param string $to      Recipient email address
 * @param string $subject Email subject
 * @param string $content Plain text email content
 * @param string $toName  Recipient name (optional)
 * @return array ['success' => bool, 'message' => string]
 */
function sendEmail($to, $subject, $content, $toName = '') {
    $apiKey = $_ENV['EMAIL_API_KEY'];
    if (empty($apiKey)) {
        logError("Email API key missing", 'email');
        return ['success' => false, 'message' => 'Email service not configured.'];
    }
    $postData = [
        'sender' => ['name' => 'National Movement', 'email' => 'srilankaparty392@gmail.com'],
        'to' => [['email' => $to, 'name' => $toName ?: $to]],
        'subject' => $subject,
        'textContent' => $content,
    ];
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, 'https://api.brevo.com/v3/smtp/email');
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($postData));
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        'accept: application/json',
        'api-key: ' . $apiKey,
        'content-type: application/json'
    ]);
    curl_setopt($ch, CURLOPT_TIMEOUT, 10);
    curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 5);
    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $curlError = curl_error($ch);
    curl_close($ch);
    if ($curlError) {
        logError("cURL error: $curlError", 'email');
        return ['success' => false, 'message' => 'cURL error: ' . $curlError];
    }
    if ($httpCode === 201) {
        @file_put_contents(__DIR__ . '/../logs/email_success.log', date('Y-m-d H:i:s') . " Email sent to $to: $subject" . PHP_EOL, FILE_APPEND);
        return ['success' => true, 'message' => 'Email sent.'];
    } else {
        $criticalCodes = [400, 401, 403, 500, 502, 503, 504];
        $logType = in_array($httpCode, $criticalCodes) ? 'email' : 'email_noncritical';
        logError("Email failed to $to. HTTP $httpCode: $response", $logType);
        return ['success' => false, 'message' => 'Failed to send email.'];
    }
}

// ============================================================
// SANITIZATION & BASIC HELPERS
// ============================================================
/**
 * Sanitize input for safe HTML output.
 */
function sanitize($input) { return htmlspecialchars(strip_tags(trim($input))); }

/**
 * Sanitize plain text (no HTML conversion, used for deletion reasons).
 */
function sanitizePlain($input) { return trim(strip_tags($input)); }

/**
 * Redirect to a URL, removing .php extension for clean URLs.
 */
function redirect($url) {
    $url = preg_replace('/\.php$/', '', $url);
    header('Location: ' . BASE_URL . ltrim($url, '/'));
    exit;
}

/**
 * Check if any admin exists in the database.
 */
function hasAdmin($pdo) {
    $stmt = $pdo->query("SELECT COUNT(*) FROM admins");
    return $stmt->fetchColumn() > 0;
}

// ============================================================
// ID GENERATORS
// ============================================================
/**
 * Generate a unique member ID (e.g., MP202600001).
 */
function generateMemberId($pdo) {
    $prefix = 'MP' . date('Y');
    do {
        $number = str_pad(rand(1, 99999), 5, '0', STR_PAD_LEFT);
        $member_id = $prefix . $number;
        $stmt = $pdo->prepare("SELECT id FROM members WHERE member_id = ?");
        $stmt->execute([$member_id]);
    } while ($stmt->fetch());
    return $member_id;
}

/**
 * Generate a unique admin ID (e.g., AD202600001).
 */
function generateAdminId($pdo) {
    $prefix = 'AD' . date('Y');
    do {
        $number = str_pad(rand(1, 99999), 5, '0', STR_PAD_LEFT);
        $admin_id = $prefix . $number;
        $stmt = $pdo->prepare("SELECT id FROM admins WHERE admin_id = ?");
        $stmt->execute([$admin_id]);
    } while ($stmt->fetch());
    return $admin_id;
}

/**
 * Generate a random password (12 chars, letters, numbers, special chars).
 */
function generateRandomPassword($length = 12) {
    $chars = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789!@#$%&*?';
    return substr(str_shuffle($chars), 0, $length);
}

// ============================================================
// FILE UPLOAD
// ============================================================
/**
 * Handle file upload with validation (type, size, move).
 * User errors are logged as 'user_upload'; system errors as 'upload'.
 *
 * @return string|false Destination path on success, false on failure
 */
function uploadFile($fileInput, $targetDir, $allowedTypes = ['jpg','jpeg','png','pdf','doc','docx'], $maxSize = 5*1024*1024) {
    if (!isset($_FILES[$fileInput]) || $_FILES[$fileInput]['error'] !== UPLOAD_ERR_OK) {
        logError("Upload error: File not uploaded or error code " . ($_FILES[$fileInput]['error'] ?? 'missing'), 'user_upload');
        return false;
    }
    $file = $_FILES[$fileInput];
    $ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
    if (!in_array($ext, $allowedTypes)) {
        logError("Invalid file type: {$file['name']} (extension $ext)", 'user_upload');
        return false;
    }
    if ($file['size'] > $maxSize) {
        logError("File too large: {$file['name']} ({$file['size']} bytes)", 'user_upload');
        return false;
    }
    $newName = uniqid() . '_' . bin2hex(random_bytes(5)) . '.' . $ext;
    $destination = rtrim($targetDir, '/') . '/' . $newName;
    if (move_uploaded_file($file['tmp_name'], $destination)) {
        return $destination;
    } else {
        logError("Failed to move uploaded file: {$file['name']} to $destination", 'upload');
        return false;
    }
}

// ============================================================
// PASSWORD STRENGTH
// ============================================================
/**
 * Validate password strength:
 * - Minimum 8 characters
 * - At least one uppercase, one lowercase, one digit, one special character
 */
function isStrongPassword($password) {
    if (strlen($password) < 8) return false;
    if (!preg_match('/[A-Z]/', $password)) return false;
    if (!preg_match('/[a-z]/', $password)) return false;
    if (!preg_match('/[0-9]/', $password)) return false;
    if (!preg_match('/[^A-Za-z0-9]/', $password)) return false;
    return true;
}

// ============================================================
// EMAIL QUEUE SYSTEM (FALLBACK FOR FAILED IMMEDIATE SENDS)
// ============================================================
/**
 * Add an email to the queue instead of sending immediately.
 * Used as fallback when sendEmail() fails.
 *
 * @param string $to      Recipient email
 * @param string $subject Email subject
 * @param string $body    Plain text content
 * @param string $toName  Recipient name (optional)
 * @param int    $priority 0 = normal (reserved for future)
 * @return bool True if successfully queued
 */
function queueEmail($to, $subject, $body, $toName = '', $priority = 0) {
    global $pdo;
    if (!isset($pdo)) $pdo = getDB();
    $utc = utcNow();
    $stmt = $pdo->prepare("INSERT INTO email_queue (to_email, to_name, subject, body, priority, next_attempt_at, created_at) VALUES (?, ?, ?, ?, ?, ?, ?)");
    return $stmt->execute([$to, $toName, $subject, $body, $priority, $utc, $utc]);
}

/**
 * Process the email queue – should be called by cron or fallback.
 * On success, record is deleted. On failure, retries with exponential backoff.
 *
 * @param int $limit Max emails to process per run (default 20)
 * @return array Stats ['sent' => int, 'failed' => int]
 */
function processEmailQueue($limit = 20) {
    global $pdo;
    if (!isset($pdo)) $pdo = getDB();
    $stats = ['sent' => 0, 'failed' => 0];
    $limitInt = (int)$limit;
    $utcNow = utcNow();
    $stmt = $pdo->prepare("SELECT * FROM email_queue WHERE status = 'pending' AND next_attempt_at <= ? ORDER BY priority DESC, created_at ASC LIMIT $limitInt");
    $stmt->execute([$utcNow]);
    $emails = $stmt->fetchAll();
    foreach ($emails as $email) {
        $result = sendEmail($email['to_email'], $email['subject'], $email['body'], $email['to_name']);
        $now = utcNow();
        if ($result['success']) {
            $pdo->prepare("DELETE FROM email_queue WHERE id = ?")->execute([$email['id']]);
            $stats['sent']++;
        } else {
            $retries = $email['retries'] + 1;
            if ($retries >= $email['max_retries']) {
                $pdo->prepare("UPDATE email_queue SET status = 'failed', retries = ?, updated_at = ? WHERE id = ?")->execute([$retries, $now, $email['id']]);
                $stats['failed']++;
            } else {
                $delay = min(pow($retries, 2), 60); // exponential backoff: 1,4,9,16... minutes (capped at 60)
                $next = date('Y-m-d H:i:s', strtotime("+{$delay} minutes", strtotime($now)));
                $pdo->prepare("UPDATE email_queue SET retries = ?, next_attempt_at = ?, updated_at = ? WHERE id = ?")->execute([$retries, $next, $now, $email['id']]);
            }
        }
    }
    return $stats;
}

/**
 * Automatically process the queue if enough time has passed since last run.
 * This serves as a fallback when external cron is unavailable.
 * Called on every admin page load (inside validateAdminSession).
 *
 * @param int $intervalMinutes Minimum minutes between runs (default 5)
 * @return bool True if queue was processed, false otherwise
 */
function processEmailQueueIfNeeded($intervalMinutes = 5) {
    $lastRunFile = __DIR__ . '/../logs/queue_last_run.txt';
    $now = time();
    if (!file_exists($lastRunFile) || ($now - (int)file_get_contents($lastRunFile)) >= ($intervalMinutes * 60)) {
        file_put_contents($lastRunFile, (string)$now);
        $stats = processEmailQueue(20);
        @file_put_contents(__DIR__ . '/../logs/queue_auto.log', date('Y-m-d H:i:s') . " - Sent: {$stats['sent']}, Failed: {$stats['failed']}\n", FILE_APPEND);
        return true;
    }
    return false;
}

/**
 * Normalize a street address for fuzzy matching (Sri Lankan context).
 * - Lowercase
 * - Remove punctuation
 * - Collapse multiple spaces
 * - Replace common abbreviations
 *
 * @param string $address Raw address input
 * @return string Normalized address
 */
 function normalizeAddress($address) {
     $address = mb_strtolower($address);
     $address = preg_replace('/[^\p{L}\p{N}\s]/u', '', $address); // remove punctuation
     $address = preg_replace('/\s+/', ' ', $address); // collapse multiple spaces
     $address = trim($address);

     // Common Sri Lankan street abbreviations (Optimised & Unified)
     $replacements = [
         // English Standard Terms
         'housing scheme'=> 'hs', // Multi-word first
         'gardens'       => 'grdns',
         'junction'      => 'jct',
         'terrace'       => 'terr',
         'highway'       => 'hwy',
         'avenue'        => 'ave',
         'street'        => 'st',
         'estate'        => 'est',
         'square'        => 'sq',
         'bazaar'        => 'bzr',
         'road'          => 'rd',
         'lane'          => 'ln',
         'place'         => 'pl',
         'drive'         => 'dr',
         'court'         => 'ct',

         // Sinhala/Transliterated Terms
         'mawatha'       => 'mw',
         'veediya'       => 'vidiya', // Standardises spelling
         'palatha'       => 'paltha',
         'watta'         => 'watta',
         'maga'          => 'mga',
         'para'          => 'para',
         'gama'          => 'gama',

         // Tamil/Transliterated Terms
         'saalai'        => 'slai',
         'santhi'        => 'snthi',
         'veethi'        => 'vth',
         'theru'         => 'thr',

         // Administrative & Postal
         'division'      => 'div',
         'section'       => 'sec',
         'colony'        => 'col',
         'ward'          => 'wrd',
     ];

     foreach ($replacements as $original => $normalized) {
         $pattern = '/\b' . preg_quote($original, '/') . '\b/u';
         $address = preg_replace($pattern, $normalized, $address);
     }

     return $address;
 }

/**
 * Calculate Levenshtein distance and return similarity percentage.
 * Uses native levenshtein() if available (faster), otherwise similar_text().
 *
 * @param string $str1 First string
 * @param string $str2 Second string
 * @return float Similarity percentage (0-100)
 */
function stringSimilarity($str1, $str2) {
    if (function_exists('levenshtein')) {
        $distance = levenshtein($str1, $str2);
        $maxLen = max(strlen($str1), strlen($str2));
        if ($maxLen == 0) return 100;
        return (1 - $distance / $maxLen) * 100;
    } else {
        similar_text($str1, $str2, $percent);
        return $percent;
    }
}

/**
 * Find the best matching verified master address for a given normalized street and city.
 * Uses fuzzy similarity (>= 90% by default) to catch typos.
 *
 * @param PDO $pdo Database connection
 * @param string $normalizedStreet Already normalized street address
 * @param int $cityId City ID from cities table
 * @param int $threshold Minimum similarity percentage (0-100)
 * @return array|null Matching master address record or null
 */
function findBestMatchingAddress($pdo, $normalizedStreet, $cityId, $threshold = 90) {
    // Fetch all verified master addresses for this city (usually only a few hundred)
    $stmt = $pdo->prepare("
        SELECT id, normalized_street, polling_division, gn_division, assigned_polling_booth
        FROM master_addresses
        WHERE city_id = ? AND status = 'verified'
    ");
    $stmt->execute([$cityId]);
    $candidates = $stmt->fetchAll();

    $bestMatch = null;
    $bestScore = 0;

    foreach ($candidates as $cand) {
        $score = stringSimilarity($normalizedStreet, $cand['normalized_street']);
        if ($score >= $threshold && $score > $bestScore) {
            $bestScore = $score;
            $bestMatch = $cand;
        }
    }
    return $bestMatch;
}
?>
