<?php
/**
 * Membership Portal.
 * Global helper functions.
 * Shared Footer for all pages public.
 * Automatically displays the current year and a copyright notice.
 *
 * @package    MembershipPortal.
 * @author     Heshan Shibry <heshan.shib@gmail.com>
 * @copyright  2026 HESHAN SHIBRY.
 * @license    Proprietary - All rights reserved.
 * @version    1.0.0.
 */
?>

      <!-- Report Issue Modal -->
      <div class="modal fade" id="reportIssueModal" tabindex="-1" aria-labelledby="reportIssueModalLabel" aria-hidden="true">
          <div class="modal-dialog">
              <div class="modal-content">
                  <form method="POST" action="<?= BASE_URL ?>admin/send_report">
                      <!-- Hidden field for browser timezone offset (minutes) -->
                      <input type="hidden" name="tz_offset" id="tz_offset" value="">
                      <div class="modal-header bg-danger text-white">
                          <h5 class="modal-title" id="reportIssueModalLabel"><i class="bi bi-bug"></i> Report an Issue</h5>
                          <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
                      </div>
                      <div class="modal-body">
                          <p>Describe the problem you encountered. Our technical team will review it.</p>
                          <div class="mb-3">
                              <label class="form-label">Subject</label>
                              <input type="text" name="subject" class="form-control" required placeholder="Brief description">
                          </div>
                          <div class="mb-3">
                              <label class="form-label">Details</label>
                              <textarea name="message" class="form-control" rows="4" required placeholder="Please provide as much detail as possible..."></textarea>
                          </div>
                      </div>
                      <div class="modal-footer">
                          <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                          <button type="submit" class="btn btn-primary">Send Report</button>
                      </div>
                  </form>
              </div>
          </div>
      </div>

      <!-- Set the timezone offset when the page loads -->
      <script>
          document.addEventListener('DOMContentLoaded', function() {
              const offset = new Date().getTimezoneOffset();
              const fields = ['tz_offset', 'tz_offset_member', 'tz_offset_admin'];
              fields.forEach(id => {
                  const el = document.getElementById(id);
                  if (el) el.value = offset;
              });
          });
      </script>
      
<footer class="bg-dark text-white-50 text-center py-4 mt-auto">
    <div class="container px-3">
        <!-- Main Footer Links -->
        <p class="mb-0 footer-text">
            <span>National Movement</span>
            <span class="footer-sep">|</span>
            <span>Secure Cloud Platform</span>
            <span class="footer-sep">|</span>
            <span>Mobile Responsive</span>
            <span class="footer-sep">|</span>
            <span>Member Empowerment</span>
        </p>

        <!-- Copyright Section -->
        <p class="mb-0 mt-3 small">
            &copy; <?= date('Y') ?> National Movement. All rights reserved.
        </p>
    </div>
</footer>
</body>
</html>
