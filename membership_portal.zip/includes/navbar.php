<?php
/**
 * Membership Portal.
 * Shared Navbar – works for both public and admin pages.
 *
 * @package    MembershipPortal.
 * @author     Heshan Shibry <heshan.shib@gmail.com>
 * @copyright  2026 HESHAN SHIBRY.
 * @license    Proprietary - All rights reserved.
 * @version    1.0.0.
 */

// Set default values for optional variables to prevent warnings
$avatarPic = $avatarPic ?? null;
$userId = $userId ?? 0;
$fullName = $fullName ?? '';
$userRole = $userRole ?? '';
$hasGenerateReports = $hasGenerateReports ?? false;
$hasRestoreUsers = $hasRestoreUsers ?? false;
$baseUrl = $baseUrl ?? '/';
$currentPage = $currentPage ?? '';
$hideAdminLinks = $hideAdminLinks ?? false;
$hideDashboardLink = $hideDashboardLink ?? false;
$customNavLink = $customNavLink ?? '';
$customNavLinkUrl = $customNavLinkUrl ?? '';
$showViewMemberLink = $showViewMemberLink ?? false;
$viewMemberId = $viewMemberId ?? 0;
$showBackToManageAdmins = $showBackToManageAdmins ?? false;
?>

<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
    <div class="container">
        <!-- Logo / Brand -->
        <a class="navbar-brand fw-bold" href="<?= isset($_SESSION['user_id']) ? BASE_URL . 'admin/dashboard' : $baseUrl ?>">
            NATIONAL BUILDER · MOVEMENT
        </a>

        <!-- Mobile Toggler (hamburger) - stays left of profile -->
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>

        <?php if (isset($isLoggedIn) && $isLoggedIn): ?>
            <!-- Profile dropdown - always visible on right -->
            <ul class="navbar-nav order-lg-2">
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle d-flex align-items-center py-0" href="#" id="userDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                        <?php if ($avatarPic): ?>
                            <img src="<?= $baseUrl ?>admin/view_admin_pic.php?id=<?= $userId ?>" alt="Profile" class="rounded-circle" width="32" height="32" style="object-fit: cover;">
                        <?php else: ?>
                            <i class="bi bi-person-circle" style="font-size: 1.8rem;"></i>
                        <?php endif; ?>
                    </a>
                    <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="userDropdown">
                        <li class="dropdown-header"><?= htmlspecialchars($fullName) ?></li>
                        <li><hr class="dropdown-divider"></li>
                        <li><a class="dropdown-item" href="<?= $baseUrl ?>admin/profile"><i class="bi bi-person"></i> My Profile</a></li>
                        <?php if ($userId == 1 || $hasRestoreUsers || $hasGenerateReports): ?>
                            <li><a class="dropdown-item" href="<?= $baseUrl ?>admin/settings"><i class="bi bi-gear"></i> Settings</a></li>
                        <?php endif; ?>
                        <?php if ($userId != 1): ?>
                            <li><a class="dropdown-item" href="#" data-bs-toggle="modal" data-bs-target="#reportIssueModal"><i class="bi bi-envelope-exclamation"></i> Report Issue</a></li>
                        <?php endif; ?>
                        <li><hr class="dropdown-divider"></li>
                        <li><a class="dropdown-item" href="<?= $baseUrl ?>logout"><i class="bi bi-box-arrow-right"></i> Logout</a></li>
                    </ul>
                </li>
            </ul>

            <!-- Main navigation links - inside hamburger, aligned right on desktop -->
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                    <?php if ($currentPage == 'dashboard'): ?>
                        <li class="nav-item">
                            <a class="nav-link" href="<?= $baseUrl ?>">Home</a>
                        </li>
                    <?php endif; ?>

                    <?php if (!$hideDashboardLink): ?>
                        <li class="nav-item">
                            <a class="nav-link <?= ($currentPage == 'dashboard') ? 'active' : '' ?>" href="<?= $baseUrl ?>admin/dashboard">Dashboard</a>
                        </li>
                    <?php endif; ?>

                    <?php if (!$hideAdminLinks): ?>
                        <?php if ($userId == 1 || !empty($isSuperAdmin)): ?>
                            <li class="nav-item">
                                <a class="nav-link <?= ($currentPage == 'manage_admins') ? 'active' : '' ?>" href="<?= $baseUrl ?>admin/manage_admins">Manage Admins</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link <?= ($currentPage == 'manage_roles') ? 'active' : '' ?>" href="<?= $baseUrl ?>admin/manage_roles">Manage Roles</a>
                            </li>
                        <?php endif; ?>

                        <!-- NEW: Verify Addresses link – visible to anyone with edit_members permission -->
                        <?php if (hasPermission('edit_members')): ?>
                            <?php
                            // Count pending addresses (global $pdo is already available)
                            $pendingCount = 0;
                            $stmt = $pdo->query("SELECT COUNT(*) FROM master_addresses WHERE status = 'pending'");
                            if ($stmt) $pendingCount = $stmt->fetchColumn();
                            ?>
                            <li class="nav-item">
                                <a class="nav-link <?= ($currentPage == 'verify_addresses') ? 'active' : '' ?>" href="<?= $baseUrl ?>admin/verify_addresses">Verify Addresses
                                    <?php if ($pendingCount > 0): ?>
                                        <span class="badge bg-warning text-dark ms-1"><?= $pendingCount ?></span>
                                    <?php endif; ?>
                                </a>
                            </li>
                        <?php endif; ?>

                        <?php if ($hasGenerateReports): ?>
                            <li class="nav-item">
                                <a class="nav-link <?= ($currentPage == 'reports') ? 'active' : '' ?>" href="<?= $baseUrl ?>admin/reports">Reports</a>
                            </li>
                        <?php endif; ?>
                    <?php endif; ?>

                    <?php if ($showViewMemberLink && $viewMemberId): ?>
                        <li class="nav-item">
                            <a class="nav-link" href="<?= $baseUrl ?>admin/view_member?id=<?= $viewMemberId ?>">View Member</a>
                        </li>
                    <?php endif; ?>

                    <?php if ($showBackToManageAdmins): ?>
                        <li class="nav-item">
                            <a class="nav-link" href="<?= $baseUrl ?>admin/manage_admins">Manage Administrator</a>
                        </li>
                    <?php endif; ?>

                    <?php if ($customNavLink && $customNavLinkUrl): ?>
                        <li class="nav-item">
                            <a class="nav-link" href="<?= $customNavLinkUrl ?>"><?= htmlspecialchars($customNavLink) ?></a>
                        </li>
                    <?php endif; ?>
                </ul>
            </div>
        <?php else: ?>
            <!-- Public view: login/register inside hamburger, no profile -->
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item">
                        <a class="nav-link <?= ($currentPage == 'register') ? 'active' : '' ?>" href="<?= $baseUrl ?>register">Join Movement</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="<?= $baseUrl ?>login">Login</a>
                    </li>
                </ul>
            </div>
        <?php endif; ?>
    </div>
</nav>
