<?php
/**
  * Membership Portal.
  * Global Admin Header
  * Include this at the top of every admin page (after setting $page_title optionally)
  *
  * @package    MembershipPortal.
  * @author     Heshan Shibry <heshan.shib@gmail.com>
  * @copyright  2026 HESHAN SHIBRY.
  * @license    Proprietary - All rights reserved.
  * @version    1.0.0.
 */
?>
<!DOCTYPE html>
<html lang="en" class="h-100">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo isset($page_title) ? htmlspecialchars($page_title) . ' | ' : ''; ?>National Movement</title>

    <!-- Bootstrap 5 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Flatpickr CSS (optional, but harmless on pages without date pickers) -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/flatpickr/dist/flatpickr.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/flatpickr/dist/themes/material_blue.css">
    <!-- Bootstrap Icons -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <!-- Global Custom CSS -->
    <link rel="stylesheet" href="<?= BASE_URL ?>assets/css/style.css">

    <!-- Page‑specific CSS (injected by individual pages) -->
    <?php if (isset($page_styles)) echo $page_styles; ?>

    <!-- Global JavaScript (deferred) -->
    <script defer src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
    <script defer src="https://cdn.jsdelivr.net/npm/flatpickr"></script>
    <script defer src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script defer src="<?= BASE_URL ?>assets/js/main.js"></script>
</head>
<body class="bg-light d-flex flex-column min-vh-100">
