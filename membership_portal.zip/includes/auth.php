<?php
/**
 * Membership Portal.
 * - Authentication & Permission Functions.
 * - RBAC, session management, etc.
 *
 * @package    MembershipPortal.
 * @author     Heshan Shibry <heshan.shib@gmail.com>
 * @copyright  2026 HESHAN SHIBRY.
 * @license    Proprietary - All rights reserved.
 * @version    1.0.0.
 */

 require_once __DIR__ . '/functions.php';

// ========== SESSION CONFIGURATION ==========
session_set_cookie_params([
    'lifetime' => 0,
    'path'     => '/',
    'domain'   => '',
    'secure'   => !empty($_SERVER['HTTPS']),
    'httponly' => true,
    'samesite' => 'Lax'
]);

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
define('SESSION_INACTIVITY_TIMEOUT', 1800); // 30 minute Timeout shown here in seconds

if (isset($_SESSION['user_id'])) {
    if (isset($_SESSION['last_activity']) && (time() - $_SESSION['last_activity']) > SESSION_INACTIVITY_TIMEOUT) {

        // 1. Clear session data
        $_SESSION = array();

        // 2. Regenerate session ID (sends new cookie, deletes old session file)
        session_regenerate_id(true);

        // 3. Set flash alert for next request
        $_SESSION['show_timeout_alert'] = true;

        // 4. Redirect to admin login (no manual cookie deletion!)
        redirect('admin');
        exit;
    }
    $_SESSION['last_activity'] = time();
}
// ========== END SESSION CONFIGURATION ==========

/**
 * Login administrator.
 */
function login($email, $password, $pdo) {
    $stmt = $pdo->prepare("SELECT * FROM admins WHERE email = ?");
    $stmt->execute([$email]);
    $admin = $stmt->fetch(PDO::FETCH_ASSOC);
    if ($admin && password_verify($password, $admin['password'])) {
        $_SESSION['user_id'] = $admin['id'];
        $_SESSION['admin_id'] = $admin['admin_id'];
        $_SESSION['full_name'] = $admin['full_name'];
        $_SESSION['role'] = $admin['role'];
        $_SESSION['is_super_admin'] = $admin['is_super_admin'];
        $_SESSION['permissions'] = $admin['permissions'];
        $_SESSION['last_activity'] = time();
        return true;
    }
    return false;
}

/**
 * Logout.
 */
function logout() {
    session_unset();
    session_destroy();

    // Delete session cookie from browser
    if (isset($_COOKIE[session_name()])) {
        setcookie(session_name(), '', time() - 3600, '/');
    }

    redirect('admin');
}

/**
 * Validate admin session (still exists in DB).
 */
function validateAdminSession($pdo) {
    if (!isset($_SESSION['user_id'])) {
        redirect('');
        exit;
    }
    $stmt = $pdo->prepare("SELECT id FROM admins WHERE id = ?");
    $stmt->execute([$_SESSION['user_id']]);
    if (!$stmt->fetch()) {
        session_destroy();
        redirect('setup');
        exit;
    }
    // Process queued emails (fallback)
    processEmailQueueIfNeeded(5);
}

/**
 * Has permission (RBAC + super admin).
 */
function hasPermission($permission, $userId = null) {
    if (!$userId) {
        if (!isset($_SESSION['user_id'])) return false;
        $userId = $_SESSION['user_id'];
    }
    global $pdo;
    if (!isset($pdo)) $pdo = getDB();

    if ($userId == 1) return true;
    if (isset($_SESSION['is_super_admin']) && $_SESSION['is_super_admin'] == 1) {
        return true;
    }
    if (!isset($_SESSION['user_id']) || $_SESSION['user_id'] != $userId) {
        $stmt = $pdo->prepare("SELECT is_super_admin FROM admins WHERE id = ?");
        $stmt->execute([$userId]);
        $row = $stmt->fetch();
        if ($row && $row['is_super_admin'] == 1) return true;
    }

    // Legacy JSON permissions
    $stmt = $pdo->prepare("SELECT permissions FROM admins WHERE id = ?");
    $stmt->execute([$userId]);
    $row = $stmt->fetch();
    if ($row && !empty($row['permissions'])) {
        $perms = json_decode($row['permissions'], true);
        if (in_array(PERM_ALL, $perms)) return true;
        if (in_array($permission, $perms)) return true;
    }

    // RBAC via roles
    $stmt = $pdo->prepare("
        SELECT COUNT(*) FROM admin_roles ar
        JOIN role_permissions rp ON ar.role_id = rp.role_id
        JOIN permissions p ON rp.permission_id = p.id
        WHERE ar.admin_id = ? AND p.name = ?
    ");
    $stmt->execute([$userId, $permission]);
    return $stmt->fetchColumn() > 0;
}

/**
 * Get all permissions of an admin.
 */
function getUserPermissions($userId = null) {
    if (!$userId) {
        if (!isset($_SESSION['user_id'])) return [];
        $userId = $_SESSION['user_id'];
    }
    global $pdo;
    if (!isset($pdo)) $pdo = getDB();

    if ($userId == 1) {
        $allPerms = $pdo->query("SELECT name FROM permissions")->fetchAll(PDO::FETCH_COLUMN);
        return $allPerms;
    }

    $stmt = $pdo->prepare("SELECT is_super_admin FROM admins WHERE id = ?");
    $stmt->execute([$userId]);
    $row = $stmt->fetch();
    if ($row && $row['is_super_admin'] == 1) {
        $allPerms = $pdo->query("SELECT name FROM permissions")->fetchAll(PDO::FETCH_COLUMN);
        return $allPerms;
    }

    $stmt = $pdo->prepare("
        SELECT DISTINCT p.name FROM admin_roles ar
        JOIN role_permissions rp ON ar.role_id = rp.role_id
        JOIN permissions p ON rp.permission_id = p.id
        WHERE ar.admin_id = ?
    ");
    $stmt->execute([$userId]);
    return $stmt->fetchAll(PDO::FETCH_COLUMN);
}

/**
 * Delete expired temporary admin accounts.
 */
function deleteExpiredTempAdmins($pdo) {
    $now = time();
    $stmt = $pdo->prepare("DELETE FROM admins WHERE force_password_change = 1 AND temp_password_expires IS NOT NULL AND temp_password_expires < ?");
    $stmt->execute([$now]);
}
?>
