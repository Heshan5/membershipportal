<?php
/**
 * Membership Portal.
 * Database Configuration.
 *
 * Defines database connection constants (host, port, user, password, name).
 * and the BASE_URL constant for redirects. Provides getDB() function to.
 * return a PDO database connection with error handling.
 *
 * @package    MembershipPortal.
 * @author     Heshan Shibry <heshan.shib@gmail.com>
 * @copyright  2026 HESHAN SHIBRY.
 * @license    Proprietary - All rights reserved.
 * @version    1.0.0.
 */
define('DB_HOST', 'sql301.infinityfree.com'); //sql host url
define('DB_PORT', '3306'); // add this line (default MySQL port)
define('DB_USER', 'if0_41699951'); //database username
define('DB_PASS', 'OgcZvNxvB734JG8'); //database password
define('DB_NAME', 'if0_41699951_membership_portal'); //database name
define('PRIMARY_ADMIN_EMAIL', 'srilankaparty392@gmail.com'); //this email is for secondary admins to report site errors and issues to the primary admin. your personal email.
define('NOREPLY_EMAIL', 'srilankaparty392@gmail.com'); // verified sender for outgoing emails.

// Base URL for the application (used in redirects)
// Change 'membership_portal' to your actual folder name, or leave empty if in root
define('BASE_URL', '/');

function getDB() {
    try {
        $pdo = new PDO("mysql:host=".DB_HOST.";port=".DB_PORT.";dbname=".DB_NAME.";charset=utf8mb4", DB_USER, DB_PASS);
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        return $pdo;
    } catch (PDOException $e) {
        die("Database connection failed: " . $e->getMessage());
    }
}
?>
