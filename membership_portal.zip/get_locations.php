<?php
/**
 * Membership Portal.
 * Get Locations.
 * This file is used by the cascade dropdowns. Place it in the same folder as register.php.
 *
 * @package    MembershipPortal.
 * @author     Heshan Shibry <heshan.shib@gmail.com>
 * @copyright  2026 HESHAN SHIBRY.
 * @license    Proprietary - All rights reserved.
 * @version    1.0.0.
 */
require_once 'includes/functions.php';
$pdo = getDB();

header('Content-Type: application/json');

$type = isset($_GET['type']) ? $_GET['type'] : '';

if ($type === 'districts' && isset($_GET['province_id'])) {
    $provinceId = (int)$_GET['province_id'];
    $stmt = $pdo->prepare("SELECT id, name_en, name_si, name_ta FROM districts WHERE province_id = ? ORDER BY name_en");
    $stmt->execute([$provinceId]);
    echo json_encode($stmt->fetchAll(PDO::FETCH_ASSOC));
    exit;
}

if ($type === 'cities' && isset($_GET['district_id'])) {
    $districtId = (int)$_GET['district_id'];
    $stmt = $pdo->prepare("SELECT id, name_en, name_si, name_ta FROM cities WHERE district_id = ? ORDER BY name_en");
    $stmt->execute([$districtId]);
    echo json_encode($stmt->fetchAll(PDO::FETCH_ASSOC));
    exit;
}

echo json_encode([]);
?>
