<?php
/**
 * Membership Portal.
 * Logout Script.
 *
 * Destroys the current admin session and redirects to the home page.
 *
 * @package    MembershipPortal.
 * @author     Heshan Shibry <heshan.shib@gmail.com>
 * @copyright  2026 HESHAN SHIBRY.
 * @license    Proprietary - All rights reserved.
 * @version    1.0.0.
 */
require_once 'includes/auth.php';
logout();
?>
