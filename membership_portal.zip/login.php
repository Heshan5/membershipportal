<?php
/**
 * Membership Portal.
 * Member Portal – Coming Soon Page.
 *
 * Displays a placeholder for the future member dashboard.
 *
 * @package    MembershipPortal.
 * @author     Heshan Shibry <heshan.shib@gmail.com>
 * @copyright  2026 HESHAN SHIBRY.
 * @license    Proprietary - All rights reserved.
 * @version    1.0.0.
 */
session_start();
require_once 'includes/functions.php';
$pdo = getDB();
$baseUrl = BASE_URL; // defined in config/database.php

if (!hasAdmin($pdo)) {
    header('Location: ' . BASE_URL . 'setup');
    exit;
}

// Variables required by shared navbar (public page – user not logged in)
$isLoggedIn = false;
$fullName = '';
$userId = 0;
$userRole = '';
$isSuperAdmin = false;
$hasGenerateReports = false;
$hasRestoreUsers = false;
?>
<!DOCTYPE html>
<html lang="en" class="h-100">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - Coming Soon | National Movement</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <link rel="stylesheet" href="assets/css/style.css">
    <style>
        body { display: flex; flex-direction: column; min-height: 100vh; }
        main { flex: 1 0 auto; }
        footer { flex-shrink: 0; }
        .coming-soon {
            background: linear-gradient(135deg, #0a2f44 0%, #1a4a6e 100%);
            color: white;
            border-radius: 28px;
        }
    </style>
</head>
<body class="bg-light d-flex flex-column min-vh-100">

    <!-- Shared navbar (public) -->
    <?php include 'includes/navbar.php'; ?>

    <main class="container my-5">
        <div class="card shadow-sm border-0 rounded-4 overflow-hidden">
            <div class="coming-soon p-5 text-center">
                <div class="mb-4">
                    <svg width="80" height="80" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round">
                        <circle cx="12" cy="12" r="10"></circle>
                        <polyline points="12 6 12 12 16 14"></polyline>
                    </svg>
                </div>
                <h1 class="display-3 fw-bold">Membership Portal</h1>
                <p class="lead mt-3">We're working hard to bring you a dedicated membership area.</p>
                <div class="mt-4">
                    <div class="alert alert-light bg-white bg-opacity-25 border-0 text-white">
                        <strong>🚀 Coming Soon!</strong> Access to membership dashboard, exclusive content, and more will be available shortly.
                    </div>
                </div>
                <div class="mt-4">
                    <a href="<?= $baseUrl ?>" class="btn btn-light btn-lg">Return Home</a>
                </div>
            </div>
        </div>
    </main>

    <!-- custom footer (public) -->
    <footer class="bg-dark text-white-50 text-center py-4 mt-auto">
        <p class="mb-0">National Movement – Login</p>
        <p class="mb-0 mt-2 small">
            &copy; <?= date('Y') ?> National Movement. All rights reserved.
        </p>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
    <script>
      document.addEventListener('click', function (event) {
          // Only run this if the screen width is mobile (less than 992px)
          if (window.innerWidth < 992) {
              const navbar = document.getElementById('navbarNav');
              const toggler = document.querySelector('.navbar-toggler');

              // Check if menu is open
              const isMenuOpen = navbar.classList.contains('show');

              // Check if the user clicked outside the menu and the hamburger button
              const isClickInside = navbar.contains(event.target) || toggler.contains(event.target);

              if (isMenuOpen && !isClickInside) {
                  const bsCollapse = new bootstrap.Collapse(navbar, {
                      toggle: false
                  });
                  bsCollapse.hide();
              }
          }
      });
    </script>
</body>
</html>
