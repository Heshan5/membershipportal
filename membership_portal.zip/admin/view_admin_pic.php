<?php
/**
 * Membership Portal.
 * View Admin Profile Picture – Displays an admin's profile picture inline.
 * Access: only logged‑in admins (can view their own picture; others cannot).
 *
 * @package    MembershipPortal.
 * @author     Heshan Shibry <heshan.shib@gmail.com>
 * @copyright  2026 HESHAN SHIBRY.
 * @license    Proprietary - All rights reserved.
 * @version    1.0.0.
 */
require_once '../includes/auth.php';
$pdo = getDB();

if (!isset($_SESSION['user_id'])) {
    die('Unauthorized');
}

$adminId = isset($_GET['id']) ? (int)$_GET['id'] : 0;
if (!$adminId) $adminId = $_SESSION['user_id']; // default to own picture

// Only allow viewing own picture or if user is super admin? For simplicity, allow own.
if ($adminId != $_SESSION['user_id']) {
    die('Unauthorized');
}

$stmt = $pdo->prepare("SELECT profile_pic FROM admins WHERE id = ?");
$stmt->execute([$adminId]);
$profilePic = $stmt->fetchColumn();

if (!$profilePic) {
    header('HTTP/1.0 404 Not Found');
    die('No profile picture');
}

$filePath = '../' . $profilePic;
if (!file_exists($filePath)) {
    header('HTTP/1.0 404 Not Found');
    die('File not found');
}

$finfo = finfo_open(FILEINFO_MIME_TYPE);
$mimeType = finfo_file($finfo, $filePath);
finfo_close($finfo);

header('Content-Type: ' . $mimeType);
header('Content-Disposition: inline; filename="admin_profile.jpg"');
header('Content-Length: ' . filesize($filePath));
readfile($filePath);
exit;
?>
