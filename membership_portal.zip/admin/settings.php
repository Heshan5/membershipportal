<?php
/**
 * Membership Portal.
 * Settings Page – Central hub for administrative tools.
 * Cards are displayed based on user permissions.
 *
 * @package    MembershipPortal.
 * @author     Heshan Shibry <heshan.shib@gmail.com>
 * @copyright  2026 HESHAN SHIBRY.
 * @license    Proprietary - All rights reserved.
 * @version    1.0.0.
 */
require_once '../includes/auth.php';
$pdo = getDB();
validateAdminSession($pdo);

// Fetch profile picture for navbar avatar
$stmt = $pdo->prepare("SELECT profile_pic FROM admins WHERE id = ?");
$stmt->execute([$_SESSION['user_id']]);
$avatarPic = $stmt->fetchColumn();

$isSuperAdmin = ($_SESSION['is_super_admin'] == 1);
$isPrimary = ($_SESSION['user_id'] == 1);

// Permission checks for each card
$canRestore = hasPermission('restore_users') || $isPrimary;
$canManagePermissions = $isPrimary;
$canViewDeletedReport = hasPermission('generate_reports');
$canViewErrorLogs = $isPrimary;

// If user has no access to any card, redirect to dashboard
if (!$canRestore && !$canManagePermissions && !$canViewDeletedReport && !$canViewErrorLogs) {
    redirect('admin/dashboard');
}

// Navbar variables
$isLoggedIn = true;
$userRole = $_SESSION['role'];
$fullName = $_SESSION['full_name'];
$userId = $_SESSION['user_id'];
$hasGenerateReports = hasPermission('generate_reports');
$hasRestoreUsers = hasPermission('restore_users');
$baseUrl = BASE_URL;
$currentPage = 'settings';
$hideAdminLinks = false; // show all admin links
?>
<?php
// Set page title and optional custom styles
$page_title = 'Settings';
$page_styles = '
    <style>
    body { background: #f4f7fc; display: flex; flex-direction: column; min-height: 100vh; }
    main { flex: 1 0 auto; }
    footer { flex-shrink: 0; }
    .settings-card { border-radius: 20px; transition: transform 0.2s; }
    .settings-card:hover { transform: translateY(-4px); }
    .settings-icon { font-size: 2.5rem; margin-bottom: 1rem; }
    /* Fix vertical alignment of user avatar in navbar */
    .navbar .dropdown-toggle {
          display: flex !important;
          align-items: center !important;
          gap: 3px !important;
          line-height: 1 !important;
      }
      .navbar .dropdown-toggle img,
      .navbar .dropdown-toggle i {
          display: inline-block;
          vertical-align: middle;
      }
    </style>
';

// Include the global header
include '../includes/header.php';
?>

  <!-- Shared navbar (admin) -->
  <?php include '../includes/navbar.php'; ?>

    <main class="container my-5">
        <div class="row g-4">
            <?php if ($canRestore): ?>
            <!-- Restore Deleted Card -->
            <div class="col-md-6 col-lg-3">
                <div class="card settings-card shadow-sm border-0 h-100">
                    <div class="card-body text-center p-4">
                        <div class="settings-icon text-primary"><i class="bi bi-arrow-repeat"></i></div>
                        <h5 class="card-title">Restore Deleted</h5>
                        <p class="card-text text-muted">View and restore deleted members or admins (soft delete).</p>
                        <a href="<?= BASE_URL ?>admin/restore" class="btn btn-primary">Go to Restore</a>
                    </div>
                </div>
            </div>
            <?php endif; ?>

            <?php if ($canManagePermissions): ?>
            <!-- Manage Permissions Card -->
            <div class="col-md-6 col-lg-3">
                <div class="card settings-card shadow-sm border-0 h-100">
                    <div class="card-body text-center p-4">
                        <div class="settings-icon text-success"><i class="bi bi-shield-lock"></i></div>
                        <h5 class="card-title">Permissions</h5>
                        <p class="card-text text-muted">Add, edit, or delete system permissions (developer use).</p>
                        <a href="<?= BASE_URL ?>admin/manage_permissions" class="btn btn-success">Go to Permissions</a>
                    </div>
                </div>
            </div>
            <?php endif; ?>

            <?php if ($canViewDeletedReport): ?>
            <!-- Deleted Records Report Card -->
            <div class="col-md-6 col-lg-3">
                <div class="card settings-card shadow-sm border-0 h-100">
                    <div class="card-body text-center p-4">
                        <div class="settings-icon text-warning"><i class="bi bi-file-text"></i></div>
                        <h5 class="card-title">Deleted Report</h5>
                        <p class="card-text text-muted">View and export logs of deleted members, admins, and restores.</p>
                        <a href="<?= BASE_URL ?>admin/deleted_reports" class="btn btn-warning">Go to Report</a>
                    </div>
                </div>
            </div>
            <?php endif; ?>

            <?php if ($canViewErrorLogs): ?>
            <!-- Error Logs Card -->
            <div class="col-md-6 col-lg-3">
                <div class="card settings-card shadow-sm border-0 h-100">
                    <div class="card-body text-center p-4">
                        <div class="settings-icon text-danger"><i class="bi bi-bug"></i></div>
                        <h5 class="card-title">Error Logs</h5>
                        <p class="card-text text-muted">View system error logs, download full log, or clear the log.</p>
                        <a href="<?= BASE_URL ?>admin/view_logs" class="btn btn-danger">View Logs</a>
                    </div>
                </div>
            </div>
            <?php endif; ?>
        </div>
    </main>

    <!-- footer (admin) includes report issue modal -->
    <?php include '../includes/footer_admin.php'; ?>
