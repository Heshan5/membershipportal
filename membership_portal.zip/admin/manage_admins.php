<?php
/**
 * Membership Portal.
 * Manage Administrators (Primary Admin & Super Admins).
 * - Primary admin (id=1): full control: create, edit permissions, delete ANY admin.
 * - Secondary super admins (is_super_admin=1, id≠1): can create, delete and restore regular admins (not super admins).
 * - Create Admin: only Full Name and Email are required. District, province, city, gender are optional (NULL initially).
 * - New admins have 1 hour to log in and change password, otherwise account is deleted.
 * - Soft delete: deleted admins are moved to deleted_admins table (audit trail, restorable).
 * - **UPDATED:** Admin table displays province, district, city, gender.
 * - **UPDATED:** Delete operation copies province, district, city, city_id, gender, gender_custom into deleted_admins.
 *
 * @package    MembershipPortal.
 * @author     Heshan Shibry <heshan.shib@gmail.com>
 * @copyright  2026 HESHAN SHIBRY.
 * @license    Proprietary - All rights reserved.
 * @version    1.0.0.
 */
require_once '../includes/auth.php';
$pdo = getDB();
validateAdminSession($pdo);
// Fetch profile picture for navbar avatar
$stmt = $pdo->prepare("SELECT profile_pic FROM admins WHERE id = ?");
$stmt->execute([$_SESSION['user_id']]);
$avatarPic = $stmt->fetchColumn();

// Variables required by shared navbar
$isLoggedIn = true;
$userRole = $_SESSION['role'];
$fullName = $_SESSION['full_name'];
$userId = $_SESSION['user_id'];
$hasGenerateReports = hasPermission('generate_reports');
$hasRestoreUsers = hasPermission('restore_users');
$baseUrl = BASE_URL; // defined in config/database.php

if (!isset($_SESSION['user_id']) || ($_SESSION['user_id'] != 1 && $_SESSION['is_super_admin'] != 1)) {
    redirect('');
}

$isPrimary = ($_SESSION['user_id'] == 1);
$isSuperAdmin = ($_SESSION['is_super_admin'] == 1);
$canCreateSuperAdmin = $isPrimary;

$error = '';
$success = '';

// Fetch all roles for dropdowns
$rolesList = $pdo->query("SELECT id, name FROM roles ORDER BY id")->fetchAll();

// ========== UPDATED: SELECT now includes province, city, city_id, gender, gender_custom ==========
// Fetch admins based on user type, with geographic and gender columns
if ($isPrimary) {
    $sql = "SELECT a.id, a.admin_id, a.full_name, a.email,
                   a.district, a.province, a.city, a.city_id, a.phone,
                   a.is_super_admin, a.created_at, a.force_password_change,
                   a.gender, a.gender_custom,
                   GROUP_CONCAT(r.name SEPARATOR ', ') AS roles_names,
                   GROUP_CONCAT(r.id SEPARATOR ',') AS role_ids
            FROM admins a
            LEFT JOIN admin_roles ar ON a.id = ar.admin_id
            LEFT JOIN roles r ON ar.role_id = r.id
            WHERE a.id != 1
            GROUP BY a.id
            ORDER BY a.id ASC";
    $stmt = $pdo->prepare($sql);
    $stmt->execute();
} else {
    $sql = "SELECT a.id, a.admin_id, a.full_name, a.email,
                   a.district, a.province, a.city, a.city_id, a.phone,
                   a.is_super_admin, a.created_at, a.force_password_change,
                   a.gender, a.gender_custom,
                   GROUP_CONCAT(r.name SEPARATOR ', ') AS roles_names,
                   GROUP_CONCAT(r.id SEPARATOR ',') AS role_ids
            FROM admins a
            LEFT JOIN admin_roles ar ON a.id = ar.admin_id
            LEFT JOIN roles r ON ar.role_id = r.id
            WHERE a.id != :self_id AND a.is_super_admin = 0
            GROUP BY a.id
            ORDER BY a.id ASC";
    $stmt = $pdo->prepare($sql);
    $stmt->execute([':self_id' => $_SESSION['user_id']]);
}
$admins = $stmt->fetchAll();

// Handle POST actions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    if ($action === 'create') {
        $full_name = sanitize($_POST['full_name']);
        $email = sanitize($_POST['email']);
        // Geographic and gender fields are not collected from the form; set to NULL
        $district = NULL;
        $phone = NULL;
        $selectedRoles = $_POST['roles'] ?? [];
        $isSuper = ($canCreateSuperAdmin && isset($_POST['is_super_admin']) && $_POST['is_super_admin'] == 1) ? 1 : 0;

        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $error = "Invalid email format. Please enter a valid email address.";
        } elseif (empty($full_name) || empty($email)) {
            $error = "Full Name and Email are required.";
        } else {
            $plainPassword = generateRandomPassword(12);
            $hashed = password_hash($plainPassword, PASSWORD_DEFAULT);
            $admin_id = generateAdminId($pdo);
            $tempExpires = time() + 3600;
            $createdAt = utcNow();

            // Insert with district, province, city, gender as NULL
            $stmt = $pdo->prepare("INSERT INTO admins (admin_id, full_name, email, password, district, phone, role, is_super_admin, force_password_change, temp_password_expires, created_at) VALUES (?, ?, ?, ?, ?, ?, 'secondary', ?, 1, ?, ?)");
            if ($stmt->execute([$admin_id, $full_name, $email, $hashed, $district, $phone, $isSuper, $tempExpires, $createdAt])) {
                $adminDbId = $pdo->lastInsertId();
                if (!empty($selectedRoles)) {
                    $roleStmt = $pdo->prepare("INSERT INTO admin_roles (admin_id, role_id) VALUES (?, ?)");
                    foreach ($selectedRoles as $roleId) {
                        $roleStmt->execute([$adminDbId, $roleId]);
                    }
                }
                // --- Hybrid email sending (unchanged) ---
                $loginLink = "http://" . $_SERVER['HTTP_HOST'] . BASE_URL . "admin";
                $subject = "Your Admin Account for National Movement – Action Required";
                $message = "Hello $full_name,\n\n";
                $message .= "An admin account has been created for you.\n\n";
                $message .= "Login Link: $loginLink\n";
                $message .= "Login Email: $email\n";
                $message .= "Temporary Password: $plainPassword\n\n";
                $message .= "⚠️ IMPORTANT: This account will expire in 1 hour if you don't login to Activate your Account.\n";
                $message .= "Please log in immediately and change your password for security.\n\n";
                $message .= "After logging in, you will be required to set a new password.\n\n";
                $message .= "If you did not expect this, please ignore this email.\n\n";
                $message .= "Regards,\nNational Movement Team";

                $result = sendEmail($email, $subject, $message, $full_name);
                if ($result['success']) {
                    $success = "Admin created successfully. A temporary password has been sent to $email. The account expires in 1 hour if not activated.";
                } else {
                    if (function_exists('queueEmail')) {
                        $queued = queueEmail($email, $subject, $message, $full_name);
                        if ($queued) {
                            $success = "Admin created successfully. A temporary password could not be sent immediately, but it has been queued and will be delivered shortly. The account expires in 1 hour if not activated.";
                        } else {
                            $error = "Admin created but email could not be sent or queued. Temporary password: $plainPassword (save this). Account expires in 1 hour.";
                        }
                    } else {
                        $error = "Admin created but email failed. Temporary password: $plainPassword (save this). Account expires in 1 hour.";
                    }
                }
                // Refresh list
                if ($isPrimary) {
                    $stmt = $pdo->prepare("SELECT a.id, a.admin_id, a.full_name, a.email, a.district, a.province, a.city, a.city_id, a.phone, a.is_super_admin, a.created_at, a.force_password_change, a.gender, a.gender_custom, GROUP_CONCAT(r.name SEPARATOR ', ') AS roles_names, GROUP_CONCAT(r.id SEPARATOR ',') AS role_ids FROM admins a LEFT JOIN admin_roles ar ON a.id = ar.admin_id LEFT JOIN roles r ON ar.role_id = r.id WHERE a.id != 1 GROUP BY a.id ORDER BY a.id ASC");
                    $stmt->execute();
                    $admins = $stmt->fetchAll();
                } else {
                    $stmt = $pdo->prepare("SELECT a.id, a.admin_id, a.full_name, a.email, a.district, a.province, a.city, a.city_id, a.phone, a.is_super_admin, a.created_at, a.force_password_change, a.gender, a.gender_custom, GROUP_CONCAT(r.name SEPARATOR ', ') AS roles_names, GROUP_CONCAT(r.id SEPARATOR ',') AS role_ids FROM admins a LEFT JOIN admin_roles ar ON a.id = ar.admin_id LEFT JOIN roles r ON ar.role_id = r.id WHERE a.id != :self_id AND a.is_super_admin = 0 GROUP BY a.id ORDER BY a.id ASC");
                    $stmt->execute([':self_id' => $_SESSION['user_id']]);
                    $admins = $stmt->fetchAll();
                }
            } else {
                $error = "Failed to create admin.";
            }
        }
    } elseif ($action === 'update_roles_modal') {
        // Update roles for an admin (unchanged)
        $adminId = (int)$_POST['admin_id'];
        $stmt = $pdo->prepare("SELECT is_super_admin FROM admins WHERE id = ?");
        $stmt->execute([$adminId]);
        $targetIsSuper = $stmt->fetchColumn();

        if ($targetIsSuper && !$isPrimary) {
            $error = "You cannot modify a super admin.";
        } else {
            if ($isPrimary && $adminId != 1) {
                $newSuper = isset($_POST['is_super_admin']) ? 1 : 0;
                $stmtSuper = $pdo->prepare("UPDATE admins SET is_super_admin = ? WHERE id = ?");
                $stmtSuper->execute([$newSuper, $adminId]);
            }

            $selectedRoles = $_POST['roles'] ?? [];
            $pdo->prepare("DELETE FROM admin_roles WHERE admin_id = ?")->execute([$adminId]);
            if (!empty($selectedRoles)) {
                $roleStmt = $pdo->prepare("INSERT INTO admin_roles (admin_id, role_id) VALUES (?, ?)");
                foreach ($selectedRoles as $roleId) {
                    $roleStmt->execute([$adminId, $roleId]);
                }
            }
            $success = "Roles updated.";
            // Refresh list
            if ($isPrimary) {
                $stmt = $pdo->prepare("SELECT a.id, a.admin_id, a.full_name, a.email, a.district, a.province, a.city, a.city_id, a.phone, a.is_super_admin, a.created_at, a.force_password_change, a.gender, a.gender_custom, GROUP_CONCAT(r.name SEPARATOR ', ') AS roles_names, GROUP_CONCAT(r.id SEPARATOR ',') AS role_ids FROM admins a LEFT JOIN admin_roles ar ON a.id = ar.admin_id LEFT JOIN roles r ON ar.role_id = r.id WHERE a.id != 1 GROUP BY a.id ORDER BY a.id ASC");
                $stmt->execute();
                $admins = $stmt->fetchAll();
            } else {
                $stmt = $pdo->prepare("SELECT a.id, a.admin_id, a.full_name, a.email, a.district, a.province, a.city, a.city_id, a.phone, a.is_super_admin, a.created_at, a.force_password_change, a.gender, a.gender_custom, GROUP_CONCAT(r.name SEPARATOR ', ') AS roles_names, GROUP_CONCAT(r.id SEPARATOR ',') AS role_ids FROM admins a LEFT JOIN admin_roles ar ON a.id = ar.admin_id LEFT JOIN roles r ON ar.role_id = r.id WHERE a.id != :self_id AND a.is_super_admin = 0 GROUP BY a.id ORDER BY a.id ASC");
                $stmt->execute([':self_id' => $_SESSION['user_id']]);
                $admins = $stmt->fetchAll();
            }
        }
    } elseif ($action === 'delete') {
        // Soft delete an admin – copy all fields (including gender) to deleted_admins
        $adminId = (int)$_POST['admin_id'];
        $reason = isset($_POST['reason']) ? sanitizePlain($_POST['reason']) : '';
        $tzOffset = isset($_POST['tz_offset']) ? (int)$_POST['tz_offset'] : null;

        $canPerformDelete = false;
        if ($isPrimary) {
            $canPerformDelete = true;
        } elseif ($isSuperAdmin) {
            $stmtCheck = $pdo->prepare("SELECT is_super_admin FROM admins WHERE id = ?");
            $stmtCheck->execute([$adminId]);
            $targetIsSuper = $stmtCheck->fetchColumn();
            if ($targetIsSuper === 0) {
                $canPerformDelete = true;
            }
        }

        if (!$canPerformDelete) {
            $error = "You do not have permission to delete this admin.";
        } elseif ($adminId == $_SESSION['user_id'] || $adminId == 1) {
            $error = "Cannot delete this admin.";
        } elseif (empty($reason)) {
            $error = "Please provide a reason for deletion.";
        } else {
            $stmt = $pdo->prepare("SELECT * FROM admins WHERE id = ?");
            $stmt->execute([$adminId]);
            $admin = $stmt->fetch();
            if ($admin) {
                if (!$isPrimary && $admin['is_super_admin'] == 1) {
                    $error = "You cannot delete a super admin.";
                } else {
                    $deletedAdminType = $admin['is_super_admin'] ? 'Super Admin' : 'Regular Admin';
                    $deletedAt = utcNow();

                    // INSERT into deleted_admins – copy all columns including gender
                    $stmtDel = $pdo->prepare("
                        INSERT INTO deleted_admins
                            (original_id, admin_id, full_name, email, password, district, province, city, city_id,
                             phone, address, profile_pic, role, permissions, force_password_change,
                             is_super_admin, temp_password_expires, created_at, deleted_at, deleted_by, reason,
                             gender, gender_custom)
                        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                    ");
                    $stmtDel->execute([
                        $admin['id'],
                        $admin['admin_id'],
                        $admin['full_name'],
                        $admin['email'],
                        $admin['password'],
                        $admin['district'],
                        $admin['province'],
                        $admin['city'],
                        $admin['city_id'],
                        $admin['phone'],
                        $admin['address'],
                        $admin['profile_pic'],
                        $admin['role'],
                        $admin['permissions'],
                        $admin['force_password_change'],
                        $admin['is_super_admin'],
                        $admin['temp_password_expires'],
                        $admin['created_at'],
                        $deletedAt,
                        $_SESSION['user_id'],
                        $reason,
                        $admin['gender'],
                        $admin['gender_custom']
                    ]);

                    $pdo->prepare("DELETE FROM admins WHERE id = ?")->execute([$adminId]);

                    if (function_exists('sendDeletionNotification')) {
                        sendDeletionNotification('Admin', $admin['full_name'], $admin['admin_id'], $_SESSION['full_name'], $reason, $tzOffset, $deletedAdminType);
                    }
                    $success = "Admin deleted successfully (moved to trash).";
                }
            } else {
                $error = "Admin not found.";
            }
            // Refresh list
            if ($isPrimary) {
                $stmt = $pdo->prepare("SELECT a.id, a.admin_id, a.full_name, a.email, a.district, a.province, a.city, a.city_id, a.phone, a.is_super_admin, a.created_at, a.force_password_change, a.gender, a.gender_custom, GROUP_CONCAT(r.name SEPARATOR ', ') AS roles_names, GROUP_CONCAT(r.id SEPARATOR ',') AS role_ids FROM admins a LEFT JOIN admin_roles ar ON a.id = ar.admin_id LEFT JOIN roles r ON ar.role_id = r.id WHERE a.id != 1 GROUP BY a.id ORDER BY a.id ASC");
                $stmt->execute();
                $admins = $stmt->fetchAll();
            } else {
                $stmt = $pdo->prepare("SELECT a.id, a.admin_id, a.full_name, a.email, a.district, a.province, a.city, a.city_id, a.phone, a.is_super_admin, a.created_at, a.force_password_change, a.gender, a.gender_custom, GROUP_CONCAT(r.name SEPARATOR ', ') AS roles_names, GROUP_CONCAT(r.id SEPARATOR ',') AS role_ids FROM admins a LEFT JOIN admin_roles ar ON a.id = ar.admin_id LEFT JOIN roles r ON ar.role_id = r.id WHERE a.id != :self_id AND a.is_super_admin = 0 GROUP BY a.id ORDER BY a.id ASC");
                $stmt->execute([':self_id' => $_SESSION['user_id']]);
                $admins = $stmt->fetchAll();
            }
        }
    }
}
?>
<?php
$page_title = 'Manage Admins';
$page_styles = '
    <style>
    body { display: flex; flex-direction: column; min-height: 100vh; }
    main { flex: 1 0 auto; }
    footer { flex-shrink: 0; }
    .role-dropdown-menu {
        max-height: 260px;
        overflow-y: auto;
        padding: 12px;
        min-width: 260px;
    }
    .role-dropdown-menu .form-check {
        display: flex;
        align-items: center;
        margin-bottom: 10px;
        padding-left: 0;
    }
    .role-dropdown-menu .form-check-input {
        margin: 0 8px 0 0;
        float: none;
        flex-shrink: 0;
    }
    .modal-body .form-check {
        display: flex;
        align-items: center;
        margin-bottom: 8px;
        padding-left: 0 !important;
    }
    .modal-body .form-check-input {
        margin: 0 8px 0 0 !important;
        float: none !important;
        position: static !important;
        flex-shrink: 0;
    }
    .modal-body .form-check-label {
        margin-left: 0 !important;
        font-weight: normal;
    }
    .navbar .dropdown-toggle {
          display: flex !important;
          align-items: center !important;
          gap: 3px !important;
          line-height: 1 !important;
      }
      .navbar .dropdown-toggle img,
      .navbar .dropdown-toggle i {
          display: inline-block;
          vertical-align: middle;
      }
      select.form-select {
          cursor: pointer;
      }
    </style>
';

// Include the global header
include '../includes/header.php';
?>

  <!-- Shared navbar (admin) -->
  <?php $currentPage = 'manage_admins';
    include '../includes/navbar.php';
  ?>

    <main class="container my-5">
      <!-- ========== ERROR ALERT ========== -->
        <?php if ($error): ?>
            <div class="alert alert-danger d-flex align-items-center border-0 border-start border-4 border-danger shadow-sm mb-4" role="alert">
                <!-- Modern Bootstrap SVG Exclamation Warning Icon -->
                <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="currentColor" class="bi bi-exclamation-triangle-fill me-3 flex-shrink-0" viewBox="0 0 16 16">
                    <path d="M8.982 1.566a1.13 1.13 0 0 0-1.96 0L.165 13.233c-.457.778.091 1.767.98 1.767h13.713c.889 0 1.438-.99.98-1.767zM8 5c.535 0 .954.462.9.995l-.35 3.507a.552.552 0 0 1-1.1 0L7.1 5.995A.905.905 0 0 1 8 5m.002 6a1 1 0 1 1 0 2 1 1 0 0 1 0-2"/>
                </svg>
                <div class="small fw-semibold"><?= $error ?></div>
            </div>
        <?php endif; ?>

        <!-- ========== SUCCESS ALERT ========== -->
        <?php if ($success): ?>
            <div class="alert alert-success d-flex align-items-center alert-dismissible fade show border-0 border-start border-4 border-success shadow-sm mb-4" role="alert">
                <!-- Modern Bootstrap SVG Check Circle Icon -->
                <svg xmlns="http://www.w3.org/2000/svg" width="22" height="22" fill="currentColor" class="bi bi-check-circle-fill me-3 flex-shrink-0" viewBox="0 0 16 16">
                    <path d="M16 8A8 8 0 1 1 0 8a8 8 0 0 1 16 0m-3.97-3.03a.75.75 0 0 0-1.08.022L7.477 9.417 5.384 7.323a.75.75 0 0 0-1.06 1.06L6.97 11.03a.75.75 0 0 0 1.079-.02l3.992-4.99a.75.75 0 0 0-.01-1.05z"/>
                </svg>
                <div class="small fw-semibold"><?= $success ?></div>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php endif; ?>

        <!-- ========== RESTRICTION ALERT (GET PARAMETER ACTION) ========== -->
        <?php if (isset($_GET['error']) && $_GET['error'] == 'cannot_edit_super'): ?>
            <div class="alert alert-warning d-flex align-items-center alert-dismissible fade show border-0 border-start border-4 border-warning shadow-sm mb-4" role="alert">
                <!-- Modern Bootstrap SVG Shield Lock Icon for Role Access Restrictions -->
                <svg xmlns="http://www.w3.org/2000/svg" width="22" height="22" fill="currentColor" class="bi bi-shield-lock-fill me-3 flex-shrink-0" viewBox="0 0 16 16">
                    <path fill-rule="evenodd" d="M8 0c-.69 0-1.843.265-2.928.56-1.11.3-2.229.655-2.887.87a1.54 1.54 0 0 0-1.044 1.262c-.596 4.477.787 7.795 2.465 9.99a11.8 11.8 0 0 0 2.517 2.453c.386.273.744.482 1.048.625.28.132.581.24.829.24s.548-.108.829-.24a7 7 0 0 0 1.048-.625 11.8 11.8 0 0 0 2.517-2.453c1.678-2.195 3.061-5.513 2.465-9.99a1.54 1.54 0 0 0-1.044-1.263 63 63 0 0 0-2.887-.87C9.843.266 8.69 0 8 0m0 5a1.5 1.5 0 0 1 .5 2.915V9.5a.5.5 0 0 1-1 0V7.915A1.5 1.5 0 0 1 8 5"/>
                </svg>
                <div class="small fw-semibold">You are not allowed to edit super admins.</div>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php endif; ?>

        <!-- Create New Admin Form (only Full Name and Email) -->
        <div class="card shadow-sm border-0 rounded-4 mb-4">
            <div class="card-body p-4">
                <h3 class="card-title mb-3"><i class="bi bi-person-plus-fill"></i> Create New Admin</h3>
                <form method="POST" id="createAdminForm">
                    <input type="hidden" name="action" value="create">
                    <div class="row">
                        <div class="col-md-5 mb-3">
                            <label class="form-label fw-semibold">Full Name *</label>
                            <input type="text" name="full_name" class="form-control" required>
                        </div>
                        <div class="col-md-5 mb-3">
                            <label class="form-label fw-semibold">Email *</label>
                            <input type="email" name="email" class="form-control" required>
                        </div>
                    </div>
                    <div class="mb-3">
                        <label class="form-label fw-semibold">Assign Roles (for Regular Admins)</label>
                          <div class="col-md-3 mb-3 dropdown">
                              <button class="btn btn-outline-secondary dropdown-toggle w-100 text-start" type="button" data-bs-toggle="dropdown" data-bs-auto-close="outside" aria-expanded="false" id="roleDropdownBtn">
                                  <span id="selectedRolesText">Select roles...</span>
                              </button>
                            <div class="dropdown-menu role-dropdown-menu p-2 w-100">
                                <?php foreach ($rolesList as $role): ?>
                                    <div class="form-check">
                                        <input class="form-check-input role-checkbox" style="cursor: pointer;" type="checkbox" name="roles[]" value="<?= $role['id'] ?>" id="create_role_<?= $role['id'] ?>">
                                        <label class="form-check-label" for="create_role_<?= $role['id'] ?>" style="cursor: pointer; width: 100%;">
                                            <?= htmlspecialchars($role['name']) ?>
                                        </label>
                                    </div>
                                <?php endforeach; ?>
                            </div>
                        </div>
                        <?php if ($canCreateSuperAdmin): ?>
                        <small class="text-muted">Select the permissions for a regular admin. These will be ignored if you make the admin a Super Admin below.</small>
                        <?php endif; ?>
                    </div>
                    <?php if ($canCreateSuperAdmin): ?>
                      <div class="mb-3 p-3 border rounded bg-light">
                        <label class="form-label fw-semibold">⭐ Super Admin Privileges (Optional)</label>
                        <div class="d-flex align-items-center gap-2 mt-2">
                            <input type="checkbox" class="form-check-input m-0" name="is_super_admin" id="is_super_admin" value="1" style="cursor: pointer;">
                            <label class="form-check-label" for="is_super_admin">
                                <i class="bi bi-star-fill text-warning"></i> Make this admin a Super Admin
                            </label>
                        </div>
                        <div id="superAdminHelp" class="form-text text-muted" style="display: none;">
                            <i class="bi bi-info-circle"></i> Super admins automatically have <strong>all permissions</strong> but <strong>cannot delete other admins</strong>. Role selection above is ignored.
                        </div>
                        <small class="text-muted">Check this box only if you want to grant full system access (except admin deletion).</small>
                      </div>
                    <?php endif; ?>
                    <button type="submit" class="btn btn-dark"><i class="bi bi-save"></i> Create Admin</button>
                </form>
                <hr>
                <small class="text-muted"><i class="bi bi-envelope-paper-fill"></i> A temporary password will be generated and sent to the admin's email. They will be required to change it on first login.</small>
            </div>
        </div>

        <!-- ========== UPDATED TABLE: Now includes Province, District, City, Gender ========== -->
        <div class="card shadow-sm border-0 rounded-4">
            <div class="card-body p-4">
                <h3 class="card-title mb-3"><i class="bi bi-person-badge-fill"></i> Existing Administrators (excluding primary)</h3>
                <div class="table-responsive">
                    <table class="table table-hover align-middle custom-admin-table">
                        <thead class="table-light">
                            <tr>
                                <th class="ps-3">ID</th>
                                <th>Admin ID</th>
                                <th>Full Name</th>
                                <th>Email</th>
                                <th>Province</th>
                                <th>District</th>
                                <th>City/Town</th>
                                <th>Phone</th>
                                <th>Gender</th>
                                <th>Admin Type</th>
                                <th>Roles</th>
                                <th>Status</th>
                                <th>Registered On</th>
                                <th class="text-end pe-3">Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($admins as $admin): ?>
                            <tr>
                                <td class="ps-3 text-muted small">#<?= $admin['id'] ?></td>
                                <td><span class="badge bg-light text-dark border fw-medium"><?= htmlspecialchars($admin['admin_id']) ?></span></td>
                                <td class="fw-bold text-dark"><?= htmlspecialchars($admin['full_name']) ?></td>
                                <td class="text-secondary small"><?= htmlspecialchars($admin['email']) ?></td>
                                <td><?= htmlspecialchars($admin['province'] ?: '-') ?></td>
                                <td><?= htmlspecialchars($admin['district'] ?: '-') ?></td>
                                <td><?= htmlspecialchars($admin['city'] ?: '-') ?></td>
                                <td><?= htmlspecialchars($admin['phone'] ?: '-') ?></td>
                                <td>
                                    <?php
                                    if (!empty($admin['gender'])) {
                                        $genderDisplay = htmlspecialchars($admin['gender']);
                                        if ($admin['gender'] == 'Other' && !empty($admin['gender_custom'])) {
                                            $genderDisplay .= ' (' . htmlspecialchars($admin['gender_custom']) . ')';
                                        }
                                        echo $genderDisplay;
                                    } else {
                                        echo '-';
                                    }
                                    ?>
                                </td>
                                <td>
                                    <?php if ($admin['is_super_admin']): ?>
                                        <span class="badge rounded-pill bg-info-subtle text-info border border-info px-2">
                                            <i class="bi bi-star-fill small"></i> Super Admin
                                        </span>
                                    <?php else: ?>
                                        <span class="badge rounded-pill bg-secondary-subtle text-secondary border border-secondary px-2">Regular Admin</span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <span class="text-muted small fw-medium role-tag-container">
                                        <?= htmlspecialchars($admin['roles_names'] ?: 'None') ?>
                                    </span>
                                </td>
                                <td>
                                    <?php if ($admin['force_password_change'] == 1): ?>
                                        <span class="badge rounded-pill bg-warning text-dark">
                                            <i class="bi bi-clock-history"></i> Pending
                                        </span>
                                    <?php else: ?>
                                        <span class="badge rounded-pill bg-success">
                                            <i class="bi bi-check-circle-fill"></i> Active
                                        </span>
                                    <?php endif; ?>
                                </td>
                                <td data-utc-time="<?= $admin['created_at'] ?>"><?= $admin['created_at'] ?></td>
                                <td class="text-end pe-3">
                                    <div class="d-flex justify-content-end gap-2">
                                      <?php if ($admin['force_password_change'] == 1): ?>
                                        <button class="btn btn-sm btn-outline-secondary rounded-pill px-3" disabled title="Admin has not activated their account yet">
                                            <i class="bi bi-pencil-square"></i> Info
                                        </button>
                                      <?php else: ?>
                                        <a href="edit_other_admin?id=<?= $admin['id'] ?>" class="btn btn-sm btn-outline-info rounded-pill px-3">
                                            <i class="bi bi-pencil-square"></i> Info
                                        </a>
                                      <?php endif; ?>

                                        <button type="button" class="btn btn-sm btn-outline-primary rounded-pill px-3 btn-edit-roles"
                                            data-bs-toggle="modal" data-bs-target="#editRolesModal"
                                            data-admin-id="<?= $admin['id'] ?>"
                                            data-admin-name="<?= htmlspecialchars($admin['full_name']) ?>"
                                            data-role-ids="<?= $admin['role_ids'] ?>"
                                            data-is-super="<?= $admin['is_super_admin'] ?>">
                                            <i class="bi bi-shield-lock"></i> Roles
                                        </button>

                                        <?php
                                        $showDelete = false;
                                        if ($isPrimary) {
                                            $showDelete = true;
                                        } elseif ($isSuperAdmin && !$admin['is_super_admin']) {
                                            $showDelete = true;
                                        }
                                        if ($showDelete && $admin['id'] != $_SESSION['user_id'] && $admin['id'] != 1):
                                        ?>
                                          <button type="button" class="btn btn-sm btn-outline-danger rounded-pill px-3"
                                              data-bs-toggle="modal" data-bs-target="#deleteAdminModal"
                                              data-admin-id="<?= $admin['id'] ?>"
                                              data-admin-name="<?= htmlspecialchars($admin['full_name']) ?>"
                                              data-admin-id-display="<?= htmlspecialchars($admin['admin_id']) ?>">
                                              <i class="bi bi-trash"></i> Delete
                                          </button>
                                        <?php endif; ?>
                                    </div>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                            <?php if (count($admins) === 0): ?>
                                <tr>
                                    <td colspan="14" class="text-center text-muted">No administrators found.</td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </main>

    <!-- Modal for Editing Roles (unchanged) -->
    <div class="modal fade" id="editRolesModal" tabindex="-1" aria-labelledby="editRolesModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <form method="POST">
                    <input type="hidden" name="action" value="update_roles_modal">
                    <input type="hidden" name="admin_id" id="modal_admin_id" value="">
                    <div class="modal-header bg-dark text-white">
                        <h5 class="modal-title" id="editRolesModalLabel"><i class="bi bi-person-gear"></i> Edit Roles for <span id="modal_admin_name"></span></h5>
                        <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                    </div>
                    <div class="modal-body">
                        <p>Select roles for this administrator:</p>

                        <?php if ($isPrimary): ?>
                            <div class="mb-3 p-2 bg-light rounded">
                                <div class="form-check">
                                    <input class="form-check-input" type="checkbox" name="is_super_admin" value="1" id="super_admin_modal_checkbox">
                                    <label class="form-check-label fw-bold text-primary" for="super_admin_modal_checkbox">
                                        <i class="bi bi-star-fill"></i> Super Admin
                                    </label>
                                    <div class="small text-muted mt-1">Grant full permissions (except deleting super admins). Only primary admin can assign this.</div>
                                </div>
                            </div>
                            <hr>
                        <?php endif; ?>

                        <div class="row" id="roles_checkboxes_container">
                            <?php foreach ($rolesList as $role): ?>
                                <div class="col-md-6 mb-2">
                                    <div class="form-check">
                                        <input class="form-check-input modal-role-checkbox" type="checkbox" name="roles[]" value="<?= $role['id'] ?>" id="modal_role_<?= $role['id'] ?>">
                                        <label class="form-check-label" for="modal_role_<?= $role['id'] ?>">
                                            <?= htmlspecialchars($role['name']) ?>
                                        </label>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                        <button type="submit" class="btn btn-primary">Save Changes</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- Delete Admin Modal (unchanged) -->
    <div class="modal fade" id="deleteAdminModal" tabindex="-1" aria-labelledby="deleteAdminModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <form method="POST" id="deleteAdminForm">
                    <input type="hidden" name="action" value="delete">
                    <input type="hidden" name="admin_id" id="delete_admin_id" value="">
                    <input type="hidden" name="tz_offset" id="tz_offset_admin" value="">
                    <div class="modal-header bg-danger text-white">
                        <h5 class="modal-title" id="deleteAdminModalLabel"><i class="bi bi-exclamation-triangle"></i> Confirm Deletion</h5>
                        <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                    </div>
                    <div class="modal-body">
                        <p>You are about to delete the admin:</p>
                        <p><strong id="delete_admin_name"></strong> (<span id="delete_admin_id_display"></span>)</p>
                        <p>This action will move the admin to the trash.</p>
                        <div class="mb-3">
                            <label class="form-label">Reason for deletion <span class="text-danger">*</span></label>
                            <textarea name="reason" class="form-control" rows="3" placeholder="e.g., No longer needed, role changed, etc." required></textarea>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                        <button type="submit" class="btn btn-danger">Delete Admin</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const form = document.getElementById('createAdminForm');
            if (form) {
                const submitBtn = form.querySelector('button[type="submit"]');
                form.addEventListener('submit', function() {
                    setTimeout(function() {
                        if (submitBtn && submitBtn.innerText.trim() === "Create Admin") {
                            submitBtn.innerText = "Creating Admin...";
                        }
                        if (submitBtn) {
                            submitBtn.style.opacity = "0.5";
                            submitBtn.style.pointerEvents = "none";
                        }
                    }, 0);
                });
            }
        });
    </script>

    <!-- footer (admin) includes report issue modal -->
    <?php include '../includes/footer_admin.php'; ?>
