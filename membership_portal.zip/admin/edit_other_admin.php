<?php
/**
 * Membership Portal.
 * Edit Other Admin – Allows super admins to edit basic info of another admin
 * (except permissions and password – those are handled in manage_admins.php).
 * Only primary admin can edit super admins; secondary super admins can edit regular admins only.
 * Includes email format validation.
 *
 * UPDATED: Replaced hard‑coded district dropdown with province → district → city cascade.
 * Uses database‑driven geographic data (provinces, districts, cities).
 * UPDATED: Added gender display (read‑only) – cannot be changed by the editing admin.
 *
 * @package    MembershipPortal.
 * @author     Heshan Shibry <heshan.shib@gmail.com>
 * @copyright  2026 HESHAN SHIBRY.
 * @license    Proprietary - All rights reserved.
 * @version    1.0.0.
 */
require_once '../includes/auth.php';
$pdo = getDB();
validateAdminSession($pdo);
$isSuperAdmin = ($_SESSION['is_super_admin'] == 1);
// Fetch profile picture for navbar avatar
$stmt = $pdo->prepare("SELECT profile_pic FROM admins WHERE id = ?");
$stmt->execute([$_SESSION['user_id']]);
$avatarPic = $stmt->fetchColumn();

if (!isset($_SESSION['user_id']) || !hasPermission(PERM_MANAGE_ADMINS)) {
    redirect('');
}

$adminId = (int)$_GET['id'];
$currentUserId = $_SESSION['user_id'];
$isPrimary = ($currentUserId == 1);

// Cannot edit primary admin (id=1) unless you are primary yourself
if ($adminId == 1 && !$isPrimary) {
    redirect('admin/manage_admins?error=not_allowed');
}
// Cannot edit yourself – use own profile page
if ($adminId == $currentUserId) {
    redirect('admin/profile');
}

// Fetch admin data
$stmt = $pdo->prepare("SELECT * FROM admins WHERE id = ? AND role = 'secondary'");
$stmt->execute([$adminId]);
$admin = $stmt->fetch();
if (!$admin) {
    redirect('admin/manage_admins?error=not_found');
}

// Only primary can edit super admins
if ($admin['is_super_admin'] == 1 && !$isPrimary) {
    redirect('admin/manage_admins?error=cannot_edit_super');
}

// Get current geographic IDs from the stored city_id
$current_city_id = (int)$admin['city_id'];
$current_province_id = 0;
$current_district_id = 0;
if ($current_city_id) {
    $loc = $pdo->prepare("
        SELECT p.id as province_id, d.id as district_id
        FROM cities c
        JOIN districts d ON c.district_id = d.id
        JOIN provinces p ON d.province_id = p.id
        WHERE c.id = ?
    ");
    $loc->execute([$current_city_id]);
    $locData = $loc->fetch();
    if ($locData) {
        $current_province_id = $locData['province_id'];
        $current_district_id = $locData['district_id'];
    }
}

// Fetch all provinces for the dropdown
$provinces = $pdo->query("SELECT id, name_en, name_si, name_ta FROM provinces ORDER BY name_en")->fetchAll();

// Helper to format trilingual names
function formatTrilingual($name_en, $name_si, $name_ta) {
    $text = $name_en;
    if ($name_si && $name_ta) $text .= " ($name_si / $name_ta)";
    elseif ($name_si) $text .= " ($name_si)";
    elseif ($name_ta) $text .= " ($name_ta)";
    return htmlspecialchars($text);
}

// Parse stored phone
$phone_code = '';
$phone_number = '';
if (!empty($admin['phone'])) {
    $parts = explode(' ', $admin['phone'], 2);
    $phone_code = $parts[0] ?? '';
    $phone_number = $parts[1] ?? '';
}

$message = '';
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $full_name = sanitize($_POST['full_name']);
    $email = sanitize($_POST['email']);

    // Get geographic selections
    $province_id = isset($_POST['province']) ? (int)$_POST['province'] : 0;
    $district_id = isset($_POST['district']) ? (int)$_POST['district'] : 0;
    $city_id = isset($_POST['city']) ? (int)$_POST['city'] : 0;

    // Resolve names from IDs (only if ID > 0)
    $province_name = '';
    $district_name = '';
    $city_name = '';
    if ($province_id > 0) {
        $stmt = $pdo->prepare("SELECT name_en FROM provinces WHERE id = ?");
        $stmt->execute([$province_id]);
        $province_name = $stmt->fetchColumn() ?: '';
    }
    if ($district_id > 0) {
        $stmt = $pdo->prepare("SELECT name_en FROM districts WHERE id = ?");
        $stmt->execute([$district_id]);
        $district_name = $stmt->fetchColumn() ?: '';
    }
    if ($city_id > 0) {
        $stmt = $pdo->prepare("SELECT name_en FROM cities WHERE id = ?");
        $stmt->execute([$city_id]);
        $city_name = $stmt->fetchColumn() ?: '';
    } else {
        $city_id = null; // for foreign key
    }

    $phone_code = sanitize($_POST['phone_code'] ?? '');
    $phone_number = sanitize($_POST['phone_number'] ?? '');
    $phone = !empty($phone_code) && !empty($phone_number) ? $phone_code . ' ' . $phone_number : '';
    $address = sanitize($_POST['address']);

    // Email format validation
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = "Invalid email format. Please enter a valid email address.";
    } elseif (empty($full_name) || empty($email)) {
        $error = "Full Name and Email are required.";
    } else {
        // Check email uniqueness (excluding current admin)
        $check = $pdo->prepare("SELECT id FROM admins WHERE email = ? AND id != ?");
        $check->execute([$email, $adminId]);
        if ($check->fetch()) {
            $error = "Email already used by another admin.";
        } else {
            // Update all fields, including geographic data (gender is NOT updated)
            $update = $pdo->prepare("
                UPDATE admins SET
                    full_name = ?, email = ?,
                    province = ?, district = ?, city = ?, city_id = ?,
                    phone = ?, address = ?
                WHERE id = ?
            ");
            if ($update->execute([$full_name, $email, $province_name, $district_name, $city_name, $city_id, $phone, $address, $adminId])) {
                $message = "Admin information updated successfully.";
                // Refresh data
                $stmt = $pdo->prepare("SELECT * FROM admins WHERE id = ?");
                $stmt->execute([$adminId]);
                $admin = $stmt->fetch();
                // Reparse phone
                $parts = explode(' ', $admin['phone'], 2);
                $phone_code = $parts[0] ?? '';
                $phone_number = $parts[1] ?? '';
                // Refresh current geographic IDs
                $current_city_id = (int)$admin['city_id'];
                if ($current_city_id) {
                    $loc = $pdo->prepare("
                        SELECT p.id as province_id, d.id as district_id
                        FROM cities c
                        JOIN districts d ON c.district_id = d.id
                        JOIN provinces p ON d.province_id = p.id
                        WHERE c.id = ?
                    ");
                    $loc->execute([$current_city_id]);
                    $locData = $loc->fetch();
                    if ($locData) {
                        $current_province_id = $locData['province_id'];
                        $current_district_id = $locData['district_id'];
                    }
                } else {
                    $current_province_id = 0;
                    $current_district_id = 0;
                }
            } else {
                $error = "Update failed.";
            }
        }
    }
}

// Navbar variables
$isLoggedIn = true;
$userRole = $_SESSION['role'];
$fullName = $_SESSION['full_name'];
$userId = $_SESSION['user_id'];
$hasGenerateReports = hasPermission('generate_reports');
$hasRestoreUsers = hasPermission('restore_users');
$baseUrl = BASE_URL;
$hideAdminLinks = true;               // hide Manage Admins, Manage Roles, Reports
$showBackToManageAdmins = true;       // show custom "← Manage Admins" link
?>
<?php
// Set page title and optional custom styles
$page_title = 'Edit Admin - '. htmlspecialchars($admin['full_name']);
$page_styles = '
    <style>
    body { display: flex; flex-direction: column; min-height: 100vh; }
    main { flex: 1 0 auto; }
    footer { flex-shrink: 0; }
    /* Fix vertical alignment of user avatar in navbar */
    .navbar .dropdown-toggle {
          display: flex !important;
          align-items: center !important;
          gap: 3px !important;
          line-height: 1 !important;
      }
      .navbar .dropdown-toggle img,
      .navbar .dropdown-toggle i {
          display: inline-block;
          vertical-align: middle;
      }
    select.form-select {
        cursor: pointer;
    }
    /* Truncate long text with dots (...) inside form controls */
    .form-select, .form-select option {
        text-overflow: ellipsis;
        overflow: hidden;
        white-space: nowrap;
    }
    /* Disabled fields style */
    select:disabled, input:disabled {
        background-color: #e9ecef;
        cursor: not-allowed;
    }
    </style>
';

// Include the global header
include '../includes/header.php';
?>
    <!-- Shared navbar (admin) -->
    <?php include '../includes/navbar.php'; ?>

    <main class="container my-5">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card shadow-sm border-0 rounded-4">
                    <div class="card-body p-4 p-md-5">
                        <h2 class="card-title text-center mb-4">Edit Admin: <?= htmlspecialchars($admin['full_name']) ?></h2>
                        <!-- ========== SUCCESS MESSAGE BLOCK ========== -->
                          <?php if ($message): ?>
                              <div class="alert alert-success d-flex align-items-center alert-dismissible fade show border-0 border-start border-4 border-success shadow-sm mb-4" role="alert">
                                  <!-- Modern Bootstrap SVG Check Circle Icon -->
                                  <svg xmlns="http://www.w3.org/2000/svg" width="22" height="22" fill="currentColor" class="bi bi-check-circle-fill me-3 flex-shrink-0" viewBox="0 0 16 16">
                                      <path d="M16 8A8 8 0 1 1 0 8a8 8 0 0 1 16 0m-3.97-3.03a.75.75 0 0 0-1.08.022L7.477 9.417 5.384 7.323a.75.75 0 0 0-1.06 1.06L6.97 11.03a.75.75 0 0 0 1.079-.02l3.992-4.99a.75.75 0 0 0-.01-1.05z"/>
                                  </svg>
                                  <div class="small fw-semibold">
                                      <?= $message ?>
                                  </div>
                                  <!-- Dismissible Close Button for Success States -->
                                  <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                              </div>
                          <?php endif; ?>

                          <!-- ========== ERROR MESSAGE BLOCK ========== -->
                          <?php if ($error): ?>
                              <div class="alert alert-danger d-flex align-items-center border-0 border-start border-4 border-danger shadow-sm mb-4" role="alert">
                                  <!-- Modern Bootstrap SVG Exclamation Warning Icon -->
                                  <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="currentColor" class="bi bi-exclamation-triangle-fill me-3 flex-shrink-0" viewBox="0 0 16 16">
                                      <path d="M8.982 1.566a1.13 1.13 0 0 0-1.96 0L.165 13.233c-.457.778.091 1.767.98 1.767h13.713c.889 0 1.438-.99.98-1.767zM8 5c.535 0 .954.462.9.995l-.35 3.507a.552.552 0 0 1-1.1 0L7.1 5.995A.905.905 0 0 1 8 5m.002 6a1 1 0 1 1 0 2 1 1 0 0 1 0-2"/>
                                  </svg>
                                  <div class="small fw-semibold">
                                      <?= $error ?>
                                  </div>
                              </div>
                          <?php endif; ?>
                        <form method="POST">
                            <div class="col-md-6 mb-3">
                                <label class="form-label fw-semibold">Full Name</label>
                                <input type="text" name="full_name" class="form-control" value="<?= htmlspecialchars($admin['full_name']) ?>" required>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label class="form-label fw-semibold">Email</label>
                                <input type="email" name="email" class="form-control" value="<?= htmlspecialchars($admin['email']) ?>" required>
                                <div class="invalid-feedback" id="emailFeedback"></div>
                            </div>

                            <div class="col-md-4 mb-3">
                                <label class="form-label fw-semibold">Admin ID (read-only)</label>
                                <input type="text" class="form-control bg-light" value="<?= htmlspecialchars($admin['admin_id']) ?>" readonly>
                            </div>

                            <!-- Geographic Hierarchy (Province -> District -> City) -->
                            <div class="row align-items-end g-3 mb-3">
                                <div class="col-md-4">
                                    <label class="form-label fw-semibold">Province</label>
                                    <select id="provinceSelect" name="province" class="form-select">
                                        <option value="">Select Province</option>
                                        <?php foreach ($provinces as $p): ?>
                                            <option value="<?= $p['id'] ?>" <?= ($current_province_id == $p['id']) ? 'selected' : '' ?>>
                                                <?= formatTrilingual($p['name_en'], $p['name_si'], $p['name_ta']) ?>
                                            </option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                                <div class="col-md-4">
                                    <label class="form-label fw-semibold">District</label>
                                    <select id="districtSelect" name="district" class="form-select" <?= $current_district_id ? '' : 'disabled' ?>>
                                        <option value="">Select...</option>
                                    </select>
                                </div>
                                <div class="col-md-4">
                                    <label class="form-label fw-semibold">City / Town</label>
                                    <select id="citySelect" name="city" class="form-select" <?= $current_city_id ? '' : 'disabled' ?>>
                                        <option value="">Select...</option>
                                    </select>
                                </div>
                            </div>

                            <!-- Gender Display (read‑only) -->
                              <div class="row mb-3">
                                  <div class="col-md-6">
                                      <label class="form-label fw-semibold">Gender</label>
                                      <div class="form-control bg-light">
                                          <?php
                                          if (!empty($admin['gender'])) {
                                              $gender_display = htmlspecialchars($admin['gender']);
                                              if ($admin['gender'] == 'Other' && !empty($admin['gender_custom'])) {
                                                  $gender_display .= ' (' . htmlspecialchars($admin['gender_custom']) . ')';
                                              }
                                              echo $gender_display;
                                          } else {
                                              echo 'Not specified';
                                          }
                                          ?>
                                      </div>
                                  </div>
                              </div>

                            <div class="col-md-5 mb-3">
                                <label class="form-label fw-semibold">Phone (optional)</label>
                                <div class="row g-2">
                                    <div class="col-4">
                                        <select name="phone_code" class="form-select">
                                            <option value="+94" <?= $phone_code == '+94' ? 'selected' : '' ?>>+94</option>
                                            <option value="+91" <?= $phone_code == '+91' ? 'selected' : '' ?>>+91</option>
                                            <option value="+1" <?= $phone_code == '+1' ? 'selected' : '' ?>>+1</option>
                                            <option value="+44" <?= $phone_code == '+44' ? 'selected' : '' ?>>+44</option>
                                            <option value="+61" <?= $phone_code == '+61' ? 'selected' : '' ?>>+61</option>
                                            <option value="+971" <?= $phone_code == '+971' ? 'selected' : '' ?>>+971</option>
                                        </select>
                                    </div>
                                    <div class="col-8">
                                        <input type="tel" name="phone_number" class="form-control" placeholder="712345678" pattern="[0-9]{7,10}" title="7 to 10 digits" value="<?= htmlspecialchars($phone_number) ?>">
                                    </div>
                                </div>
                                <small class="text-muted">Select country code and enter local number (without leading zero).</small>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label class="form-label fw-semibold">Address</label>
                                <textarea name="address" rows="3" class="form-control"><?= htmlspecialchars($admin['address']) ?></textarea>
                            </div>
                            <button type="submit" class="btn btn-dark w-100 py-2">Save Changes</button>
                        </form>
                        <div class="text-center mt-3">
                            <small>Note: You cannot change permissions or password here. Use Manage Admins to modify roles or delete. Gender cannot be changed – the user may update it via their own profile.</small>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </main>

    <!-- JavaScript for cascade dropdowns -->
    <script>
        // Province → District → City cascade (trilingual)
        document.addEventListener('DOMContentLoaded', function () {
            const provinceSelect = document.getElementById('provinceSelect');
            const districtSelect = document.getElementById('districtSelect');
            const citySelect = document.getElementById('citySelect');

            // Preserve current selections (from PHP)
            const currentDistrictId = <?= (int)$current_district_id ?>;
            const currentCityId = <?= (int)$current_city_id ?>;

            function formatOption(name_en, name_si, name_ta) {
                let text = name_en;
                if (name_si && name_ta) text += ` (${name_si} / ${name_ta})`;
                else if (name_si) text += ` (${name_si})`;
                else if (name_ta) text += ` (${name_ta})`;
                return text;
            }

            function loadDistricts(provinceId, selectedDistrictId = 0) {
                if (!provinceId) {
                    districtSelect.innerHTML = '<option value="">Select District</option>';
                    districtSelect.disabled = true;
                    citySelect.innerHTML = '<option value="">Select City/Town</option>';
                    citySelect.disabled = true;
                    return;
                }
                fetch(`<?= BASE_URL ?>get_locations.php?type=districts&province_id=${provinceId}`)
                    .then(res => res.json())
                    .then(data => {
                        districtSelect.innerHTML = '<option value="">Select District</option>';
                        data.forEach(item => {
                            const selected = (selectedDistrictId == item.id) ? 'selected' : '';
                            districtSelect.innerHTML += `<option value="${item.id}" ${selected}>${formatOption(item.name_en, item.name_si, item.name_ta)}</option>`;
                        });
                        districtSelect.disabled = false;
                        if (selectedDistrictId) {
                            loadCities(selectedDistrictId, currentCityId);
                        } else {
                            citySelect.innerHTML = '<option value="">Select City/Town</option>';
                            citySelect.disabled = true;
                        }
                    })
                    .catch(err => console.error(err));
            }

            function loadCities(districtId, selectedCityId = 0) {
                if (!districtId) {
                    citySelect.innerHTML = '<option value="">Select City/Town</option>';
                    citySelect.disabled = true;
                    return;
                }
                fetch(`<?= BASE_URL ?>get_locations.php?type=cities&district_id=${districtId}`)
                    .then(res => res.json())
                    .then(data => {
                        citySelect.innerHTML = '<option value="">Select City/Town</option>';
                        data.forEach(item => {
                            const selected = (selectedCityId == item.id) ? 'selected' : '';
                            citySelect.innerHTML += `<option value="${item.id}" ${selected}>${formatOption(item.name_en, item.name_si, item.name_ta)}</option>`;
                        });
                        citySelect.disabled = false;
                    })
                    .catch(err => console.error(err));
            }

            // Initial load if a province is preselected
            if (provinceSelect.value) {
                loadDistricts(provinceSelect.value, currentDistrictId);
            }

            provinceSelect.addEventListener('change', function() {
                loadDistricts(this.value, 0);
            });

            districtSelect.addEventListener('change', function() {
                loadCities(this.value, 0);
            });
        });

        /*
         * Edit Other Admin: ISOLATED SUBMIT LOCK
         * This script only runs on the profile page. It locks the button
         * to prevent double-clicking without affecting any other admin views.
         */
        document.addEventListener('DOMContentLoaded', function() {
            const form = document.querySelector('form');
            const submitBtn = document.querySelector('button[type="submit"]');

            if (form && submitBtn) {
                form.addEventListener('submit', function() {
                    setTimeout(function() {
                        // Matches your exact button text
                        if (submitBtn.innerText.trim() === "Save Changes") {
                            submitBtn.innerText = "Saving Changes...";
                        }

                        submitBtn.style.opacity = "0.5";
                        submitBtn.style.pointerEvents = "none";
                    }, 0);
                });
            }
        });
    </script>

    <!-- footer (admin) includes report issue modal -->
    <?php include '../includes/footer_admin.php'; ?>
