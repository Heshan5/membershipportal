<?php
/**
 * Membership Portal.
 * Download all documents of a member as a ZIP file.
 * Access: only admins with view_members permission.
 *
 * @package    MembershipPortal.
 * @author     Heshan Shibry <heshan.shib@gmail.com>
 * @copyright  2026 HESHAN SHIBRY.
 * @license    Proprietary - All rights reserved.
 * @version    1.0.0.
 */
require_once '../includes/auth.php';
$pdo = getDB();

if (!isset($_SESSION['user_id']) || !hasPermission(PERM_VIEW_MEMBERS)) {
    die('Unauthorized');
}

$memberId = isset($_GET['member_id']) ? (int)$_GET['member_id'] : 0;
if (!$memberId) die('Invalid member ID');

// Fetch member details
$stmt = $pdo->prepare("SELECT full_name FROM members WHERE id = ?");
$stmt->execute([$memberId]);
$member = $stmt->fetch();
if (!$member) die('Member not found');

// Fetch all documents for this member
$stmt = $pdo->prepare("SELECT document_path, document_name FROM documents WHERE member_id = ?");
$stmt->execute([$memberId]);
$docs = $stmt->fetchAll();

if (empty($docs)) {
    die('No documents found for this member.');
}

// Create ZIP file
$zip = new ZipArchive();
$zipName = 'member_' . $memberId . '_' . preg_replace('/[^a-zA-Z0-9]/', '_', $member['full_name']) . '_documents.zip';
$zipPath = sys_get_temp_dir() . '/' . $zipName;

if ($zip->open($zipPath, ZipArchive::CREATE | ZipArchive::OVERWRITE) !== true) {
    die('Could not create ZIP file.');
}

foreach ($docs as $doc) {
    $filePath = '../' . $doc['document_path'];
    if (file_exists($filePath)) {
        // Use original document name or a safe name
        $safeName = basename($doc['document_path']);
        $zip->addFile($filePath, $safeName);
    }
}
$zip->close();

// Send ZIP to browser
header('Content-Type: application/zip');
header('Content-Disposition: attachment; filename="' . $zipName . '"');
header('Content-Length: ' . filesize($zipPath));
readfile($zipPath);
unlink($zipPath); // delete temp file
exit;
?>
