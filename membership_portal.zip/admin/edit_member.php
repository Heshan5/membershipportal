<?php
/**
 * Membership Portal – Edit Member (Admin)
 *
 * - Allows editing of all member fields including geographic and political data.
 * - When political data is changed, the system UPSERTs into geo_political_mapping (city‑level self‑learning).
 * - Province dropdown now shows trilingual names (English, Sinhala, Tamil).
 * - Gender is displayed as read‑only (collected during registration, cannot be edited here).
 *
 * @package    MembershipPortal.
 * @author     Heshan Shibry <heshan.shib@gmail.com>
 * @copyright  2026 HESHAN SHIBRY.
 * @license    Proprietary - All rights reserved.
 * @version    1.0.0.
 */
require_once '../includes/auth.php';
$pdo = getDB();
validateAdminSession($pdo);

// Helper for trilingual province names
function formatTrilingual($name_en, $name_si, $name_ta) {
    $text = $name_en;
    if (!empty($name_si) && !empty($name_ta)) {
        $text .= " ($name_si / $name_ta)";
    } elseif (!empty($name_si)) {
        $text .= " ($name_si)";
    } elseif (!empty($name_ta)) {
        $text .= " ($name_ta)";
    }
    return htmlspecialchars($text);
}

if (!hasPermission(PERM_EDIT_MEMBERS)) {
    redirect('admin/dashboard');
}

$memberId = (int)$_GET['id'];
if (!$memberId) redirect('admin/dashboard');

// Fetch member data (including gender fields)
$stmt = $pdo->prepare("SELECT * FROM members WHERE id = ?");
$stmt->execute([$memberId]);
$member = $stmt->fetch();
if (!$member) redirect('admin/dashboard');

// Get current province, district, city IDs from city_id
$city_id = (int)$member['city_id'];
$province_id = 0;
$district_id = 0;
if ($city_id) {
    $stmt = $pdo->prepare("
        SELECT c.id as city_id, c.name_en as city_name,
               d.id as district_id, d.name_en as district_name,
               p.id as province_id, p.name_en as province_name
        FROM cities c
        JOIN districts d ON c.district_id = d.id
        JOIN provinces p ON d.province_id = p.id
        WHERE c.id = ?
    ");
    $stmt->execute([$city_id]);
    $loc = $stmt->fetch();
    if ($loc) {
        $province_id = $loc['province_id'];
        $district_id = $loc['district_id'];
        $city_id = $loc['city_id'];
    }
}

// Fetch provinces with all three language columns
$provinces = $pdo->query("SELECT id, name_en, name_si, name_ta FROM provinces ORDER BY name_en")->fetchAll();

// Parse phone
$phone_code = '';
$phone_number = '';
if (!empty($member['phone'])) {
    $parts = explode(' ', $member['phone'], 2);
    $phone_code = $parts[0] ?? '';
    $phone_number = $parts[1] ?? '';
}

$message = '';
$error = '';

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $full_name = sanitize($_POST['full_name']);
    $email = sanitize($_POST['email']);
    $province_id_new = (int)$_POST['province'];
    $district_id_new = (int)$_POST['district'];
    $city_id_new = (int)$_POST['city'];

    $phone_code = sanitize($_POST['phone_code'] ?? '');
    $phone_number = sanitize($_POST['phone_number'] ?? '');
    $phone = !empty($phone_code) && !empty($phone_number) ? $phone_code . ' ' . $phone_number : '';
    $address = sanitize($_POST['address']);

    $polling_division = sanitize($_POST['polling_division']);
    $gn_division = sanitize($_POST['gn_division']);
    $assigned_booth = sanitize($_POST['assigned_polling_booth']);

    // Gender is NOT updated from this form – it remains as originally stored.

    // Get English names for province, district, city
    $province_name = '';
    $district_name = '';
    $city_name = '';
    if ($province_id_new) {
        $stmt = $pdo->prepare("SELECT name_en FROM provinces WHERE id = ?");
        $stmt->execute([$province_id_new]);
        $province_name = $stmt->fetchColumn();
    }
    if ($district_id_new) {
        $stmt = $pdo->prepare("SELECT name_en FROM districts WHERE id = ?");
        $stmt->execute([$district_id_new]);
        $district_name = $stmt->fetchColumn();
    }
    if ($city_id_new) {
        $stmt = $pdo->prepare("SELECT name_en FROM cities WHERE id = ?");
        $stmt->execute([$city_id_new]);
        $city_name = $stmt->fetchColumn();
    }

    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = "Invalid email format.";
    } elseif (empty($full_name) || empty($email) || empty($province_id_new) || empty($district_id_new) || empty($city_id_new)) {
        $error = "Full Name, Email, Province, District, and City are required.";
    } else {
        $check = $pdo->prepare("SELECT id FROM members WHERE email = ? AND id != ?");
        $check->execute([$email, $memberId]);
        if ($check->fetch()) {
            $error = "Email already used by another member.";
        } else {
            $update = $pdo->prepare("
                UPDATE members SET
                    full_name = ?, email = ?,
                    province = ?, district = ?, city = ?, city_id = ?,
                    phone = ?, address = ?,
                    polling_division = ?, gn_division = ?, assigned_polling_booth = ?,
                    last_updated_by_admin = ?
                WHERE id = ?
            ");
            if ($update->execute([
                $full_name, $email,
                $province_name, $district_name, $city_name, $city_id_new,
                $phone, $address,
                $polling_division, $gn_division, $assigned_booth,
                $_SESSION['user_id'], $memberId
            ])) {
                // Self‑learning UPSERT for city‑level mapping
                if ($city_id_new && !empty($polling_division)) {
                    $stmt = $pdo->prepare("
                        INSERT INTO geo_political_mapping (city_id, polling_division_name, gn_division_default)
                        VALUES (?, ?, ?)
                        ON DUPLICATE KEY UPDATE
                            polling_division_name = VALUES(polling_division_name),
                            gn_division_default = VALUES(gn_division_default)
                    ");
                    $stmt->execute([$city_id_new, $polling_division, $gn_division]);
                }
                $message = "Member information updated successfully.";
                // Refresh member data
                $stmt = $pdo->prepare("SELECT * FROM members WHERE id = ?");
                $stmt->execute([$memberId]);
                $member = $stmt->fetch();
                $city_id = $city_id_new;
                $province_id = $province_id_new;
                $district_id = $district_id_new;
                $parts = explode(' ', $member['phone'], 2);
                $phone_code = $parts[0] ?? '';
                $phone_number = $parts[1] ?? '';
            } else {
                $error = "Update failed.";
            }
        }
    }
}

// Navbar & header variables
$stmt = $pdo->prepare("SELECT profile_pic FROM admins WHERE id = ?");
$stmt->execute([$_SESSION['user_id']]);
$avatarPic = $stmt->fetchColumn();

$isLoggedIn = true;
$userRole = $_SESSION['role'];
$fullName = $_SESSION['full_name'];
$userId = $_SESSION['user_id'];
$isSuperAdmin = ($_SESSION['is_super_admin'] == 1);
$hasGenerateReports = hasPermission('generate_reports');
$hasRestoreUsers = hasPermission('restore_users');
$baseUrl = BASE_URL;
$hideAdminLinks = true;
$currentPage = 'edit_member';
$showViewMemberLink = true;
$viewMemberId = $member['id'];

$page_title = 'Edit Member - ' . htmlspecialchars($member['full_name']);
$page_styles = '
    <style>
        body { display: flex; flex-direction: column; min-height: 100vh; }
        main { flex: 1 0 auto; }
        footer { flex-shrink: 0; }
        .navbar .dropdown-toggle {
            display: flex !important;
            align-items: center !important;
            gap: 3px !important;
            line-height: 1 !important;
        }
        .navbar .dropdown-toggle img,
        .navbar .dropdown-toggle i {
            display: inline-block;
            vertical-align: middle;
        }
        select.form-select { cursor: pointer; }
        .form-select, .form-select option {
            text-overflow: ellipsis;
            overflow: hidden;
            white-space: nowrap;
        }
    </style>
';

// Include the global header
include '../includes/header.php';
?>

    <!-- Shared navbar (admin) -->
    <?php include '../includes/navbar.php'; ?>

    <main class="container my-5">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card shadow-sm border-0 rounded-4">
                    <div class="card-body p-4 p-md-5">
                        <h2 class="card-title text-center mb-4">Edit Member: <?= htmlspecialchars($member['full_name']) ?></h2>
                        <!-- ========== SUCCESS MESSAGE BLOCK ========== -->
                          <?php if ($message): ?>
                              <div class="alert alert-success d-flex align-items-center alert-dismissible fade show border-0 border-start border-4 border-success shadow-sm mb-4" role="alert">
                                  <!-- Modern Bootstrap SVG Check Circle Icon -->
                                  <svg xmlns="http://www.w3.org/2000/svg" width="22" height="22" fill="currentColor" class="bi bi-check-circle-fill me-3 flex-shrink-0" viewBox="0 0 16 16">
                                      <path d="M16 8A8 8 0 1 1 0 8a8 8 0 0 1 16 0m-3.97-3.03a.75.75 0 0 0-1.08.022L7.477 9.417 5.384 7.323a.75.75 0 0 0-1.06 1.06L6.97 11.03a.75.75 0 0 0 1.079-.02l3.992-4.99a.75.75 0 0 0-.01-1.05z"/>
                                  </svg>
                                  <div class="small fw-semibold">
                                      <?= $message ?>
                                  </div>
                                  <!-- Dismissible Close Button for Success States -->
                                  <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                              </div>
                          <?php endif; ?>

                          <!-- ========== ERROR MESSAGE BLOCK ========== -->
                          <?php if ($error): ?>
                              <div class="alert alert-danger d-flex align-items-center border-0 border-start border-4 border-danger shadow-sm mb-4" role="alert">
                                  <!-- Modern Bootstrap SVG Exclamation Warning Icon -->
                                  <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="currentColor" class="bi bi-exclamation-triangle-fill me-3 flex-shrink-0" viewBox="0 0 16 16">
                                      <path d="M8.982 1.566a1.13 1.13 0 0 0-1.96 0L.165 13.233c-.457.778.091 1.767.98 1.767h13.713c.889 0 1.438-.99.98-1.767zM8 5c.535 0 .954.462.9.995l-.35 3.507a.552.552 0 0 1-1.1 0L7.1 5.995A.905.905 0 0 1 8 5m.002 6a1 1 0 1 1 0 2 1 1 0 0 1 0-2"/>
                                  </svg>
                                  <div class="small fw-semibold">
                                      <?= $error ?>
                                  </div>
                              </div>
                          <?php endif; ?>
                        <form method="POST">
                            <div class="row">
                                <div class="col-md-6 mb-3">
                                    <label class="form-label fw-semibold">Full Name</label>
                                    <input type="text" name="full_name" class="form-control" value="<?= htmlspecialchars($member['full_name']) ?>" required>
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label class="form-label fw-semibold">Email</label>
                                    <input type="email" name="email" class="form-control" value="<?= htmlspecialchars($member['email']) ?>" required>
                                    <div class="invalid-feedback" id="emailFeedback"></div>
                                </div>
                            </div>

                            <div class="col-md-4 mb-3">
                                <label class="form-label fw-semibold">Member ID (read‑only)</label>
                                <input type="text" class="form-control bg-light" value="<?= htmlspecialchars($member['member_id']) ?>" readonly>
                            </div>

                            <!-- Geographic hierarchy (province trilingual) -->
                            <div class="row align-items-end g-3 mb-4">
                                <div class="col-md-4">
                                    <label class="form-label fw-semibold">Province *</label>
                                    <select id="provinceSelect" name="province" class="form-select" required>
                                        <option value="">Select Province</option>
                                        <?php foreach ($provinces as $p): ?>
                                            <option value="<?= $p['id'] ?>" <?= ($province_id == $p['id']) ? 'selected' : '' ?>>
                                                <?= formatTrilingual($p['name_en'], $p['name_si'], $p['name_ta']) ?>
                                            </option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                                <div class="col-md-4">
                                    <label class="form-label fw-semibold">District *</label>
                                    <select id="districtSelect" name="district" class="form-select" required <?= $district_id ? '' : 'disabled' ?>>
                                        <option value="">Select...</option>
                                    </select>
                                </div>
                                <div class="col-md-4">
                                    <label class="form-label fw-semibold">City / Nearest Town *</label>
                                    <select id="citySelect" name="city" class="form-select" required <?= $city_id ? '' : 'disabled' ?>>
                                        <option value="">Select...</option>
                                    </select>
                                </div>
                            </div>

                            <div class="col-md-6 mb-4">
                                <label class="form-label fw-semibold">Phone Number</label>
                                <div class="row g-2">
                                    <div class="col-4">
                                        <select name="phone_code" class="form-select">
                                            <option value="+94" <?= $phone_code == '+94' ? 'selected' : '' ?>>+94</option>
                                            <option value="+91" <?= $phone_code == '+91' ? 'selected' : '' ?>>+91</option>
                                            <option value="+1" <?= $phone_code == '+1' ? 'selected' : '' ?>>+1</option>
                                            <option value="+44" <?= $phone_code == '+44' ? 'selected' : '' ?>>+44</option>
                                            <option value="+61" <?= $phone_code == '+61' ? 'selected' : '' ?>>+61</option>
                                            <option value="+971" <?= $phone_code == '+971' ? 'selected' : '' ?>>+971</option>
                                        </select>
                                    </div>
                                    <div class="col-8">
                                        <input type="tel" name="phone_number" class="form-control" placeholder="712345678" pattern="[0-9]{7,10}" title="7 to 10 digits" value="<?= htmlspecialchars($phone_number) ?>">
                                    </div>
                                </div>
                                <small class="text-muted">Select country code and enter local number (without leading zero).</small>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label class="form-label fw-semibold">Address</label>
                                <textarea name="address" rows="3" class="form-control"><?= htmlspecialchars($member['address']) ?></textarea>
                            </div>

                            <!-- Gender Display (read‑only) -->
                            <div class="row mb-3">
                                <div class="col-md-6">
                                    <label class="form-label fw-semibold">Gender</label>
                                    <div class="form-control bg-light">
                                        <?php
                                        if (!empty($member['gender'])) {
                                            $genderDisplay = htmlspecialchars($member['gender']);
                                            if ($member['gender'] == 'Other' && !empty($member['gender_custom'])) {
                                                $genderDisplay .= ' (' . htmlspecialchars($member['gender_custom']) . ')';
                                            }
                                            echo $genderDisplay;
                                        } else {
                                            echo 'Not specified';
                                        }
                                        ?>
                                    </div>
                                </div>
                            </div>

                            <hr>

                            <h5 class="mb-3 fw-bold">Political Data (for administrative use)</h5>
                            <div class="row">
                                <div class="col-md-4 mb-3">
                                    <label class="form-label fw-semibold">Polling Division</label>
                                    <input type="text" name="polling_division" class="form-control" value="<?= htmlspecialchars($member['polling_division'] ?? 'Pending') ?>">
                                </div>
                                <div class="col-md-4 mb-3">
                                    <label class="form-label fw-semibold">Grama Niladhari Division</label>
                                    <input type="text" name="gn_division" class="form-control" value="<?= htmlspecialchars($member['gn_division'] ?? 'Pending') ?>">
                                </div>
                                <div class="col-md-4 mb-3">
                                    <label class="form-label fw-semibold">Assigned Polling Booth</label>
                                    <input type="text" name="assigned_polling_booth" class="form-control" value="<?= htmlspecialchars($member['assigned_polling_booth'] ?? 'Pending') ?>">
                                </div>
                            </div>
                            <small class="text-muted">Changes made here will automatically update the mapping for this city, so future applicants from the same city will inherit these political details.</small>

                            <button type="submit" class="btn btn-dark w-100 py-2 mt-3">Save Changes</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </main>

    <script>
        // Make 'Pending' behave like a placeholder for political fields
        document.addEventListener('DOMContentLoaded', function() {
            const politicalFields = ['polling_division', 'gn_division', 'assigned_polling_booth'];
            politicalFields.forEach(fieldName => {
                const input = document.querySelector(`input[name="${fieldName}"]`);
                if (input) {
                    const defaultValue = input.value;
                    input.addEventListener('focus', function() {
                        if (this.value === defaultValue) {
                            this.value = '';
                        }
                    });
                    input.addEventListener('blur', function() {
                        if (this.value.trim() === '') {
                            this.value = defaultValue;
                        }
                    });
                }
            });
        });

        // Province -> District -> City cascade
        document.addEventListener('DOMContentLoaded', function() {
            const provinceSelect = document.getElementById('provinceSelect');
            const districtSelect = document.getElementById('districtSelect');
            const citySelect = document.getElementById('citySelect');

            const currentDistrictId = <?= (int)$district_id ?>;
            const currentCityId = <?= (int)$city_id ?>;

            function formatOption(name_en, name_si, name_ta) {
                let text = name_en;
                if (name_si && name_ta) text += ` (${name_si} / ${name_ta})`;
                else if (name_si) text += ` (${name_si})`;
                else if (name_ta) text += ` (${name_ta})`;
                return text;
            }

            const baseUrl = '<?= rtrim(BASE_URL, '/') . '/' ?>';

            function loadDistricts(provinceId, selectedDistrictId = 0) {
                if (!provinceId) {
                    districtSelect.innerHTML = '<option value="">Select District</option>';
                    districtSelect.disabled = true;
                    citySelect.innerHTML = '<option value="">Select City/Town</option>';
                    citySelect.disabled = true;
                    return;
                }
                fetch(`${baseUrl}get_locations.php?type=districts&province_id=${provinceId}`)
                    .then(res => res.json())
                    .then(data => {
                        districtSelect.innerHTML = '<option value="">Select District</option>';
                        data.forEach(item => {
                            const selected = (selectedDistrictId == item.id) ? 'selected' : '';
                            districtSelect.innerHTML += `<option value="${item.id}" ${selected}>${formatOption(item.name_en, item.name_si, item.name_ta)}</option>`;
                        });
                        districtSelect.disabled = false;
                        if (selectedDistrictId) {
                            loadCities(selectedDistrictId, currentCityId);
                        } else {
                            citySelect.innerHTML = '<option value="">Select City/Town</option>';
                            citySelect.disabled = true;
                        }
                    })
                    .catch(err => console.error(err));
            }

            function loadCities(districtId, selectedCityId = 0) {
                if (!districtId) {
                    citySelect.innerHTML = '<option value="">Select City/Town</option>';
                    citySelect.disabled = true;
                    return;
                }
                fetch(`${baseUrl}get_locations.php?type=cities&district_id=${districtId}`)
                    .then(res => res.json())
                    .then(data => {
                        citySelect.innerHTML = '<option value="">Select City/Town</option>';
                        data.forEach(item => {
                            const selected = (selectedCityId == item.id) ? 'selected' : '';
                            citySelect.innerHTML += `<option value="${item.id}" ${selected}>${formatOption(item.name_en, item.name_si, item.name_ta)}</option>`;
                        });
                        citySelect.disabled = false;
                    })
                    .catch(err => console.error(err));
            }

            if (provinceSelect.value) {
                loadDistricts(provinceSelect.value, currentDistrictId);
            }

            provinceSelect.addEventListener('change', function() {
                loadDistricts(this.value, 0);
            });

            districtSelect.addEventListener('change', function() {
                loadCities(this.value, 0);
            });
        });

        // Submit lock
        document.addEventListener('DOMContentLoaded', function() {
            const form = document.querySelector('form');
            const submitBtn = document.querySelector('button[type="submit"]');
            if (form && submitBtn) {
                form.addEventListener('submit', function() {
                    setTimeout(function() {
                        if (submitBtn.innerText.trim() === "Save Changes") {
                            submitBtn.innerText = "Saving Changes...";
                        }
                        submitBtn.style.opacity = "0.5";
                        submitBtn.style.pointerEvents = "none";
                    }, 0);
                });
            }
        });
    </script>

    <!-- footer (admin) includes report issue modal -->
    <?php include '../includes/footer_admin.php'; ?>
