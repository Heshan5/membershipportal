<?php
/**
 * Membership Portal.
 * Forgot Password Request.
 *
 * Allows an admin to request a password reset link.
 * Validates email format, checks if the email exists in the `admins` table,
 * generates a secure token (1‑hour expiry), stores it in `password_resets` table,
 * and sends (or queues) a reset link email.
 *
 * @package    MembershipPortal.
 * @author     Heshan Shibry <heshan.shib@gmail.com>
 * @copyright  2026 HESHAN SHIBRY.
 * @license    Proprietary - All rights reserved.
 * @version    1.0.0.
 */
session_start();
require_once '../includes/functions.php';
$pdo = getDB();
$baseUrl = BASE_URL;

// If no admin exists, redirect to setup
if (!hasAdmin($pdo)) {
    header('Location: ' . BASE_URL . 'setup');
    exit;
}

// Automatically delete expired tokens on every request (cleanup)
$pdo->exec("DELETE FROM password_resets WHERE expires_at < UNIX_TIMESTAMP()");

$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = sanitize($_POST['email']);

    // Email format validation
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = "Invalid email format. Please enter a valid email address.";
    } else {
        $stmt = $pdo->prepare("SELECT id, full_name FROM admins WHERE email = ?");
        $stmt->execute([$email]);
        $admin = $stmt->fetch();

        if ($admin) {
            $token = bin2hex(random_bytes(32));
            $expires = time() + 3600; // 1 hour

            $stmt = $pdo->prepare("DELETE FROM password_resets WHERE email = ?");
            $stmt->execute([$email]);

            $utcNow = utcNow();
            $stmt = $pdo->prepare("INSERT INTO password_resets (email, token, expires_at, created_at) VALUES (?, ?, ?, ?)");
            $stmt->execute([$email, $token, $expires, $utcNow]);

            $resetLink = "http://" . $_SERVER['HTTP_HOST'] . rtrim(dirname($_SERVER['SCRIPT_NAME']), '/') . "/reset_password?token=" . $token;

            $subject = "Password Reset for National Movement";
            $message = "Hello {$admin['full_name']},\n\nClick the link to reset your password:\n$resetLink\n\nThis link expires in 1 hour.\n\nIf you did not request this, ignore this email.";

            // --- Hybrid sending: immediate + fallback queue ---
            $result = sendEmail($email, $subject, $message, $admin['full_name']);
            if ($result['success']) {
                $success = "A password reset link has been sent to your email address.";
            } else {
                // Immediate send failed – try to queue the email for later
                if (function_exists('queueEmail')) {
                    $queued = queueEmail($email, $subject, $message, $admin['full_name']);
                    if ($queued) {
                        $success = "A password reset link could not be sent immediately, but it has been queued and will be delivered shortly.";
                    } else {
                        $error = "Failed to send or queue the reset email. Please contact support.";
                    }
                } else {
                    $error = "Failed to send email. Please contact support.";
                }
            }
        } else {
            $error = "This email address is not registered in our system.";
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Forgot Password | National Movement</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../assets/css/style.css">
    <style>
        .invalid-feedback { display: block; }
        /* Custom dark navy button to match the image */
        .btn-dark-navy {
            background-color: #001f3f; /* Adjust this hex to match your specific navy */
            color: white;
            border: none;
        }

        .btn-dark-navy:hover {
            background-color: #00152b;
            color: white;
        }

        /* Adds the underline back only when hovering the link */
        a.text-decoration-none:hover {
            text-decoration: underline !important;
            text-underline-offset: 4px;
        }

        /* Matches the soft shadow from your image */
        .shadow-sm {
            box-shadow: 0 .125rem .25rem rgba(0,0,0,.075) !important;
        }
        .custom-link {
            color: #007bff; /* A nice standard blue */
            transition: color 0.2s ease; /* Makes the color change feel smooth, not jerky */
        }

        .custom-link:hover {
            color: #0056b3; /* A noticeably darker blue for the hover state */
        }
    </style>
</head>
<body class="bg-light d-flex flex-column min-vh-100">

    <!-- custom navbar -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <div class="container justify-content-center">
            <h4 class="text-white fw-bold mx-auto text-center">NATIONAL BUILDER · MOVEMENT</h4>
        </div>
    </nav>

      <main class="flex-grow-1 py-5"> <!-- Added py-5 for vertical spacing -->
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-md-6 col-lg-5"> <!-- Adjusted column width for a tighter look -->
                    <!-- Use border-0 and rounded-4 for that soft, modern card look -->
                    <div class="card border-0 shadow-sm rounded-4">
                        <div class="card-body p-6"> <!-- Increased padding to match the image -->
                            <h2 class="text-center mb-4 fw-normal">Forgot Password</h2>

                            <?php if ($error): ?>
                                  <div class="alert alert-danger d-flex align-items-center border-0 border-start border-4 border-danger shadow-sm mb-4" role="alert">
                                      <!-- Modern Bootstrap SVG Exclamation Warning Icon -->
                                      <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="currentColor" class="bi bi-exclamation-triangle-fill me-3 flex-shrink-0" viewBox="0 0 16 16">
                                          <path d="M8.982 1.566a1.13 1.13 0 0 0-1.96 0L.165 13.233c-.457.778.091 1.767.98 1.767h13.713c.889 0 1.438-.99.98-1.767zM8 5c.535 0 .954.462.9.995l-.35 3.507a.552.552 0 0 1-1.1 0L7.1 5.995A.905.905 0 0 1 8 5m.002 6a1 1 0 1 1 0 2 1 1 0 0 1 0-2"/>
                                      </svg>
                                      <div class="small fw-semibold">
                                          <?= $error ?>
                                      </div>
                                  </div>
                              <?php endif; ?>

                              <?php if ($success): ?>
                                    <div class="alert alert-success d-flex align-items-center alert-dismissible fade show border-0 border-start border-4 border-success shadow-sm mb-4" role="alert">
                                        <!-- Modern Bootstrap SVG Check Circle Icon -->
                                        <svg xmlns="http://www.w3.org/2000/svg" width="22" height="22" fill="currentColor" class="bi bi-check-circle-fill me-3 flex-shrink-0" viewBox="0 0 16 16">
                                            <path d="M16 8A8 8 0 1 1 0 8a8 8 0 0 1 16 0m-3.97-3.03a.75.75 0 0 0-1.08.022L7.477 9.417 5.384 7.323a.75.75 0 0 0-1.06 1.06L6.97 11.03a.75.75 0 0 0 1.079-.02l3.992-4.99a.75.75 0 0 0-.01-1.05z"/>
                                        </svg>
                                        <div>
                                            <div class="small fw-semibold">
                                              <?= $success ?>
                                            </div>
                                        </div>
                                        <!-- Native Bootstrap 5 Close Button -->
                                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                                    </div>
                            <?php else: ?>
                                <form method="POST" id="forgotForm">
                                    <div class="mb-3"> <!-- Increased margin -->
                                        <label class="form-label fw-semibold">Email address *</label>
                                        <!-- Use py-2 for a taller, modern input -->
                                        <input type="email" name="email" id="email" class="form-control py-2" required>
                                        <div class="invalid-feedback" id="emailFeedback"></div>
                                    </div>

                                    <div class="col-md-12 text-center">
                                        <!-- Removed w-100 and added px-4 for a perfectly proportioned centered button -->
                                        <button type="submit" class="btn btn-dark py-2 rounded-pill px-5">
                                            Send Reset Link
                                        </button>
                                    </div>
                                </form>
                            <?php endif; ?>

                            <div class="text-center mt-4">
                                <!-- text-primary gives you that blue link color -->
                                <a class="text-decoration-none custom-link" href="<?= $baseUrl ?>admin">Back to Login</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </main>

    <!-- custom footer -->
    <footer class="bg-dark text-white-50 text-center py-4 mt-auto">
        <p class="mb-0">National Movement – Forgot Password</p>
        <p class="mb-0 mt-2 small">
            &copy; <?= date('Y') ?> National Movement. All rights reserved.
        </p>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Email validation with live feedback
        const emailInput = document.getElementById('email');
        const emailFeedback = document.getElementById('emailFeedback');
        emailInput.addEventListener('input', function() {
            const email = this.value;
            const isValid = /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
            if (!isValid && email.length > 0) {
                this.classList.add('is-invalid');
                emailFeedback.textContent = 'Please enter a valid email address (e.g., name@example.com).';
            } else {
                this.classList.remove('is-invalid');
                emailFeedback.textContent = '';
            }
        });
        /*
         * RESET LINK REQUEST: WITH STATUS TEXT
         * Changes text to "Sending..." so the user knows the email process has started.
         */
        document.addEventListener('DOMContentLoaded', function() {
            const form = document.querySelector('form');
            const submitBtn = document.querySelector('button[type="submit"]');

            if (form && submitBtn) {
                form.addEventListener('submit', function() {
                    setTimeout(function() {
                        // Change text to "Sending..." for better feedback
                        submitBtn.innerText = "Sending Link...";
                        submitBtn.style.opacity = "0.5";
                        submitBtn.style.pointerEvents = "none";
                    }, 0);
                });
            }
        });
    </script>
</body>
</html>
