<?php
/**
 * Membership Portal.
 * View Document (inline) – Displays a document in the browser.
 * Access: only admins with view_members permission.
 *
 * @package    MembershipPortal.
 * @author     Heshan Shibry <heshan.shib@gmail.com>
 * @copyright  2026 HESHAN SHIBRY.
 * @license    Proprietary - All rights reserved.
 * @version    1.0.0.
 */
require_once '../includes/auth.php';
$pdo = getDB();

if (!isset($_SESSION['user_id']) || !hasPermission(PERM_VIEW_MEMBERS)) {
    die('Unauthorized');
}

$docId = isset($_GET['id']) ? (int)$_GET['id'] : 0;
if (!$docId) die('Invalid document ID');

$stmt = $pdo->prepare("SELECT d.document_path, d.document_name FROM documents d WHERE d.id = ?");
$stmt->execute([$docId]);
$doc = $stmt->fetch();
if (!$doc) die('Document not found');

$filePath = '../' . $doc['document_path'];
if (!file_exists($filePath)) die('File not found on server');

// Determine MIME type
$finfo = finfo_open(FILEINFO_MIME_TYPE);
$mimeType = finfo_file($finfo, $filePath);
finfo_close($finfo);

// Output the file inline
header('Content-Type: ' . $mimeType);
header('Content-Disposition: inline; filename="' . basename($doc['document_path']) . '"');
header('Content-Length: ' . filesize($filePath));
readfile($filePath);
exit;
?>
