<?php
/**
 * Membership Portal.
 * Delete Member – Soft delete (move to deleted_members table).
 * Access: only admins with delete_members permission.
 * Expects POST with member_id and reason.
 *
 * Updated to include all geographic and political columns,
 * as well as verification status and gender for full audit.
 *
 * @package    MembershipPortal.
 * @author     Heshan Shibry <heshan.shib@gmail.com>
 * @copyright  2026 HESHAN SHIBRY.
 * @license    Proprietary - All rights reserved.
 * @version    1.0.0.
 */
require_once '../includes/auth.php';
$pdo = getDB();
validateAdminSession($pdo);

if (!hasPermission(PERM_DELETE_MEMBERS)) {
    redirect('admin/dashboard');
}

// Only accept POST requests
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    redirect('admin/dashboard');
}

$memberId = isset($_POST['member_id']) ? (int)$_POST['member_id'] : 0;
$reason = isset($_POST['reason']) ? sanitizePlain($_POST['reason']) : '';
$tzOffset = isset($_POST['tz_offset']) ? (int)$_POST['tz_offset'] : null;

if (!$memberId) {
    $_SESSION['delete_error'] = "Invalid member ID.";
    redirect('admin/dashboard');
    exit;
}

if (empty($reason)) {
    $_SESSION['delete_error'] = "Please provide a reason for deletion.";
    redirect('admin/dashboard');
    exit;
}

// Fetch member data (for the notification and to verify existence)
$stmt = $pdo->prepare("SELECT full_name, member_id FROM members WHERE id = ?");
$stmt->execute([$memberId]);
$memberInfo = $stmt->fetch();
if (!$memberInfo) {
    $_SESSION['delete_error'] = "Member not found.";
    redirect('admin/dashboard');
    exit;
}

// Generate UTC timestamp for deletion
$deletedAt = utcNow();

// --- Insert into deleted_members using SELECT (includes all columns, now with gender) ---
$stmtDel = $pdo->prepare("
    INSERT INTO deleted_members
        (original_id, member_id, full_name, email, province, district, city, city_id,
         phone, address, profile_pic, created_at, deleted_at, deleted_by, reason,
         polling_division, gn_division, assigned_polling_booth, verification_status,
         master_address_id, gender, gender_custom)
    SELECT
        id, member_id, full_name, email, province, district, city, city_id,
        phone, address, profile_pic, created_at, ?, ?, ?,
        polling_division, gn_division, assigned_polling_booth, verification_status,
        master_address_id, gender, gender_custom
    FROM members
    WHERE id = ?
");
$stmtDel->execute([$deletedAt, $_SESSION['user_id'], $reason, $memberId]);

// --- Move documents to deleted_documents ---
$stmtDocs = $pdo->prepare("SELECT * FROM documents WHERE member_id = ?");
$stmtDocs->execute([$memberId]);
$docs = $stmtDocs->fetchAll();
foreach ($docs as $doc) {
    $stmtDocDel = $pdo->prepare("
        INSERT INTO deleted_documents
            (original_id, member_id, document_name, document_path, document_type, uploaded_at, deleted_at, deleted_by)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    ");
    $stmtDocDel->execute([
        $doc['id'],
        $doc['member_id'],
        $doc['document_name'],
        $doc['document_path'],
        $doc['document_type'],
        $doc['uploaded_at'],
        $deletedAt,
        $_SESSION['user_id']
    ]);
}

// --- Delete from original tables ---
$pdo->prepare("DELETE FROM members WHERE id = ?")->execute([$memberId]);
$pdo->prepare("DELETE FROM documents WHERE member_id = ?")->execute([$memberId]);

// Send notification email with deleter's local time
if (function_exists('sendDeletionNotification')) {
    sendDeletionNotification('Member', $memberInfo['full_name'], $memberInfo['member_id'], $_SESSION['full_name'], $reason, $tzOffset);
}

$_SESSION['delete_success'] = "Member deleted successfully (moved to trash).";
redirect('admin/dashboard');
exit;
?>
