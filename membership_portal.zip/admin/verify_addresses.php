<?php
/**
 * Membership Portal – Address Verification Queue (Admin)
 *
 * - Lists all master_addresses with status = 'pending'.
 * - Admin can edit polling division, GN division, polling booth and mark as 'verified'.
 * - Once verified, future registrations on that street (with fuzzy matching) will be auto‑approved.
 *
 * @package    MembershipPortal.
 * @author     Heshan Shibry <heshan.shib@gmail.com>
 * @copyright  2026 HESHAN SHIBRY.
 * @license    Proprietary - All rights reserved.
 * @version    1.0.0.
 */
require_once '../includes/auth.php';
$pdo = getDB();
validateAdminSession($pdo);

if (!hasPermission('edit_members')) { // or a dedicated permission
    redirect('admin/dashboard');
}

// Fetch profile picture for navbar avatar
$stmt = $pdo->prepare("SELECT profile_pic FROM admins WHERE id = ?");
$stmt->execute([$_SESSION['user_id']]);
$avatarPic = $stmt->fetchColumn();

// Navbar variables
$isLoggedIn = true;
$userRole = $_SESSION['role'];
$fullName = $_SESSION['full_name'];
$userId = $_SESSION['user_id'];
$isSuperAdmin = ($_SESSION['is_super_admin'] == 1);
$hasGenerateReports = hasPermission('generate_reports');
$hasRestoreUsers = hasPermission('restore_users');
$baseUrl = BASE_URL;
$currentPage = 'verify_addresses';
$hideAdminLinks = false;

$message = '';
$error = '';

// Handle verification update
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['verify_id'])) {
    $verify_id = (int)$_POST['verify_id'];
    $polling_div = sanitize($_POST['polling_division']);
    $gn_div = sanitize($_POST['gn_division']);
    $booth = sanitize($_POST['assigned_polling_booth']);

    $stmt = $pdo->prepare("UPDATE master_addresses SET
        polling_division = ?, gn_division = ?, assigned_polling_booth = ?,
        status = 'verified', verified_by_admin = ?,
        updated_at = NOW()
        WHERE id = ? AND status = 'pending'");
    if ($stmt->execute([$polling_div, $gn_div, $booth, $_SESSION['user_id'], $verify_id])) {
        $message = "Address verified successfully. Future registrations on this street will be auto‑approved.";
    } else {
        $error = "Update failed.";
    }
}

// Fetch pending master addresses with city names
$sql = "SELECT ma.*, c.name_en as city_name
        FROM master_addresses ma
        JOIN cities c ON ma.city_id = c.id
        WHERE ma.status = 'pending'
        ORDER BY ma.created_at ASC";
$pending = $pdo->query($sql)->fetchAll();

$page_title = 'Verify Addresses';
$page_styles = '
    <style>
        body { display: flex; flex-direction: column; min-height: 100vh; background-color: #f8f9fa; }
        main { flex: 1 0 auto; }
        footer { flex-shrink: 0; }
        .navbar .dropdown-toggle {
            display: flex !important;
            align-items: center !important;
            gap: 3px !important;
            line-height: 1 !important;
        }
        .navbar .dropdown-toggle img,
        .navbar .dropdown-toggle i {
            display: inline-block;
            vertical-align: middle;
        }
        /* Force everything inside the verification table to align perfectly in the center */
        .align-middle tbody td {
            vertical-align: middle !important;
        }

        /* Removes default bottom margin from Bootstrap form elements inside the table rows */
        .align-middle td .form-control {
            margin-bottom: 0 !important;
        }

        /* FIXES THE BUBBLY LOOK: Resets the border-radius and makes the fields compact */
        .align-middle td .form-control {
            border-radius: 6px !important;      /* Removes the puffy bubble shape */
            padding: 0.35rem 0.65rem !important; /* Makes it compact like standard inputs */
            font-size: 0.875rem !important;      /* Cleans up text sizing */
            height: auto !important;             /* Ensures it do not stretch vertically */
        }
    </style>
';

// Include the global header
include '../includes/header.php';
?>

      <!-- Shared navbar (admin) -->
      <?php include '../includes/navbar.php'; ?>

      <main class="container my-4">
          <div class="card shadow-sm border-0 rounded-4">
              <div class="card-body p-4">
                <div class="mb-4">
                  <h2 class="card-title mb-1">🏠 Address Verification Queue</h2>
                  <p class="text-muted mb-0">Review pending physical addresses, map administrative boundaries, and authorize future matches.</p>
                </div>
                <!-- ========== SUCCESS MESSAGE BLOCK ========== -->
                  <?php if ($message): ?>
                    <div class="alert alert-success d-flex align-items-center alert-dismissible fade show border-0 border-start border-4 border-success shadow-sm mb-4" role="alert">
                        <!-- Modern Bootstrap SVG Check Circle Icon -->
                        <svg xmlns="http://www.w3.org/2000/svg" width="22" height="22" fill="currentColor" class="bi bi-check-circle-fill me-3 flex-shrink-0" viewBox="0 0 16 16">
                            <path d="M16 8A8 8 0 1 1 0 8a8 8 0 0 1 16 0m-3.97-3.03a.75.75 0 0 0-1.08.022L7.477 9.417 5.384 7.323a.75.75 0 0 0-1.06 1.06L6.97 11.03a.75.75 0 0 0 1.079-.02l3.992-4.99a.75.75 0 0 0-.01-1.05z"/>
                        </svg>
                        <div class="small fw-semibold"><?= $message ?></div>
                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    </div>
                  <?php endif; ?>

                  <!-- ========== ERROR MESSAGE BLOCK ========== -->
                  <?php if ($error): ?>
                    <div class="alert alert-danger d-flex align-items-center border-0 border-start border-4 border-danger shadow-sm mb-4" role="alert">
                        <!-- Modern Bootstrap SVG Exclamation Warning Icon -->
                        <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="currentColor" class="bi bi-exclamation-triangle-fill me-3 flex-shrink-0" viewBox="0 0 16 16">
                            <path d="M8.982 1.566a1.13 1.13 0 0 0-1.96 0L.165 13.233c-.457.778.091 1.767.98 1.767h13.713c.889 0 1.438-.99.98-1.767zM8 5c.535 0 .954.462.9.995l-.35 3.507a.552.552 0 0 1-1.1 0L7.1 5.995A.905.905 0 0 1 8 5m.002 6a1 1 0 1 1 0 2 1 1 0 0 1 0-2"/>
                        </svg>
                        <div class="small fw-semibold"><?= $error ?></div>
                    </div>
                  <?php endif; ?>

                  <!-- ========== NO PENDING DATA (INFO BANNER STATE) ========== -->
                  <?php if (empty($pending)): ?>
                    <div class="alert alert-info d-flex align-items-center alert-dismissible fade show border-0 border-start border-4 border-info shadow-sm mb-4" role="alert">
                        <!-- Modern Bootstrap SVG Info Circle Icon -->
                        <svg xmlns="http://www.w3.org/2000/svg" width="22" height="22" fill="currentColor" class="bi bi-info-circle-fill me-3 flex-shrink-0" viewBox="0 0 16 16">
                            <path d="M8 16A8 8 0 1 0 8 0a8 8 0 0 0 0 16zm.93-9.412-1 4.705c-.07.34.029.533.304.533.194 0 .487-.07.686-.246l-.088.416c-.287.346-.92.598-1.465.598-.703 0-1.002-.422-.808-1.319l.738-3.468c.064-.293.006-.399-.287-.47l-.451-.081.082-.381 2.29-.287zM8 5.5a1 1 0 1 1 0-2 1 1 0 0 1 0 2z"/>
                        </svg>
                        <div class="small fw-semibold">No pending addresses. All good!</div>
                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    </div>
                  <?php else: ?>
                      <div class="table-responsive">
                          <table class="table table-hover align-middle custom-admin-table">
                              <thead class="table-light">
                                  <tr>
                                      <th>ID</th>
                                      <th>Street Address (as entered)</th>
                                      <th>City</th>
                                      <th>Normalized (for matching)</th>
                                      <th>Polling Division</th>
                                      <th>Grama Niladhari Division</th>
                                      <th>Polling Booth</th>
                                      <th>Actions</th>
                                  </tr>
                              </thead>
                              <tbody>
                                  <?php foreach ($pending as $addr): ?>
                                  <form method="POST">
                                      <input type="hidden" name="verify_id" value="<?= $addr['id'] ?>">
                                      <tr>
                                          <td>#<?= $addr['id'] ?></td>
                                          <td><?= htmlspecialchars($addr['street_address']) ?></td>
                                          <td><?= htmlspecialchars($addr['city_name']) ?></td>
                                          <td><code class="fs-6"><?= htmlspecialchars($addr['normalized_street']) ?></code></td>
                                          <!-- Added explicit vertical centering style to override bootstrap input table behavior -->
                                          <td style="vertical-align: middle !important;"><input type="text" name="polling_division" class="form-control" value="<?= htmlspecialchars($addr['polling_division']) ?>" required></td>
                                          <td style="vertical-align: middle !important;"><input type="text" name="gn_division" class="form-control" value="<?= htmlspecialchars($addr['gn_division']) ?>" required></td>
                                          <td style="vertical-align: middle !important;"><input type="text" name="assigned_polling_booth" class="form-control" value="<?= htmlspecialchars($addr['assigned_polling_booth']) ?>" required></td>
                                          <td style="vertical-align: middle !important;"><button type="submit" class="btn btn-sm btn-outline-success px-3 rounded-pill">Verify & Save</button></td>
                                      </tr>
                                  </form>
                                  <?php endforeach; ?>
                              </tbody>
                          </table>
                      </div>
                  <?php endif; ?>
              </div>
          </div>
      </main>

<script>
  // Make 'Not Assigned' behave like a placeholder for political fields
  document.addEventListener('DOMContentLoaded', function() {
      const politicalFields = ['polling_division', 'gn_division', 'assigned_polling_booth'];
      politicalFields.forEach(fieldName => {
          const inputs = document.querySelectorAll(`input[name="${fieldName}"]`);
          inputs.forEach(input => {
              const defaultValue = input.value;
              input.addEventListener('focus', function() {
                  if (this.value === defaultValue) {
                      this.value = '';
                  }
              });
              input.addEventListener('blur', function() {
                  if (this.value.trim() === '') {
                      this.value = defaultValue;
                  }
              });
          });
      });
  });
</script>

<!-- footer (admin) includes report issue modal -->
<?php include '../includes/footer_admin.php'; ?>
