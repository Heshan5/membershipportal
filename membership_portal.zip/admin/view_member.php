<?php
/**
 * Membership Portal – View Member Details
 *
 * - Displays all member information including geographic fields (province, district, city)
 *   and political fields (polling division, GN division, assigned booth).
 * - Shows a badge "Unverified" if polling_division is 'Pending'.
 * - Displays gender (with custom text if "Other" was selected).
 * - UTC timestamp converted to local time.
 *
 * @package    MembershipPortal.
 * @author     Heshan Shibry <heshan.shib@gmail.com>
 * @copyright  2026 HESHAN SHIBRY.
 * @license    Proprietary - All rights reserved.
 * @version    1.0.0.
 */
require_once '../includes/auth.php';
$pdo = getDB();
validateAdminSession($pdo);

$isSuperAdmin = ($_SESSION['is_super_admin'] == 1);
$stmt = $pdo->prepare("SELECT profile_pic FROM admins WHERE id = ?");
$stmt->execute([$_SESSION['user_id']]);
$avatarPic = $stmt->fetchColumn();

$isLoggedIn = true;
$userRole = $_SESSION['role'];
$fullName = $_SESSION['full_name'];
$userId = $_SESSION['user_id'];
$hasGenerateReports = hasPermission('generate_reports');
$hasRestoreUsers = hasPermission('restore_users');
$baseUrl = BASE_URL;
$hideAdminLinks = true;

if (!isset($_SESSION['user_id']) || !hasPermission(PERM_VIEW_MEMBERS)) {
    redirect('');
}

$memberId = (int)$_GET['id'];
if (!$memberId) redirect('admin/dashboard');

// Updated SELECT to include gender and gender_custom
$stmt = $pdo->prepare("
    SELECT id, member_id, full_name, email, province, district, city, phone, address,
           polling_division, gn_division, assigned_polling_booth, profile_pic, created_at,
           gender, gender_custom
    FROM members WHERE id = ?
");
$stmt->execute([$memberId]);
$member = $stmt->fetch();
if (!$member) redirect('admin/dashboard');

$stmtDocs = $pdo->prepare("SELECT id, document_name, document_path, document_type FROM documents WHERE member_id = ? ORDER BY uploaded_at DESC");
$stmtDocs->execute([$memberId]);
$docs = $stmtDocs->fetchAll();

$canEdit = hasPermission(PERM_EDIT_MEMBERS);

$page_title = 'Member Details - ' . htmlspecialchars($member['full_name']);
$page_styles = '
    <style>
    .navbar .dropdown-toggle {
        display: flex !important;
        align-items: center !important;
        gap: 3px !important;
        line-height: 1 !important;
    }
    .navbar .dropdown-toggle img,
    .navbar .dropdown-toggle i {
        display: inline-block;
        vertical-align: middle;
    }
    .member-info-list .row {
        margin-bottom: 0.75rem;
        padding-bottom: 0.5rem;
        border-bottom: 1px solid #e9ecef;
    }
    .member-info-list .col-4, .member-info-list .col-3 {
        font-weight: 600;
        color: #6c757d;
    }
    @media (max-width: 768px) {
        .member-info-list .col-4 {
            font-size: 0.9rem;
        }
    }
    </style>
';

// Include the global header
include '../includes/header.php';
?>

<!-- Shared navbar (admin) -->
<?php include '../includes/navbar.php'; ?>

<main class="container my-4">
    <div class="card shadow-sm border-0 rounded-4 mb-4">
        <div class="card-body p-4">
            <div class="row g-4">
                <div class="col-md-4 text-center order-first order-md-last">
                    <?php if ($member['profile_pic']): ?>
                        <img src="view_profile_pic.php?id=<?= $memberId ?>" alt="Profile" class="profile-img shadow-sm mb-3">
                    <?php else: ?>
                        <i class="bi bi-person-circle" style="font-size: 100px; color: #ccc;"></i>
                    <?php endif; ?>
                </div>

                <!-- Member Details -->
                <div class="col-md-8 order-last order-md-first">
                    <h2 class="card-title mb-1 fw-bold">View Member</h2>
                    <h4 class="text-muted mb-3">Administrator View</h4>
                    <hr>
                    <h3 class="fw-bold mb-4">
                        <?= htmlspecialchars($member['full_name']) ?>
                        <br class="d-md-none">
                        <small class="text-muted fs-5">(<?= $member['member_id'] ?>)</small>
                    </h3>
                    <div class="member-info-list">
                        <div class="row"><div class="col-4 col-md-3">Email</div><div class="col-8 col-md-9 text-break"><?= htmlspecialchars($member['email']) ?></div></div>
                        <div class="row"><div class="col-4 col-md-3">Province</div><div class="col-8 col-md-9"><?= htmlspecialchars($member['province']) ?></div></div>
                        <div class="row"><div class="col-4 col-md-3">District</div><div class="col-8 col-md-9"><?= htmlspecialchars($member['district']) ?></div></div>
                        <div class="row"><div class="col-4 col-md-3">City / Town</div><div class="col-8 col-md-9"><?= htmlspecialchars($member['city']) ?></div></div>
                        <div class="row"><div class="col-4 col-md-3">Phone</div><div class="col-8 col-md-9"><?= htmlspecialchars($member['phone']) ?></div></div>
                        <div class="row"><div class="col-4 col-md-3">Address</div><div class="col-8 col-md-9"><?= nl2br(htmlspecialchars($member['address'])) ?></div></div>
                        <div class="row"><div class="col-4 col-md-3">Gender</div><div class="col-8 col-md-9">
                            <?php
                            if (!empty($member['gender'])) {
                                $genderDisplay = htmlspecialchars($member['gender']);
                                if ($member['gender'] == 'Other' && !empty($member['gender_custom'])) {
                                    $genderDisplay .= ' (' . htmlspecialchars($member['gender_custom']) . ')';
                                }
                                echo $genderDisplay;
                            } else {
                                echo 'Not specified';
                            }
                            ?>
                        </div></div>
                        <div class="row">
                            <div class="col-4 col-md-3">Polling Division</div>
                            <div class="col-8 col-md-9">
                                <?= htmlspecialchars($member['polling_division']) ?>
                                <?php if ($member['polling_division'] == 'Pending'): ?>
                                    <span class="badge bg-warning text-dark ms-2">Unverified</span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="row"><div class="col-4 col-md-3">Grama Niladhari Division</div><div class="col-8 col-md-9"><?= htmlspecialchars($member['gn_division']) ?></div></div>
                        <div class="row"><div class="col-4 col-md-3">Assigned Polling Booth</div><div class="col-8 col-md-9"><?= htmlspecialchars($member['assigned_polling_booth']) ?></div></div>
                        <div class="row"><div class="col-4 col-md-3">Registered On (UTC)</div><div class="col-8 col-md-9" data-utc-time="<?= $member['created_at'] ?>"><?= $member['created_at'] ?></div></div>
                    </div>

                    <!-- Photo Actions -->
                    <div class="mt-4 p-3 bg-light rounded-3">
                        <label class="fw-bold mb-2 d-block small text-uppercase text-muted">Profile Photo Actions</label>
                        <div class="d-flex flex-wrap gap-2">
                            <?php if ($member['profile_pic']): ?>
                                <a href="view_profile_pic.php?id=<?= $memberId ?>" target="_blank" class="btn btn-outline-dark flex-grow-1"><i class="bi bi-eye"></i> View Full</a>
                                <a href="download_profile_pic.php?id=<?= $memberId ?>" class="btn btn-success flex-grow-1"><i class="bi bi-download"></i> Download</a>
                            <?php else: ?>
                                <span class="text-muted">No photo uploaded</span>
                            <?php endif; ?>
                        </div>
                    </div>
                    <?php if ($canEdit): ?>
                        <div class="mt-4 d-grid d-md-block">
                            <a href="<?= BASE_URL ?>admin/edit_member?id=<?= $member['id'] ?>" class="btn btn-primary btn-lg px-5 rounded-pill"><i class="bi bi-pencil-square"></i> Edit Member</a>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>

    <!-- Documents Card -->
    <div class="card shadow-sm border-0 rounded-4">
        <div class="card-body p-4">
            <div class="d-flex justify-content-between align-items-center mb-4 flex-wrap gap-3">
                <h3 class="card-title mb-0">📎 Documents</h3>
                <?php if (!empty($docs)): ?>
                    <a href="<?= BASE_URL ?>admin/bulk_download?member_id=<?= $memberId ?>" class="btn btn-outline-primary rounded-pill"><i class="bi bi-file-zip"></i> Download All (ZIP)</a>
                <?php endif; ?>
            </div>
            <?php if (!empty($docs)): ?>
                <div class="table-responsive">
                    <table class="table table-hover align-middle">
                        <thead class="table-light"><tr><th>File Name</th><th class="d-none d-md-table-cell">Type</th><th class="text-end">Actions</th></tr></thead>
                        <tbody>
                            <?php foreach ($docs as $doc): ?>
                                <tr>
                                    <td class="fw-semibold"><?= htmlspecialchars($doc['document_name']) ?></td>
                                    <td class="d-none d-md-table-cell text-muted small"><?= htmlspecialchars($doc['document_type']) ?></td>
                                    <td class="text-end">
                                        <div class="btn-group">
                                            <a href="<?= BASE_URL ?>admin/view_document?id=<?= $doc['id'] ?>" target="_blank" class="btn btn-sm btn-light border" title="View"><i class="bi bi-eye"></i></a>
                                            <a href="<?= BASE_URL ?>admin/download_document?id=<?= $doc['id'] ?>" class="btn btn-sm btn-light border text-success" title="Download"><i class="bi bi-download"></i></a>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php else: ?>
                <div class="text-center py-4"><i class="bi bi-folder-x display-4 text-muted"></i><p class="text-muted mt-2">No documents found.</p></div>
            <?php endif; ?>
        </div>
    </div>
</main>

<!-- footer (admin) includes report issue modal -->
<?php include '../includes/footer_admin.php'; ?>
