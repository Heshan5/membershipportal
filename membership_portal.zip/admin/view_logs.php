<?php
/**
 * Membership Portal.
 * Error Log Viewer & Email Success Log Viewer.
 *
 * Allows primary admin (id=1) to view, download, and clear the error log file,
 * and also to view (and optionally download) the email success log.
 *
 * @package    MembershipPortal.
 * @author     Heshan Shibry <heshan.shib@gmail.com>
 * @copyright  2026 HESHAN SHIBRY.
 * @license    Proprietary - All rights reserved.
 * @version    1.0.0.
 */
require_once '../includes/auth.php';
$pdo = getDB();
validateAdminSession($pdo);
$isSuperAdmin = ($_SESSION['is_super_admin'] == 1);
$isPrimary = ($_SESSION['user_id'] == 1);

// Only primary admin (id=1) can access this page
if ($_SESSION['user_id'] != 1) {
    redirect('admin/dashboard');
}

// Fetch profile picture for navbar avatar
$stmt = $pdo->prepare("SELECT profile_pic FROM admins WHERE id = ?");
$stmt->execute([$_SESSION['user_id']]);
$avatarPic = $stmt->fetchColumn();

$errorLogFile = __DIR__ . '/../logs/error.log';
$successLogFile = __DIR__ . '/../logs/email_success.log';
$message = '';
$warning = '';

// Handle clearing the error log
if (isset($_POST['clear_log'])) {
    if (file_exists($errorLogFile)) {
        file_put_contents($errorLogFile, '');
        $message = "Error log file cleared successfully.";
    } else {
        $warning = "Error log file does not exist yet. Nothing to clear.";
    }
}

// Read the error log file (last 1000 lines)
$errorLogContent = '';
if (file_exists($errorLogFile)) {
    $lines = file($errorLogFile);
    $lastLines = array_slice($lines, -1000);
    $errorLogContent = implode('', $lastLines);
} else {
    $errorLogContent = "No error log file found. (It will be created when the first error occurs.)";
}

// Read the success log file (last 1000 lines)
$successLogContent = '';
if (file_exists($successLogFile)) {
    $lines = file($successLogFile);
    $lastLines = array_slice($lines, -1000);
    $successLogContent = implode('', $lastLines);
} else {
    $successLogContent = "No email success log file found. (Will be created when first email is sent successfully.)";
}

// Download full error log
if (isset($_GET['download_error'])) {
    if (file_exists($errorLogFile)) {
        header('Content-Type: text/plain');
        header('Content-Disposition: attachment; filename="error_log_' . date('Y-m-d') . '.txt"');
        readfile($errorLogFile);
        exit;
    } else {
        die("Error log file not found yet.");
    }
}

// Download full success log
if (isset($_GET['download_success'])) {
    if (file_exists($successLogFile)) {
        header('Content-Type: text/plain');
        header('Content-Disposition: attachment; filename="email_success_log_' . date('Y-m-d') . '.txt"');
        readfile($successLogFile);
        exit;
    } else {
        die("Success log file not found yet.");
    }
}

$isLoggedIn = true;
$userRole = $_SESSION['role'];
$fullName = $_SESSION['full_name'];
$userId = $_SESSION['user_id'];
$hasGenerateReports = hasPermission('generate_reports');
$hasRestoreUsers = hasPermission('restore_users');
$baseUrl = BASE_URL;
$currentPage = 'view_logs';
$hideAdminLinks = false;
?>
<?php
// Set page title and optional custom styles
$page_title = 'Logs Viewer';
$page_styles = '
    <style>
    /* 1. Base Layout */
        body { display: flex; flex-direction: column; min-height: 100vh; }
        main { flex: 1 0 auto; }
        footer { flex-shrink: 0; }

        /* 2. Terminal Styling */
        pre {
            background: #1e1e1e;
            color: #d4d4d4;
            padding: 15px;
            border-radius: 10px;
            font-size: 12px;
            max-height: 500px;
            overflow-y: auto;
        }
        .log-container {
            background: #1e1e1e;
            padding: 0;
            margin: 0;
        }
        .terminal-header {
            background: #333;
            padding: 8px 15px;
            display: flex;
            gap: 6px;
        }
        .dot {
            width: 10px;
            height: 10px;
            border-radius: 50%;
        }
        .red { background: #ff5f56; }
        .yellow { background: #ffbd2e; }
        .green { background: #27c93f; }

        .terminal-body {
            background: #1e1e1e;
            color: #d4d4d4;
            padding: 20px;
            margin: 0;
            font-family: "SFMono-Regular", Consolas, "Liberation Mono", Menlo, monospace;
            font-size: 13px;
            line-height: 1.6;
            max-height: 600px;
            overflow-y: auto;
            white-space: pre-wrap;
            word-break: break-all;
        }

        /* 3. Custom Scrollbars */
        .terminal-body::-webkit-scrollbar { width: 8px; }
        .terminal-body::-webkit-scrollbar-track { background: #1e1e1e; }
        .terminal-body::-webkit-scrollbar-thumb { background: #333; border-radius: 10px; }

        /* 4. Navbar & Avatar Fixes */
        .navbar .dropdown-toggle {
            display: flex !important;
            align-items: center !important;
            gap: 3px !important;
            line-height: 1 !important;
        }
        .navbar .dropdown-toggle img,
        .navbar .dropdown-toggle i {
            display: inline-block;
            vertical-align: middle;
        }

        /* 5. Tab Styling */
        .nav-tabs .nav-link {
            border: none;
            border-bottom: 2px solid transparent;
            color: #495057;
            font-weight: 500;
            transition: all 0.3s ease;
        }
        .nav-tabs .nav-link.active {
            border-bottom-color: #0a2f44;
            color: #0a2f44;
            background: transparent;
        }
        .tab-pane { background: transparent; }

        /* 6. MOBILE FIX: Button Centering & Path Alignment */
        @media (max-width: 576px) {
            .terminal-body {
                font-size: 11px;
                padding: 15px;
            }
            .bg-light.justify-content-between {
                flex-direction: column !important;
                justify-content: center !important;
                align-items: center !important;
                text-align: center !important;
                padding: 18px 15px !important;
            }
            .bg-light .font-monospace {
                width: 100%;
                margin-bottom: 12px !important;
                font-size: 0.75rem;
                opacity: 0.8;
            }
            .bg-light .d-flex.gap-2 {
                justify-content: center !important;
                width: 100%;
            }
            .bg-light .btn-sm {
                padding: 8px 18px !important;
                font-size: 0.85rem;
                display: inline-flex;
                align-items: center;
                justify-content: center;
            }
        }
    </style>
';

// Include the global header
include '../includes/header.php';
?>

  <!-- Shared navbar (admin) -->
  <?php include '../includes/navbar.php'; ?>

  <main class="container my-4 my-md-5">
    <div class="card shadow-sm border-0 rounded-4 overflow-hidden">
        <div class="card-header bg-white py-3 border-bottom-0">
            <div class="d-flex justify-content-between align-items-center flex-wrap gap-3">
                <h2 class="h4 mb-0 fw-bold text-dark"><i class="bi bi-journal-code text-primary"></i> System Logs</h2>
            </div>
        </div>

        <div class="card-body p-0">
          <!-- ========== MODERNIZED LOGS SUCCESS NOTIFICATION ========== -->
          <?php if ($message): ?>
              <div class="alert alert-success d-flex align-items-center alert-dismissible fade show border-0 border-start border-4 border-success shadow-sm mx-3 mt-3 mb-2" role="alert">
                  <!-- Modern Bootstrap SVG Check Circle Icon -->
                  <svg xmlns="http://www.w3.org/2000/svg" width="22" height="22" fill="currentColor" class="bi bi-check-circle-fill me-3 flex-shrink-0" viewBox="0 0 16 16">
                      <path d="M16 8A8 8 0 1 1 0 8a8 8 0 0 1 16 0m-3.97-3.03a.75.75 0 0 0-1.08.022L7.477 9.417 5.384 7.323a.75.75 0 0 0-1.06 1.06L6.97 11.03a.75.75 0 0 0 1.079-.02l3.992-4.99a.75.75 0 0 0-.01-1.05z"/>
                  </svg>
                  <div class="small fw-semibold"><?= $message ?></div>
                  <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
              </div>
          <?php endif; ?>

          <!-- ========== MODERNIZED LOGS WARNING NOTIFICATION ========== -->
          <?php if ($warning): ?>
              <div class="alert alert-warning d-flex align-items-center alert-dismissible fade show border-0 border-start border-4 border-warning shadow-sm mx-3 mt-3 mb-2" role="alert">
                  <!-- Modern Bootstrap SVG Shield Alert Icon -->
                  <svg xmlns="http://www.w3.org/2000/svg" width="22" height="22" fill="currentColor" class="bi bi-shield-fill-exclamation me-3 flex-shrink-0" viewBox="0 0 16 16">
                      <path d="M8 0c-.69 0-1.843.265-2.928.56-1.11.3-2.229.655-2.887.87a1.54 1.54 0 0 0-1.044 1.262c-.596 4.477.787 7.795 2.465 9.99a11.8 11.8 0 0 0 2.517 2.453c.386.273.744.482 1.048.625.28.132.581.24.829.24s.548-.108.829-.24a7 7 0 0 0 1.048-.625 11.8 11.8 0 0 0 2.517-2.453c1.678-2.195 3.061-5.513 2.465-9.99a1.54 1.54 0 0 0-1.044-1.263 63 63 0 0 0-2.887-.87C9.843.266 8.69 0 8 0zm-.002 11a1 1 0 1 1 0-2 1 1 0 0 1 0 2zM9 4.5V8a1 1 0 0 1-2 0V4.5a1 1 0 0 1 2 0z"/>
                  </svg>
                  <div class="small fw-semibold"><?= $warning ?></div>
                  <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
              </div>
          <?php endif; ?>

            <!-- Tab navigation -->
            <ul class="nav nav-tabs px-3 pt-2" id="logsTab" role="tablist">
                <li class="nav-item" role="presentation">
                    <button class="nav-link active" id="error-tab" data-bs-toggle="tab" data-bs-target="#error" type="button" role="tab">🐞 Error Logs</button>
                </li>
                <li class="nav-item" role="presentation">
                    <button class="nav-link" id="success-tab" data-bs-toggle="tab" data-bs-target="#success" type="button" role="tab">📧 Email Success Logs</button>
                </li>
            </ul>

            <!-- Tab panes -->
            <div class="tab-content">
                <!-- Error Log Pane -->
                <div class="tab-pane fade show active" id="error" role="tabpanel">
                  <div class="bg-light px-4 py-2 border-top border-bottom d-flex align-items-center justify-content-between flex-wrap gap-3">
                      <small class="text-muted fw-medium font-monospace">PATH: logs/error.log</small>
                      <div class="d-flex align-items-center gap-2">
                          <?php if (file_exists($errorLogFile)): ?>
                              <a href="?download_error=1" class="btn btn-outline-primary btn-sm rounded-pill px-3 d-flex align-items-center" style="height: 32px;">
                                  <i class="bi bi-download me-1"></i> Download
                              </a>
                              <form method="POST" onsubmit="return confirm('Clear entire error log? This cannot be undone.')" class="m-0">
                                  <button type="submit" name="clear_log" class="btn btn-outline-danger btn-sm rounded-pill px-3 d-flex align-items-center" style="height: 32px;">
                                      <i class="bi bi-trash3 me-1"></i> Clear Log
                                  </button>
                              </form>
                          <?php else: ?>
                              <span class="text-muted small">(Log file not created yet)</span>
                          <?php endif; ?>
                      </div>
                    </div>
                    <div class="log-container">
                        <div class="terminal-header">
                            <span class="dot red"></span>
                            <span class="dot yellow"></span>
                            <span class="dot green"></span>
                        </div>
                        <pre class="terminal-body"><?= htmlspecialchars($errorLogContent) ?></pre>
                    </div>
                </div>

                <!-- Success Log Pane -->
                <div class="tab-pane fade" id="success" role="tabpanel">
                  <!-- For the Success Log Pane -->
                    <div class="bg-light px-4 py-2 border-top border-bottom d-flex align-items-center justify-content-between flex-wrap gap-3">
                      <small class="text-muted fw-medium font-monospace">PATH: logs/email_success.log</small>
                      <div class="d-flex align-items-center gap-2">
                          <?php if (file_exists($successLogFile)): ?>
                              <a href="?download_success=1" class="btn btn-outline-success btn-sm rounded-pill px-3 d-flex align-items-center" style="height: 32px;">
                                  <i class="bi bi-download me-1"></i> Download
                              </a>
                          <?php else: ?>
                              <span class="text-muted small">(Log file not created yet)</span>
                          <?php endif; ?>
                      </div>
                    </div>
                    <div class="log-container">
                        <div class="terminal-header">
                            <span class="dot green"></span>
                            <span class="dot yellow"></span>
                            <span class="dot red"></span>
                        </div>
                        <pre class="terminal-body"><?= htmlspecialchars($successLogContent) ?></pre>
                    </div>
                </div>
            </div>
        </div>
    </div>
  </main>

  <!-- footer (admin) includes report issue modal -->
  <?php include '../includes/footer_admin.php'; ?>
