<?php
/**
 * Membership Portal – Admin Dashboard
 *
 * - Lists all members with full geographic and political columns.
 * - Highlights rows where polling_division = 'Pending' (yellow background).
 * - UTC timestamps converted to local time via data-utc-time.
 * - Added Gender column (with custom text for 'Other').
 *
 * @package    MembershipPortal.
 * @author     Heshan Shibry <heshan.shib@gmail.com>
 * @copyright  2026 HESHAN SHIBRY.
 * @license    Proprietary - All rights reserved.
 * @version    1.0.0.
 */
require_once '../includes/auth.php';
$pdo = getDB();
validateAdminSession($pdo);

// Navbar variables (same as before)
$stmt = $pdo->prepare("SELECT profile_pic FROM admins WHERE id = ?");
$stmt->execute([$_SESSION['user_id']]);
$avatarPic = $stmt->fetchColumn();

$isLoggedIn = true;
$userRole = $_SESSION['role'];
$fullName = $_SESSION['full_name'];
$userId = $_SESSION['user_id'];
$hasGenerateReports = hasPermission('generate_reports');
$hasRestoreUsers = hasPermission('restore_users');
$baseUrl = BASE_URL;

if (!hasPermission(PERM_VIEW_MEMBERS)) {
    redirect('');
}

$isPrimary = ($_SESSION['user_id'] == 1);
$isSuperAdmin = ($_SESSION['is_super_admin'] == 1);
$canFilter = hasPermission('filter_members');

$filter_name = isset($_GET['name']) ? trim($_GET['name']) : '';
$filter_district = isset($_GET['district']) ? trim($_GET['district']) : '';

// Select all needed columns (including gender)
$sql = "SELECT id, member_id, full_name, email, province, district, city, phone, created_at,
               polling_division, gender, gender_custom
        FROM members WHERE 1=1";
$params = [];

if (!empty($filter_name)) {
    $sql .= " AND (full_name LIKE :name OR email LIKE :name OR member_id LIKE :name)";
    $params[':name'] = "%$filter_name%";
}
if (!empty($filter_district)) {
    $sql .= " AND district = :district";
    $params[':district'] = $filter_district;
}
$sql .= " ORDER BY created_at ASC";

$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$members = $stmt->fetchAll();

$districts = $pdo->query("SELECT DISTINCT district FROM members ORDER BY district")->fetchAll(PDO::FETCH_COLUMN);
$canDelete = hasPermission(PERM_DELETE_MEMBERS);

// Check for pending master addresses (only for admins with edit_members permission)
$pendingCount = 0;
if (hasPermission('edit_members')) {
    $stmt = $pdo->prepare("SELECT COUNT(*) FROM master_addresses WHERE status = 'pending'");
    $stmt->execute();
    $pendingCount = $stmt->fetchColumn();
}

$page_title = 'Dashboard';
$page_styles = '
    <style>
    body { display: flex; flex-direction: column; min-height: 100vh; }
    main { flex: 1 0 auto; }
    footer { flex-shrink: 0; }
    .filter-card { background: #f8f9fa; border-radius: 16px; }

    .navbar .dropdown-toggle {
        display: flex !important;
        align-items: center !important;
        gap: 3px !important;
        line-height: 1 !important;
    }
    .navbar .dropdown-toggle img,
    .navbar .dropdown-toggle i {
        display: inline-block;
        vertical-align: middle;
    }

    select.form-select {
        cursor: pointer;
    }

    /* Removes the puffy bubble shape from filters on the member page */
    .filter-card .form-control {
        border-radius: 6px !important;
        height: 38px !important;
    }

    /* FIXES THE SELECT DROPDOWN CUT-OFF: Balances height, line-height, and padding */
    .filter-card .form-select {
        border-radius: 6px !important;
        height: 38px !important;
        padding-top: 0.35rem !important;    /* Shrinks top thick spacing */
        padding-bottom: 0.35rem !important; /* Shrinks bottom thick spacing */
        line-height: 1.5 !important;        /* Centers text exactly inside the box */
    }

    /* Removes the puffy bubble shape from the dashboard filter elements */
    #dashboardFilterForm .form-control,
    #dashboardFilterForm .form-select {
        border-radius: 6px !important;
        height: 38px !important;
        margin-bottom: 0 !important;
        width: 100% !important; /* Lets inputs fill their wrappers naturally */
    }

    /* Fixes the dropdown inner text padding baseline layout constraints */
    #dashboardFilterForm .form-select {
        padding-top: 0.35rem !important;
        padding-bottom: 0.35rem !important;
        line-height: 1.5 !important;
    }

    /* Strips away puffy pill bubbles from the main dashboard button row */
    #dashboardFilterForm .btn {
        height: 38px !important;
        border-radius: 6px !important;
        padding: 0 1.25rem !important;
        display: inline-flex !important;
        align-items: center !important;
        justify-content: center !important;
        font-size: 0.875rem !important;
        transition: all 0.15s ease-in-out !important;
    }

    /* Premium Dark configuration for the main Dashboard Clear Button */
    #dashboardFilterForm .btn-dark {
        background-color: #212529 !important;
        border-color: #212529 !important;
        color: #ffffff !important;
    }
    #dashboardFilterForm .btn-dark:hover {
        background-color: #424649 !important;
        border-color: #373b3e !important;
        color: #ffffff !important;
    }

    /* ==========================================================================
       DESKTOP ONLY SIZING RULES: Enforces exact width specifications safely
       ========================================================================== */
    @media (min-width: 768px) {
        /* Locks the Search input wrapper precisely to 350px width */
        #dashboardFilterForm .filter-search-wrap {
            max-width: 350px !important;
            min-width: 350px !important;
        }

        /* Locks the District dropdown wrapper precisely to 300px width */
        #dashboardFilterForm .filter-district-wrap {
            max-width: 300px !important;
            min-width: 300px !important;
        }
    }
    </style>
';

// Include the global header
include '../includes/header.php';
?>

      <!-- Shared navbar (admin) -->
      <?php $currentPage = 'dashboard';
        include '../includes/navbar.php';
      ?>

    <main class="container my-5">
      <!-- ========== REPORT SENT (SUCCESS FLASH SESSION) ========== -->
        <?php if (isset($_SESSION['report_sent'])): ?>
          <div class="alert alert-success d-flex align-items-center alert-dismissible fade show border-0 border-start border-4 border-success shadow-sm mb-4" role="alert">
              <!-- Modern Bootstrap SVG Check Circle Icon -->
              <svg xmlns="http://www.w3.org/2000/svg" width="22" height="22" fill="currentColor" class="bi bi-check-circle-fill me-3 flex-shrink-0" viewBox="0 0 16 16">
                  <path d="M16 8A8 8 0 1 1 0 8a8 8 0 0 1 16 0m-3.97-3.03a.75.75 0 0 0-1.08.022L7.477 9.417 5.384 7.323a.75.75 0 0 0-1.06 1.06L6.97 11.03a.75.75 0 0 0 1.079-.02l3.992-4.99a.75.75 0 0 0-.01-1.05z"/>
              </svg>
              <div class="small fw-semibold"><?= $_SESSION['report_sent'] ?></div>
              <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
          </div>
          <?php unset($_SESSION['report_sent']); ?>
        <?php endif; ?>

        <!-- ========== REPORT ERROR (DANGER FLASH SESSION) ========== -->
        <?php if (isset($_SESSION['report_error'])): ?>
          <div class="alert alert-danger d-flex align-items-center border-0 border-start border-4 border-danger shadow-sm mb-4" role="alert">
              <!-- Modern Bootstrap SVG Exclamation Warning Icon -->
              <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="currentColor" class="bi bi-exclamation-triangle-fill me-3 flex-shrink-0" viewBox="0 0 16 16">
                  <path d="M8.982 1.566a1.13 1.13 0 0 0-1.96 0L.165 13.233c-.457.778.091 1.767.98 1.767h13.713c.889 0 1.438-.99.98-1.767zM8 5c.535 0 .954.462.9.995l-.35 3.507a.552.552 0 0 1-1.1 0L7.1 5.995A.905.905 0 0 1 8 5m.002 6a1 1 0 1 1 0 2 1 1 0 0 1 0-2"/>
              </svg>
              <div class="small fw-semibold"><?= $_SESSION['report_error'] ?></div>
          </div>
          <?php unset($_SESSION['report_error']); ?>
        <?php endif; ?>

        <!-- ========== REPORT WARNING (QUEUED EMAIL) ========== -->
        <?php if (isset($_SESSION['report_warning'])): ?>
          <div class="alert alert-warning d-flex align-items-center alert-dismissible fade show border-0 border-start border-4 border-warning shadow-sm mb-4" role="alert">
              <!-- Modern Bootstrap SVG Shield Alert Icon -->
              <svg xmlns="http://www.w3.org/2000/svg" width="22" height="22" fill="currentColor" class="bi bi-shield-fill-exclamation me-3 flex-shrink-0" viewBox="0 0 16 16">
                  <path d="M8 0c-.69 0-1.843.265-2.928.56-1.11.3-2.229.655-2.887.87a1.54 1.54 0 0 0-1.044 1.262c-.596 4.477.787 7.795 2.465 9.99a11.8 11.8 0 0 0 2.517 2.453c.386.273.744.482 1.048.625.28.132.581.24.829.24s.548-.108.829-.24a7 7 0 0 0 1.048-.625 11.8 11.8 0 0 0 2.517-2.453c1.678-2.195 3.061-5.513 2.465-9.99a1.54 1.54 0 0 0-1.044-1.263 63 63 0 0 0-2.887-.87C9.843.266 8.69 0 8 0zm-.002 11a1 1 0 1 1 0-2 1 1 0 0 1 0 2zM9 4.5V8a1 1 0 0 1-2 0V4.5a1 1 0 0 1 2 0z"/>
              </svg>
              <div class="small fw-semibold"><?= $_SESSION['report_warning'] ?></div>
              <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
          </div>
          <?php unset($_SESSION['report_warning']); ?>
        <?php endif; ?>

        <!-- ========== DELETE SUCCESS (SUCCESS FLASH SESSION) ========== -->
        <?php if (isset($_SESSION['delete_success'])): ?>
          <div class="alert alert-success d-flex align-items-center alert-dismissible fade show border-0 border-start border-4 border-success shadow-sm mb-4" role="alert">
              <svg xmlns="http://www.w3.org/2000/svg" width="22" height="22" fill="currentColor" class="bi bi-check-circle-fill me-3 flex-shrink-0" viewBox="0 0 16 16">
                  <path d="M16 8A8 8 0 1 1 0 8a8 8 0 0 1 16 0m-3.97-3.03a.75.75 0 0 0-1.08.022L7.477 9.417 5.384 7.323a.75.75 0 0 0-1.06 1.06L6.97 11.03a.75.75 0 0 0 1.079-.02l3.992-4.99a.75.75 0 0 0-.01-1.05z"/>
              </svg>
              <div class="small fw-semibold">
                  <?= $_SESSION['delete_success']; unset($_SESSION['delete_success']); ?>
              </div>
              <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
          </div>
        <?php endif; ?>

        <!-- ========== DELETE ERROR (DANGER FLASH SESSION) ========== -->
        <?php if (isset($_SESSION['delete_error'])): ?>
          <div class="alert alert-danger d-flex align-items-center border-0 border-start border-4 border-danger shadow-sm mb-4" role="alert">
              <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="currentColor" class="bi bi-exclamation-triangle-fill me-3 flex-shrink-0" viewBox="0 0 16 16">
                  <path d="M8.982 1.566a1.13 1.13 0 0 0-1.96 0L.165 13.233c-.457.778.091 1.767.98 1.767h13.713c.889 0 1.438-.99.98-1.767zM8 5c.535 0 .954.462.9.995l-.35 3.507a.552.552 0 0 1-1.1 0L7.1 5.995A.905.905 0 0 1 8 5m.002 6a1 1 0 1 1 0 2 1 1 0 0 1 0-2"/>
              </svg>
              <div class="small fw-semibold">
                  <?= $_SESSION['delete_error']; unset($_SESSION['delete_error']); ?>
              </div>
          </div>
        <?php endif; ?>

        <!-- ========== PENDING VERIFICATION COUNT (WARNING NOTIFICATION) ========== -->
        <?php if ($pendingCount > 0): ?>
          <div class="alert alert-warning d-flex align-items-center alert-dismissible fade show border-0 border-start border-4 border-warning shadow-sm mb-4" role="alert">
              <!-- Modern Bootstrap SVG Shield Alert Icon -->
              <svg xmlns="http://www.w3.org/2000/svg" width="22" height="22" fill="currentColor" class="bi bi-shield-fill-exclamation me-3 flex-shrink-0" viewBox="0 0 16 16">
                  <path d="M8 0c-.69 0-1.843.265-2.928.56-1.11.3-2.229.655-2.887.87a1.54 1.54 0 0 0-1.044 1.262c-.596 4.477.787 7.795 2.465 9.99a11.8 11.8 0 0 0 2.517 2.453c.386.273.744.482 1.048.625.28.132.581.24.829.24s.548-.108.829-.24a7 7 0 0 0 1.048-.625 11.8 11.8 0 0 0 2.517-2.453c1.678-2.195 3.061-5.513 2.465-9.99a1.54 1.54 0 0 0-1.044-1.263 63 63 0 0 0-2.887-.87C9.843.266 8.69 0 8 0zm-.002 11a1 1 0 1 1 0-2 1 1 0 0 1 0 2zM9 4.5V8a1 1 0 0 1-2 0V4.5a1 1 0 0 1 2 0z"/>
              </svg>
              <div>
                  <strong><?= $pendingCount ?> new address(es)</strong> need verification.
                  <a href="<?= BASE_URL ?>admin/verify_addresses" class="alert-link ms-1">Review them now →</a>
              </div>
              <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
          </div>
        <?php endif; ?>

        <!-- ========== CRITICAL CRASH MONITOR (CRITICAL WARNING) ========== -->
        <?php
        $logFile = __DIR__ . '/../logs/error.log';
        $hasCriticalErrors = false;
        if (file_exists($logFile)) {
          $lines = file($logFile);
          $lastLines = array_slice($lines, -100);
          foreach ($lastLines as $line) {
              if (strpos($line, '[db]') !== false || strpos($line, '[email]') !== false || strpos($line, '[upload]') !== false) {
                  $hasCriticalErrors = true;
                  break;
              }
          }
        }
        if ($hasCriticalErrors && ($_SESSION['user_id'] == 1 || $_SESSION['is_super_admin'] == 1)) {
          $errorLogUrl = BASE_URL . 'admin/view_logs';
          echo '<div class="alert alert-warning d-flex align-items-center alert-dismissible fade show border-0 border-start border-4 border-warning shadow-sm mb-4" role="alert">
                  <svg xmlns="http://www.w3.org/2000/svg" width="22" height="22" fill="currentColor" class="bi bi-shield-fill-exclamation me-3 flex-shrink-0" viewBox="0 0 16 16">
                      <path d="M8 0c-.69 0-1.843.265-2.928.56-1.11.3-2.229.655-2.887.87a1.54 1.54 0 0 0-1.044 1.262c-.596 4.477.787 7.795 2.465 9.99a11.8 11.8 0 0 0 2.517 2.453c.386.273.744.482 1.048.625.28.132.581.24.829.24s.548-.108.829-.24a7 7 0 0 0 1.048-.625 11.8 11.8 0 0 0 2.517-2.453c1.678-2.195 3.061-5.513 2.465-9.99a1.54 1.54 0 0 0-1.044-1.263 63 63 0 0 0-2.887-.87C9.843.266 8.69 0 8 0zm-.002 11a1 1 0 1 1 0-2 1 1 0 0 1 0 2zM9 4.5V8a1 1 0 0 1-2 0V4.5a1 1 0 0 1 2 0z"/>
                  </svg>
                  <div>
                      <strong>System errors detected!</strong> Please contact the primary administrator to review the <a href="' . $errorLogUrl . '" class="alert-link">error log</a>.
                  </div>
                  <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>';
        }
        ?>
          <div class="card shadow-sm border-0 rounded-4">
              <div class="card-body p-4">
                  <h2 class="card-title mb-4">📋 All Members (<?= count($members) ?>)</h2>
                  <?php if ($canFilter): ?>
                      <div class="filter-card p-3 mb-4">
                        <form method="GET" action="<?= BASE_URL ?>admin/dashboard" id="dashboardFilterForm" class="d-flex flex-column flex-md-row align-items-stretch align-items-md-end gap-3">
                            <!-- Added tracking selectors so the CSS can control sizing perfectly per device screen -->
                            <div class="w-100 w-md-auto filter-search-wrap">
                                <label class="form-label fw-semibold mb-1">Name / Email / Member ID</label>
                                <input type="text" name="name" class="form-control" placeholder="Search..." value="<?= htmlspecialchars($filter_name) ?>" required>
                            </div>
                            <div class="w-100 w-md-auto filter-district-wrap">
                                <label class="form-label fw-semibold mb-1">District</label>
                                <select name="district" class="form-select">
                                    <option value="">Select...</option>
                                    <?php foreach ($districts as $d): ?>
                                        <option value="<?= htmlspecialchars($d) ?>" <?= $filter_district == $d ? 'selected' : '' ?>><?= htmlspecialchars($d) ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <!-- Buttons float cleanly into place next to your fixed desktop modules -->
                            <div class="d-flex align-items-center gap-2 w-100 w-md-auto ms-md-auto mt-2 mt-md-0">
                                <button type="submit" class="btn btn-primary px-3 fw-medium flex-fill flex-md-grow-0 text-nowrap">
                                    <i class="bi bi-funnel"></i> Filter
                                </button>
                                <a href="<?= BASE_URL ?>admin/dashboard" class="btn btn-dark px-3 fw-medium d-inline-flex align-items-center justify-content-center gap-1 flex-fill flex-md-grow-0 text-nowrap">
                                    Clear
                                </a>
                            </div>
                        </form>
                      </div>
                  <?php endif; ?>
                  <div class="table-responsive">
                      <table class="table table-hover align-middle custom-admin-table">
                          <thead class="table-light">
                              <tr>
                                  <th class="ps-3">ID</th>
                                  <th>Member ID</th>
                                  <th>Full Name</th>
                                  <th>Email</th>
                                  <th>Province</th>
                                  <th>District</th>
                                  <th>City/Town</th>
                                  <th>Phone</th>
                                  <th>Gender</th>
                                  <th>Polling Division</th>
                                  <th>Registered On</th>
                                  <th class="text-end pe-3">Actions</th>
                              </tr>
                          </thead>
                          <tbody>
                              <?php foreach ($members as $m): ?>
                                  <tr class="<?= ($m['polling_division'] == 'Pending') ? 'table-warning' : '' ?>">
                                      <td class="ps-3 text-muted small">#<?= $m['id'] ?></td>
                                      <td><span class="badge bg-light text-dark border fw-medium"><?= htmlspecialchars($m['member_id']) ?></span></td>
                                      <td class="fw-bold text-dark"><?= htmlspecialchars($m['full_name']) ?></td>
                                      <td class="text-secondary"><?= htmlspecialchars($m['email']) ?></td>
                                      <td><?= htmlspecialchars($m['province']) ?></td>
                                      <td><?= htmlspecialchars($m['district']) ?></td>
                                      <td><?= htmlspecialchars($m['city']) ?></td>
                                      <td class="fw-semibold text-nowrap"><?= htmlspecialchars($m['phone']) ?></td>
                                      <td>
                                          <?php
                                          if (!empty($m['gender'])) {
                                              $genderDisplay = htmlspecialchars($m['gender']);
                                              if ($m['gender'] == 'Other' && !empty($m['gender_custom'])) {
                                                  $genderDisplay .= ' (' . htmlspecialchars($m['gender_custom']) . ')';
                                              }
                                              echo $genderDisplay;
                                          } else {
                                              echo '-';
                                          }
                                          ?>
                                       </td>
                                      <td><?= htmlspecialchars($m['polling_division']) ?></td>
                                      <td class="registration-date" data-utc-time="<?= $m['created_at'] ?>"><?= $m['created_at'] ?></td>
                                      <td class="text-end pe-3">
                                          <div class="d-flex justify-content-end gap-2">
                                              <a href="<?= BASE_URL ?>admin/view_member?id=<?= $m['id'] ?>" class="btn btn-sm btn-outline-primary px-3 rounded-pill">
                                                  <i class="bi bi-eye me-1"></i> View
                                              </a>
                                              <?php if (hasPermission('delete_members')): ?>
                                                  <button type="button" class="btn btn-sm btn-outline-danger px-3 rounded-pill"
                                                      data-bs-toggle="modal" data-bs-target="#deleteMemberModal"
                                                      data-member-id="<?= $m['id'] ?>"
                                                      data-member-name="<?= htmlspecialchars($m['full_name']) ?>"
                                                      data-member-id-display="<?= htmlspecialchars($m['member_id']) ?>">
                                                      <i class="bi bi-trash"></i> Delete
                                                  </button>
                                              <?php endif; ?>
                                          </div>
                                       </td>
                                   </tr>
                              <?php endforeach; ?>
                              <?php if (count($members) === 0): ?>
                                   <tr><td colspan="12" class="text-center text-muted">No members found.</td></tr>
                              <?php endif; ?>
                          </tbody>
                      </table>
                  </div>
              </div>
          </div>
      </main>

      <!-- Delete Member Modal (reason required) -->
      <div class="modal fade" id="deleteMemberModal" tabindex="-1" aria-labelledby="deleteMemberModalLabel" aria-hidden="true">
          <div class="modal-dialog">
              <div class="modal-content">
                  <form method="POST" action="<?= BASE_URL ?>admin/delete_member">
                      <input type="hidden" name="member_id" id="delete_member_id" value="">
                      <input type="hidden" name="tz_offset" id="tz_offset_member" value="">
                      <div class="modal-header bg-danger text-white">
                          <h5 class="modal-title" id="deleteMemberModalLabel"><i class="bi bi-exclamation-triangle"></i> Confirm Deletion</h5>
                          <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                      </div>
                      <div class="modal-body">
                          <p>You are about to delete the member:</p>
                          <p><strong id="delete_member_name"></strong> (<span id="delete_member_id_display"></span>)</p>
                          <p>This action will move the member and all associated documents to the trash.</p>
                          <div class="mb-3">
                              <label class="form-label">Reason for deletion <span class="text-danger">*</span></label>
                              <textarea name="reason" class="form-control" rows="3" placeholder="e.g., Duplicate entry, request from member, etc." required></textarea>
                          </div>
                      </div>
                      <div class="modal-footer">
                          <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                          <button type="submit" class="btn btn-danger">Delete Member</button>
                      </div>
                  </form>
              </div>
          </div>
      </div>

      <!-- footer (admin) includes report issue modal -->
      <?php include '../includes/footer_admin.php'; ?>
