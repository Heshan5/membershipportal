<?php
/**
 * Membership Portal.
 * Download a single document file.
 * Access: only admins with view_members permission.
 *
 * @package    MembershipPortal.
 * @author     Heshan Shibry <heshan.shib@gmail.com>
 * @copyright  2026 HESHAN SHIBRY.
 * @license    Proprietary - All rights reserved.
 * @version    1.0.0.
 */
require_once '../includes/auth.php';
$pdo = getDB();

if (!isset($_SESSION['user_id']) || !hasPermission(PERM_VIEW_MEMBERS)) {
    die('Unauthorized');
}

$docId = isset($_GET['id']) ? (int)$_GET['id'] : 0;
if (!$docId) die('Invalid document ID');

// Fetch document path and verify member exists
$stmt = $pdo->prepare("SELECT d.document_path, d.member_id, m.full_name FROM documents d JOIN members m ON d.member_id = m.id WHERE d.id = ?");
$stmt->execute([$docId]);
$doc = $stmt->fetch();
if (!$doc) die('Document not found');

$filePath = '../' . $doc['document_path'];
if (!file_exists($filePath)) die('File not found on server');

// Force download
header('Content-Description: File Transfer');
header('Content-Type: application/octet-stream');
header('Content-Disposition: attachment; filename="' . basename($doc['document_path']) . '"');
header('Expires: 0');
header('Cache-Control: must-revalidate');
header('Pragma: public');
header('Content-Length: ' . filesize($filePath));
readfile($filePath);
exit;
?>
