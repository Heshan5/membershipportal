<?php
/**
 * Membership Portal.
 * Admin Profile – Edit own information and change password.
 * Any logged-in admin can use this.
 * Also allows uploading a profile picture.
 * Includes cache‑busting for navbar avatar.
 *
 * UPDATED: Replaced hard‑coded district dropdown with province → district → city cascade.
 * Uses database‑driven geographic data (provinces, districts, cities).
 * UPDATED: Added gender selection (Male, Female, Other, Prefer not to say) with custom text for "Other".
 * UPDATED: Custom gender field now required when "Other" is selected.
 *
 * @package    MembershipPortal.
 * @author     Heshan Shibry <heshan.shib@gmail.com>
 * @copyright  2026 HESHAN SHIBRY.
 * @license    Proprietary - All rights reserved.
 * @version    1.0.0.
 */
require_once '../includes/auth.php';
$pdo = getDB();
validateAdminSession($pdo);
$baseUrl = BASE_URL;

if (!isset($_SESSION['user_id'])) {
    redirect('');
}

$userId = $_SESSION['user_id'];
$isPrimary = ($_SESSION['user_id'] == 1);
$isSuperAdmin = ($_SESSION['is_super_admin'] == 1);

$stmt = $pdo->prepare("SELECT * FROM admins WHERE id = ?");
$stmt->execute([$userId]);
$admin = $stmt->fetch();
if (!$admin) redirect('');

// Get current geographic IDs (province, district, city) from the stored city_id
$current_city_id = (int)$admin['city_id'];
$current_province_id = 0;
$current_district_id = 0;
if ($current_city_id) {
    $loc = $pdo->prepare("
        SELECT p.id as province_id, d.id as district_id
        FROM cities c
        JOIN districts d ON c.district_id = d.id
        JOIN provinces p ON d.province_id = p.id
        WHERE c.id = ?
    ");
    $loc->execute([$current_city_id]);
    $locData = $loc->fetch();
    if ($locData) {
        $current_province_id = $locData['province_id'];
        $current_district_id = $locData['district_id'];
    }
}

// Fetch all provinces for the dropdown
$provinces = $pdo->query("SELECT id, name_en, name_si, name_ta FROM provinces ORDER BY name_en")->fetchAll();

// Helper to format trilingual names
function formatTrilingual($name_en, $name_si, $name_ta) {
    $text = $name_en;
    if ($name_si && $name_ta) $text .= " ($name_si / $name_ta)";
    elseif ($name_si) $text .= " ($name_si)";
    elseif ($name_ta) $text .= " ($name_ta)";
    return htmlspecialchars($text);
}

// Cache busting for profile picture (so navbar avatar updates immediately)
$avatarCache = '';
if (!empty($admin['profile_pic']) && file_exists('../' . $admin['profile_pic'])) {
    $avatarCache = '?v=' . filemtime('../' . $admin['profile_pic']);
} else {
    $avatarCache = '?v=' . time();
}

// Parse stored phone
$phone_code = '';
$phone_number = '';
if (!empty($admin['phone'])) {
    $parts = explode(' ', $admin['phone'], 2);
    $phone_code = $parts[0] ?? '';
    $phone_number = $parts[1] ?? '';
}

$message = '';
$error = '';

// Handle profile picture upload
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['upload_pic'])) {
    if (isset($_FILES['profile_pic']) && $_FILES['profile_pic']['error'] === UPLOAD_ERR_OK) {
        $uploadPath = uploadFile('profile_pic', '../uploads/', ['jpg','jpeg','png'], 2*1024*1024);
        if ($uploadPath) {
            $uploadPath = str_replace('../', '', $uploadPath);
            if (!empty($admin['profile_pic']) && file_exists('../' . $admin['profile_pic'])) {
                unlink('../' . $admin['profile_pic']);
            }
            $stmt = $pdo->prepare("UPDATE admins SET profile_pic = ? WHERE id = ?");
            if ($stmt->execute([$uploadPath, $userId])) {
                $message = "Profile picture updated successfully.";
                // Refresh admin data
                $stmt = $pdo->prepare("SELECT * FROM admins WHERE id = ?");
                $stmt->execute([$userId]);
                $admin = $stmt->fetch();
                // Update cache busting after upload
                if (!empty($admin['profile_pic']) && file_exists('../' . $admin['profile_pic'])) {
                    $avatarCache = '?v=' . filemtime('../' . $admin['profile_pic']);
                } else {
                    $avatarCache = '?v=' . time();
                }
            } else {
                $error = "Failed to update profile picture.";
            }
        } else {
            $error = "File upload failed. Please use a JPG/PNG image under 2MB.";
        }
    } else {
        $error = "Please select a file to upload.";
    }
}

// Handle profile info update (name, email, geographic data, phone, address, gender) and password change
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_profile'])) {
    $full_name = sanitize($_POST['full_name']);
    $email = sanitize($_POST['email']);

    // ---------------------------------------------------------------
    // Geographic selections – safely get values (avoid undefined keys)
    // ---------------------------------------------------------------
    $province_id = isset($_POST['province']) ? (int)$_POST['province'] : 0;
    $district_id = isset($_POST['district']) ? (int)$_POST['district'] : 0;
    $city_id = isset($_POST['city']) ? (int)$_POST['city'] : 0;

    // Resolve names from IDs (only if ID > 0)
    $province_name = '';
    $district_name = '';
    $city_name = '';
    if ($province_id > 0) {
        $stmt = $pdo->prepare("SELECT name_en FROM provinces WHERE id = ?");
        $stmt->execute([$province_id]);
        $province_name = $stmt->fetchColumn() ?: '';
    }
    if ($district_id > 0) {
        $stmt = $pdo->prepare("SELECT name_en FROM districts WHERE id = ?");
        $stmt->execute([$district_id]);
        $district_name = $stmt->fetchColumn() ?: '';
    }
    if ($city_id > 0) {
        $stmt = $pdo->prepare("SELECT name_en FROM cities WHERE id = ?");
        $stmt->execute([$city_id]);
        $city_name = $stmt->fetchColumn() ?: '';
    } else {
        // If city_id is 0 (no city selected), set to NULL for foreign key constraint
        $city_id = null;
    }

    $phone_code = sanitize($_POST['phone_code'] ?? '');
    $phone_number = sanitize($_POST['phone_number'] ?? '');
    $phone = !empty($phone_code) && !empty($phone_number) ? $phone_code . ' ' . $phone_number : '';
    $address = sanitize($_POST['address']);
    $new_password = $_POST['new_password'] ?? '';
    $confirm_password = $_POST['confirm_password'] ?? '';

    // ----- GENDER HANDLING (start) -----
    $gender = sanitize($_POST['gender'] ?? '');
    $gender_custom = sanitize($_POST['gender_custom'] ?? '');

    // Allowed gender values
    $allowedGenders = ['Male', 'Female', 'Prefer not to say', 'Other'];
    if (!in_array($gender, $allowedGenders)) {
        $gender = null;
    }

    // If gender is NOT 'Other', force gender_custom to NULL
    if ($gender !== 'Other') {
        $gender_custom = null;
    } else {
        $gender_custom = trim($gender_custom);
        if (strlen($gender_custom) > 50) {
            $gender_custom = substr($gender_custom, 0, 50);
        }
        // CUSTOM TEXT MUST NOT BE EMPTY
        if (empty($gender_custom)) {
            $error = "Please specify your gender when selecting 'Other'.";
        }
    }
    // ----- GENDER HANDLING (end) -----

    // Email format validation
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = "Invalid email format. Please enter a valid email address.";
    } elseif (empty($full_name) || empty($email)) {
        $error = "Please fill in all required fields (Full Name, Email).";
    } else {
        // Check if email already exists for another admin (excluding current)
        $check = $pdo->prepare("SELECT id FROM admins WHERE email = ? AND id != ?");
        $check->execute([$email, $userId]);
        if ($check->fetch()) {
            $error = "Email already used by another admin.";
        } else {
            if (!empty($new_password)) {
                if ($new_password !== $confirm_password) {
                    $error = "New passwords do not match.";
                } elseif (!isStrongPassword($new_password)) {
                    $error = "Password must be at least 8 characters and include uppercase, lowercase, digit, and special character (e.g., @, #, $, %).";
                } else {
                    $hashed = password_hash($new_password, PASSWORD_DEFAULT);
                    $stmt = $pdo->prepare("UPDATE admins SET password = ?, force_password_change = 0, temp_password_expires = NULL WHERE id = ?");
                    $stmt->execute([$hashed, $userId]);
                    $message = "Password updated successfully.";
                }
            }

            if (empty($error)) {
                // Update all fields, including geographic data and gender
                $stmt = $pdo->prepare("
                    UPDATE admins SET
                        full_name = ?, email = ?,
                        province = ?, district = ?, city = ?, city_id = ?,
                        phone = ?, address = ?, gender = ?, gender_custom = ?
                    WHERE id = ?
                ");
                if ($stmt->execute([$full_name, $email, $province_name, $district_name, $city_name, $city_id, $phone, $address, $gender, $gender_custom, $userId])) {
                    $message = $message ? $message . " Profile updated." : "Profile updated successfully.";
                    $_SESSION['full_name'] = $full_name;
                    // Refresh data
                    $stmt = $pdo->prepare("SELECT * FROM admins WHERE id = ?");
                    $stmt->execute([$userId]);
                    $admin = $stmt->fetch();
                    // Reparse phone
                    $parts = explode(' ', $admin['phone'], 2);
                    $phone_code = $parts[0] ?? '';
                    $phone_number = $parts[1] ?? '';
                    // Refresh current geographic IDs
                    $current_city_id = (int)$admin['city_id'];
                    if ($current_city_id) {
                        $loc = $pdo->prepare("
                            SELECT p.id as province_id, d.id as district_id
                            FROM cities c
                            JOIN districts d ON c.district_id = d.id
                            JOIN provinces p ON d.province_id = p.id
                            WHERE c.id = ?
                        ");
                        $loc->execute([$current_city_id]);
                        $locData = $loc->fetch();
                        if ($locData) {
                            $current_province_id = $locData['province_id'];
                            $current_district_id = $locData['district_id'];
                        }
                    } else {
                        $current_province_id = 0;
                        $current_district_id = 0;
                    }
                } else {
                    if (empty($new_password)) $error = "Failed to update profile.";
                }
            }
        }
    }
}
?>
<?php
// Set page title and optional custom styles
$page_title = 'My Profile - Admin';
$page_styles = '
    <style>
    body { display: flex; flex-direction: column; min-height: 100vh; }
    main { flex: 1 0 auto; }
    footer { flex-shrink: 0; }

    .profile-img-container {
        text-align: center;
        margin-bottom: 1.5rem;
    }
    .profile-img {
        width: 120px;
        height: 120px;
        border-radius: 50%;
        object-fit: cover;
        cursor: pointer;
        border: 2px solid #dee2e6;
        box-shadow: 0 4px 8px rgba(0,0,0,0.1);
        transition: opacity 0.2s;
    }
    .profile-img:hover {
        opacity: 0.8;
    }
    .upload-hint {
        font-size: 0.8rem;
        color: #6c757d;
        margin-top: 0.5rem;
    }
    #fileInput {
        display: none;
    }
    .profile-img-container img,
    .profile-img-container i {
        display: inline-block;
        margin: 0 auto;
    }
    .navbar .dropdown-toggle {
          display: flex !important;
          align-items: center !important;
          gap: 3px !important;
          line-height: 1 !important;
      }
      .navbar .dropdown-toggle img,
      .navbar .dropdown-toggle i {
          display: inline-block;
          vertical-align: middle;
      }
    .form-check {
        display: flex;
        align-items: center;
        gap: 0.5rem;
    }
    .form-check-input {
        margin: 0;
        cursor: pointer;
    }
    select.form-select {
        cursor: pointer;
    }
    /* Truncate long text with dots (...) inside form controls */
    .form-select, .form-select option {
        text-overflow: ellipsis;
        overflow: hidden;
        white-space: nowrap;
    }
    </style>
';

// Include the global header
include '../includes/header.php';
?>

    <!-- UPDATED NAVBAR: Profile avatar outside hamburger, floating dropdown -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <div class="container">
            <!-- Logo / Brand -->
            <a class="navbar-brand fw-bold" href="<?= BASE_URL ?>admin/dashboard">
                NATIONAL BUILDER · MOVEMENT
            </a>

            <!-- Mobile Toggler (hamburger) -->
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>

            <!-- Profile dropdown - always visible on right, outside hamburger -->
            <ul class="navbar-nav order-lg-2">
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle d-flex align-items-center py-0" href="#" id="userDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                        <?php if ($admin['profile_pic'] && file_exists('../' . $admin['profile_pic'])): ?>
                            <img src="<?= BASE_URL ?>admin/view_admin_pic?id=<?= $_SESSION['user_id'] . $avatarCache ?>" alt="Profile" class="rounded-circle" width="32" height="32" style="object-fit: cover;">
                        <?php else: ?>
                            <i class="bi bi-person-circle" style="font-size: 1.8rem; line-height: 1;"></i>
                        <?php endif; ?>
                    </a>
                    <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="userDropdown">
                        <li class="dropdown-header"><?= htmlspecialchars($_SESSION['full_name']) ?></li>
                        <li><hr class="dropdown-divider"></li>
                        <li><a class="dropdown-item" href="<?= BASE_URL ?>admin/profile"><i class="bi bi-person"></i> My Profile</a></li>
                        <?php $showSettings = (hasPermission('restore_users') || $_SESSION['user_id'] == 1 || hasPermission('generate_reports')); if ($showSettings): ?>
                            <li><a class="dropdown-item" href="<?= BASE_URL ?>admin/settings"><i class="bi bi-gear"></i> Settings</a></li>
                        <?php endif; ?>
                        <?php if ($_SESSION['user_id'] != 1): ?>
                            <li><a class="dropdown-item" href="#" data-bs-toggle="modal" data-bs-target="#reportIssueModal"><i class="bi bi-envelope-exclamation"></i> Report Issue</a></li>
                        <?php endif; ?>
                        <li><hr class="dropdown-divider"></li>
                        <li><a class="dropdown-item" href="<?= $baseUrl ?>logout"><i class="bi bi-box-arrow-right"></i> Logout</a></li>
                    </ul>
                </li>
            </ul>

            <!-- Main navigation links (inside hamburger) -->
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item"><a class="nav-link" href="<?= BASE_URL ?>admin/dashboard">Dashboard</a></li>
                    <?php if ($isPrimary || $isSuperAdmin): ?>
                        <li class="nav-item"><a class="nav-link" href="<?= BASE_URL ?>admin/manage_admins">Manage Admins</a></li>
                        <li class="nav-item"><a class="nav-link" href="<?= BASE_URL ?>admin/manage_roles">Manage Roles</a></li>
                    <?php endif; ?>
                    <!-- NEW: Verify Addresses link – visible to anyone with edit_members permission -->
                    <?php if (hasPermission('edit_members')): ?>
                        <?php
                        // Count pending addresses (global $pdo is already available)
                        $pendingCount = 0;
                        $stmt = $pdo->query("SELECT COUNT(*) FROM master_addresses WHERE status = 'pending'");
                        if ($stmt) $pendingCount = $stmt->fetchColumn();
                        ?>
                        <li class="nav-item">
                            <a class="nav-link <?= ($currentPage == 'verify_addresses') ? 'active' : '' ?>" href="<?= $baseUrl ?>admin/verify_addresses">Verify Addresses
                                <?php if ($pendingCount > 0): ?>
                                    <span class="badge bg-warning text-dark ms-1"><?= $pendingCount ?></span>
                                <?php endif; ?>
                            </a>
                        </li>
                    <?php endif; ?>
                    <?php if (hasPermission('generate_reports')): ?>
                        <li class="nav-item"><a class="nav-link" href="<?= BASE_URL ?>admin/reports">Reports</a></li>
                    <?php endif; ?>
                </ul>
            </div>
        </div>
    </nav>

    <main class="container my-5">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card shadow-sm border-0 rounded-4">
                    <div class="card-body p-4 p-md-5">
                        <h2 class="card-title text-center mb-4">
                            My Profile
                            <?php if ($isSuperAdmin): ?>
                                <span class="badge bg-info">Super Admin</span>
                            <?php endif; ?>
                        </h2>
                        <!-- ========== SUCCESS MESSAGE BLOCK ========== -->
                          <?php if ($message): ?>
                              <div class="alert alert-success d-flex align-items-center alert-dismissible fade show border-0 border-start border-4 border-success shadow-sm mb-4" role="alert">
                                  <!-- Modern Bootstrap SVG Check Circle Icon -->
                                  <svg xmlns="http://www.w3.org/2000/svg" width="22" height="22" fill="currentColor" class="bi bi-check-circle-fill me-3 flex-shrink-0" viewBox="0 0 16 16">
                                      <path d="M16 8A8 8 0 1 1 0 8a8 8 0 0 1 16 0m-3.97-3.03a.75.75 0 0 0-1.08.022L7.477 9.417 5.384 7.323a.75.75 0 0 0-1.06 1.06L6.97 11.03a.75.75 0 0 0 1.079-.02l3.992-4.99a.75.75 0 0 0-.01-1.05z"/>
                                  </svg>
                                  <div class="small fw-semibold">
                                      <?= $message ?>
                                  </div>
                                  <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                              </div>
                          <?php endif; ?>

                          <!-- ========== ERROR MESSAGE BLOCK ========== -->
                          <?php if ($error): ?>
                              <div class="alert alert-danger d-flex align-items-center border-0 border-start border-4 border-danger shadow-sm mb-4" role="alert">
                                  <!-- Modern Bootstrap SVG Exclamation Warning Icon -->
                                  <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="currentColor" class="bi bi-exclamation-triangle-fill me-3 flex-shrink-0" viewBox="0 0 16 16">
                                      <path d="M8.982 1.566a1.13 1.13 0 0 0-1.96 0L.165 13.233c-.457.778.091 1.767.98 1.767h13.713c.889 0 1.438-.99.98-1.767zM8 5c.535 0 .954.462.9.995l-.35 3.507a.552.552 0 0 1-1.1 0L7.1 5.995A.905.905 0 0 1 8 5m.002 6a1 1 0 1 1 0 2 1 1 0 0 1 0-2"/>
                                  </svg>
                                  <div class="small fw-semibold">
                                      <?= $error ?>
                                  </div>
                              </div>
                          <?php endif; ?>

                        <!-- Profile Picture – Click to upload -->
                        <div class="profile-img-container mt-5 d-flex flex-column align-items-center">
                            <form method="POST" enctype="multipart/form-data" id="uploadForm">
                                <input type="file" name="profile_pic" id="fileInput" accept="image/jpeg,image/png" style="display: none;">
                                <input type="hidden" name="upload_pic" value="1">
                                <?php if ($admin['profile_pic']): ?>
                                    <img src="<?= BASE_URL ?>admin/view_admin_pic?id=<?= $userId ?>" alt="Profile Picture" class="profile-img" id="profileImg">
                                <?php else: ?>
                                    <div class="profile-img" style="background: #e9ecef; display: flex; align-items: center; justify-content: center; cursor: pointer;">
                                        <i class="bi bi-person" style="font-size: 60px; color: #adb5bd;"></i>
                                    </div>
                                <?php endif; ?>
                            </form>
                            <div class="upload-hint">Click the picture to change</div>
                        </div>

                        <hr>

                        <!-- Profile Information Form -->
                        <form method="POST" id="profileForm">
                            <input type="hidden" name="update_profile" value="1">
                            <div class="row">
                                <div class="col-md-6 mb-3">
                                    <label class="form-label fw-semibold">Full Name *</label>
                                    <input type="text" name="full_name" class="form-control" value="<?= htmlspecialchars($admin['full_name']) ?>" required>
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label class="form-label fw-semibold">Email *</label>
                                    <input type="email" name="email" class="form-control" value="<?= htmlspecialchars($admin['email']) ?>" required>
                                </div>
                            </div>

                            <!-- Gender Field (required, custom text required for "Other") -->
                            <div class="row">
                                <div class="col-md-6 mb-3">
                                    <label class="form-label fw-semibold">Gender *</label>
                                    <select id="genderSelect" name="gender" class="form-select" required>
                                        <option value="" <?= empty($admin['gender']) ? 'selected' : '' ?>>Select...</option>
                                        <option value="Male" <?= ($admin['gender'] == 'Male') ? 'selected' : '' ?>>Male</option>
                                        <option value="Female" <?= ($admin['gender'] == 'Female') ? 'selected' : '' ?>>Female</option>
                                        <option value="Prefer not to say" <?= ($admin['gender'] == 'Prefer not to say') ? 'selected' : '' ?>>Prefer not to say</option>
                                        <option value="Other" <?= ($admin['gender'] == 'Other') ? 'selected' : '' ?>>Other</option>
                                    </select>
                                </div>
                                <div class="col-md-6 mb-3" id="genderSpecifyWrapper" style="display: <?= ($admin['gender'] == 'Other') ? 'block' : 'none' ?>;">
                                    <label class="form-label fw-semibold">Please specify *</label>
                                    <input type="text" id="genderSpecifyInput" name="gender_custom" class="form-control" placeholder="e.g., Non-binary" value="<?= htmlspecialchars($admin['gender_custom'] ?? '') ?>">
                                </div>
                            </div>

                            <!-- Geographic Hierarchy (Province -> District -> City) – optional -->
                            <div class="row align-items-end g-3 mb-3">
                                <div class="col-md-4">
                                    <label class="form-label fw-semibold">Province</label>
                                    <select id="provinceSelect" name="province" class="form-select">
                                        <option value="">Select Province</option>
                                        <?php foreach ($provinces as $p): ?>
                                            <option value="<?= $p['id'] ?>" <?= ($current_province_id == $p['id']) ? 'selected' : '' ?>>
                                                <?= formatTrilingual($p['name_en'], $p['name_si'], $p['name_ta']) ?>
                                            </option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                                <div class="col-md-4">
                                    <label class="form-label fw-semibold">District</label>
                                    <select id="districtSelect" name="district" class="form-select" <?= $current_district_id ? '' : 'disabled' ?>>
                                        <option value="">Select...</option>
                                    </select>
                                </div>
                                <div class="col-md-4">
                                    <label class="form-label fw-semibold">City / Town</label>
                                    <select id="citySelect" name="city" class="form-select" <?= $current_city_id ? '' : 'disabled' ?>>
                                        <option value="">Select...</option>
                                    </select>
                                </div>
                            </div>

                            <div class="col-md-4 mb-3">
                                <label class="form-label fw-semibold">Admin ID (read-only)</label>
                                <input type="text" class="form-control bg-light" value="<?= htmlspecialchars($admin['admin_id']) ?>" readonly>
                            </div>
                            <div class="col-md-5 mb-3">
                                <label class="form-label fw-semibold">Phone (optional)</label>
                                <div class="row g-2">
                                    <div class="col-4">
                                        <select name="phone_code" class="form-select">
                                            <option value="+94" <?= $phone_code == '+94' ? 'selected' : '' ?>>+94</option>
                                            <option value="+91" <?= $phone_code == '+91' ? 'selected' : '' ?>>+91</option>
                                            <option value="+1" <?= $phone_code == '+1' ? 'selected' : '' ?>>+1</option>
                                            <option value="+44" <?= $phone_code == '+44' ? 'selected' : '' ?>>+44</option>
                                            <option value="+61" <?= $phone_code == '+61' ? 'selected' : '' ?>>+61</option>
                                            <option value="+971" <?= $phone_code == '+971' ? 'selected' : '' ?>>+971</option>
                                        </select>
                                    </div>
                                    <div class="col-8">
                                        <input type="tel" name="phone_number" class="form-control" placeholder="712345678" pattern="[0-9]{7,10}" title="7 to 10 digits" value="<?= htmlspecialchars($phone_number) ?>">
                                    </div>
                                </div>
                                <small class="text-muted">Select country code and enter local number (without leading zero).</small>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label class="form-label fw-semibold">Address</label>
                                <textarea name="address" rows="2" class="form-control"><?= htmlspecialchars($admin['address']) ?></textarea>
                            </div>
                            <hr>
                            <h5 class="mb-3">Change Password (optional)</h5>
                            <p class="text-muted small mb-3 text-center">
                                🔒 <strong>Password Requirements:</strong> Minimum 8 characters, a mix of UPPER and lower case, at least one digit, and a symbol (like @, #, $, %).
                            </p>
                            <div class="row">
                                <div class="col-md-6 mb-3">
                                    <label class="form-label fw-semibold">New Password</label>
                                    <input type="password" name="new_password" id="NewPassword" class="form-control">
                                    <div class="form-check mt-2">
                                        <input class="form-check-input" type="checkbox" id="showPasswordCheckbox1">
                                        <label class="form-check-label" for="showPasswordCheckbox1">
                                            Show password
                                        </label>
                                    </div>
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label class="form-label fw-semibold">Confirm New Password</label>
                                    <input type="password" name="confirm_password" id="ConfirmNewPassword" class="form-control">
                                    <div class="form-check mt-2">
                                        <input class="form-check-input" type="checkbox" id="showPasswordCheckbox2">
                                        <label class="form-check-label" for="showPasswordCheckbox2">
                                            Show password
                                        </label>
                                    </div>
                                </div>
                            </div>
                            <button type="submit" class="btn btn-dark w-100 py-2" id="profileSubmitBtn">Update Profile</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </main>

    <!-- JavaScript for cascade dropdowns, gender toggle, and password visibility -->
    <script>
        // Show/hide password for New Password field
        document.getElementById('showPasswordCheckbox1').addEventListener('change', function() {
            const pwd = document.getElementById('NewPassword');
            pwd.type = this.checked ? 'text' : 'password';
        });
        document.getElementById('showPasswordCheckbox2').addEventListener('change', function() {
            const pwd = document.getElementById('ConfirmNewPassword');
            pwd.type = this.checked ? 'text' : 'password';
        });

        // Province → District → City cascade (trilingual)
        document.addEventListener('DOMContentLoaded', function () {
            const provinceSelect = document.getElementById('provinceSelect');
            const districtSelect = document.getElementById('districtSelect');
            const citySelect = document.getElementById('citySelect');

            // Preserve current selections (from PHP)
            const currentDistrictId = <?= (int)$current_district_id ?>;
            const currentCityId = <?= (int)$current_city_id ?>;

            function formatOption(name_en, name_si, name_ta) {
                let text = name_en;
                if (name_si && name_ta) text += ` (${name_si} / ${name_ta})`;
                else if (name_si) text += ` (${name_si})`;
                else if (name_ta) text += ` (${name_ta})`;
                return text;
            }

            function loadDistricts(provinceId, selectedDistrictId = 0) {
                if (!provinceId) {
                    districtSelect.innerHTML = '<option value="">Select District</option>';
                    districtSelect.disabled = true;
                    citySelect.innerHTML = '<option value="">Select City/Town</option>';
                    citySelect.disabled = true;
                    return;
                }
                fetch(`<?= BASE_URL ?>get_locations.php?type=districts&province_id=${provinceId}`)
                    .then(res => res.json())
                    .then(data => {
                        districtSelect.innerHTML = '<option value="">Select District</option>';
                        data.forEach(item => {
                            const selected = (selectedDistrictId == item.id) ? 'selected' : '';
                            districtSelect.innerHTML += `<option value="${item.id}" ${selected}>${formatOption(item.name_en, item.name_si, item.name_ta)}</option>`;
                        });
                        districtSelect.disabled = false;
                        if (selectedDistrictId) {
                            loadCities(selectedDistrictId, currentCityId);
                        } else {
                            citySelect.innerHTML = '<option value="">Select...</option>';
                            citySelect.disabled = true;
                        }
                    })
                    .catch(err => console.error(err));
            }

            function loadCities(districtId, selectedCityId = 0) {
                if (!districtId) {
                    citySelect.innerHTML = '<option value="">Select City/Town</option>';
                    citySelect.disabled = true;
                    return;
                }
                fetch(`<?= BASE_URL ?>get_locations.php?type=cities&district_id=${districtId}`)
                    .then(res => res.json())
                    .then(data => {
                        citySelect.innerHTML = '<option value="">Select City/Town</option>';
                        data.forEach(item => {
                            const selected = (selectedCityId == item.id) ? 'selected' : '';
                            citySelect.innerHTML += `<option value="${item.id}" ${selected}>${formatOption(item.name_en, item.name_si, item.name_ta)}</option>`;
                        });
                        citySelect.disabled = false;
                    })
                    .catch(err => console.error(err));
            }

            // Initial load if a province is preselected
            if (provinceSelect.value) {
                loadDistricts(provinceSelect.value, currentDistrictId);
            }

            provinceSelect.addEventListener('change', function() {
                loadDistricts(this.value, 0);
            });

            districtSelect.addEventListener('change', function() {
                loadCities(this.value, 0);
            });
        });

        /*
         * PROFILE INFORMATION: TARGETED SUBMIT FREEZE
         * Uses explicit IDs to prevent conflicts with other forms or scripts.
         */
        document.addEventListener('DOMContentLoaded', function() {
            const profileForm = document.getElementById('profileForm');
            const profileSubmitBtn = document.getElementById('profileSubmitBtn');

            if (profileForm && profileSubmitBtn) {
                profileForm.addEventListener('submit', function() {
                    setTimeout(function() {
                        profileSubmitBtn.innerText = "Updating Profile...";
                        profileSubmitBtn.style.opacity = "0.5";
                        profileSubmitBtn.style.pointerEvents = "none";
                    }, 0);
                });
            }
        });
    </script>

    <!-- footer (admin) includes report issue modal -->
    <?php include '../includes/footer_admin.php'; ?>
