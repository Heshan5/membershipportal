<?php
/**
 * Membership Portal.
 * Report Issue Handler.
 *
 * Tries to send the email immediately using Brevo.
 * If that fails, queues the email for later sending (processed on admin login).
 * The email body includes the reporter's local time (captured via JavaScript offset).
 *
 * @package    MembershipPortal.
 * @author     Heshan Shibry <heshan.shib@gmail.com>
 * @copyright  2026 HESHAN SHIBRY.
 * @license    Proprietary - All rights reserved.
 * @version    1.0.0.
 */
require_once '../includes/auth.php';
$pdo = getDB();
validateAdminSession($pdo);

if (!isset($_SESSION['user_id'])) {
    redirect('');
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    redirect('admin/dashboard');
}

$subject = sanitize($_POST['subject']);
$message = sanitize($_POST['message']);

$reporterName = $_SESSION['full_name'];
$reporterId = $_SESSION['admin_id'];

// Fetch reporter's email
$stmt = $pdo->prepare("SELECT email FROM admins WHERE id = ?");
$stmt->execute([$_SESSION['user_id']]);
$reporterEmail = $stmt->fetchColumn();

// Build the full message
$fullMessage = "A new issue has been reported by $reporterName ($reporterId).\n\n";
$fullMessage .= "Reporter Email: $reporterEmail\n\n";
$fullMessage .= "Subject: $subject\n\n";
$fullMessage .= "Details:\n$message\n\n";
$fullMessage .= "Reported from IP: " . $_SERVER['REMOTE_ADDR'] . "\n";

// ==================== Reporter's local time (based on browser offset) ====================
// Get timezone offset from hidden field (minutes, negative for east of UTC)
$tzOffset = isset($_POST['tz_offset']) && is_numeric($_POST['tz_offset']) ? (int)$_POST['tz_offset'] : null;
if ($tzOffset !== null) {
    // Offset in minutes: e.g., Kenya UTC+3 => offset = -180
    $utc = new DateTime('now', new DateTimeZone('UTC'));
    $utc->modify("-{$tzOffset} minutes");
    $reporterLocalTime = $utc->format('Y-m-d H:i:s');
    $fullMessage .= "Time (reporter's local): $reporterLocalTime\n\n";
} else {
    // Fallback to server UTC time (should not happen because offset is sent)
    $fullMessage .= "Time (UTC): " . gmdate('Y-m-d H:i:s') . " UTC\n\n";
}

// Determine recipient – PRIMARY_ADMIN_EMAIL constant or fallback to id=1 admin
$to = defined('PRIMARY_ADMIN_EMAIL') && PRIMARY_ADMIN_EMAIL ? PRIMARY_ADMIN_EMAIL : '';
if (empty($to)) {
    $stmt = $pdo->prepare("SELECT email FROM admins WHERE id = 1");
    $stmt->execute();
    $to = $stmt->fetchColumn();
}
if (empty($to)) {
    $_SESSION['report_error'] = "No primary admin email configured. Please contact support.";
    redirect('admin/dashboard');
}

$emailSubject = "[Portal Issue] " . $subject;

// --- Hybrid sending: immediate + fallback queue ---
$success = false;
if (function_exists('sendEmail')) {
    $result = sendEmail($to, $emailSubject, $fullMessage, 'Primary Admin');
    $success = $result['success'];
    if (!$success) {
        // Immediate send failed – queue the email for later
        if (function_exists('queueEmail')) {
            $queued = queueEmail($to, $emailSubject, $fullMessage, 'Primary Admin');
            if ($queued) {
                $_SESSION['report_warning'] = "Your report could not be sent immediately, but it has been queued and will be delivered shortly.";
            } else {
                $_SESSION['report_error'] = "Failed to send or queue your report. Please contact the primary admin directly.";
            }
        } else {
            $_SESSION['report_error'] = "Email system unavailable. Please contact the primary admin.";
        }
    }
} else {
    // Fallback to native mail() if Provider not available
    $headers = "From: " . (defined('NOREPLY_EMAIL') ? NOREPLY_EMAIL : 'noreply@example.com') . "\r\n";
    $headers .= "Reply-To: " . $reporterEmail . "\r\n";
    $success = mail($to, $emailSubject, $fullMessage, $headers);
    if (!$success) {
        $_SESSION['report_error'] = "Failed to send the report. Please contact the primary admin directly.";
    }
}

if ($success) {
    $_SESSION['report_sent'] = "Your issue has been reported. Thank you.";
}

redirect('admin/dashboard');
exit;
?>
