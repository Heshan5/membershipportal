<?php
/**
 * Membership Portal.
 * Restore Deleted Records (Members & Admins).
 * Access: Primary admin (full), Secondary super (members + regular admins), Regular with restore_users (members only).
 *
 * UPDATED: Admin restore now includes gender and gender_custom fields.
 * UPDATED: Deleted Admins table now displays gender.
 * UPDATED: Restore log stores gender for both members and admins.
 *
 * @package    MembershipPortal.
 * @author     Heshan Shibry <heshan.shib@gmail.com>
 * @copyright  2026 HESHAN SHIBRY.
 * @license    Proprietary - All rights reserved.
 * @version    1.0.0.
 */
require_once '../includes/auth.php';
$pdo = getDB();
validateAdminSession($pdo);
$isSuperAdmin = ($_SESSION['is_super_admin'] == 1);
$isPrimary = ($_SESSION['user_id'] == 1);

// Fetch profile picture for navbar avatar
$stmt = $pdo->prepare("SELECT profile_pic FROM admins WHERE id = ?");
$stmt->execute([$_SESSION['user_id']]);
$avatarPic = $stmt->fetchColumn();

$isSuper = ($_SESSION['is_super_admin'] == 1);
$canRestoreMembers = ($isPrimary || $isSuper || hasPermission('restore_users'));
// Secondary super admins can restore regular admins (not super admins)
$canRestoreRegularAdmins = ($isSuper && !$isPrimary); // they will be checked per record

if (!$canRestoreMembers && !$isPrimary && !$canRestoreRegularAdmins) {
    redirect('admin/dashboard');
}

$message = '';
$error = '';

// ==================== MEMBER RESTORE (with gender capture for restore log) ====================
if (isset($_GET['restore_member'])) {
    if (!$canRestoreMembers) {
        $error = "You don't have permission to restore members.";
    } else {
        $delId = (int)$_GET['restore_member'];
        $stmt = $pdo->prepare("SELECT * FROM deleted_members WHERE id = ?");
        $stmt->execute([$delId]);
        $del = $stmt->fetch();
        if ($del) {
            $deletedAt = $del['deleted_at'];
            $deletionReason = $del['reason'];

            // Capture gender from deleted_members for restore log
            $restore_gender = $del['gender'] ?? null;
            $restore_gender_custom = $del['gender_custom'] ?? null;

            // Insert back into members with all columns (geographic, political, verification)
            $stmtIns = $pdo->prepare("
                INSERT INTO members
                    (member_id, full_name, email, province, district, city, city_id,
                     phone, address, profile_pic, created_at, polling_division, gn_division,
                     assigned_polling_booth, last_updated_by_admin, master_address_id, verification_status)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ");
            $stmtIns->execute([
                $del['member_id'],
                $del['full_name'],
                $del['email'],
                $del['province'],
                $del['district'],
                $del['city'],
                $del['city_id'],
                $del['phone'],
                $del['address'],
                $del['profile_pic'],
                $del['created_at'],
                $del['polling_division'],
                $del['gn_division'],
                $del['assigned_polling_booth'],
                null, // last_updated_by_admin – set to null on restore
                $del['master_address_id'],
                $del['verification_status']
            ]);
            $newMemberId = $pdo->lastInsertId();

            // Restore documents
            $stmtDocs = $pdo->prepare("SELECT * FROM deleted_documents WHERE member_id = ?");
            $stmtDocs->execute([$del['original_id']]);
            $docs = $stmtDocs->fetchAll();
            foreach ($docs as $doc) {
                $stmtInsDoc = $pdo->prepare("INSERT INTO documents (member_id, document_name, document_path, document_type, uploaded_at) VALUES (?, ?, ?, ?, ?)");
                $stmtInsDoc->execute([$newMemberId, $doc['document_name'], $doc['document_path'], $doc['document_type'], $doc['uploaded_at']]);
            }

            // Clean up deleted tables
            $pdo->prepare("DELETE FROM deleted_members WHERE id = ?")->execute([$delId]);
            $pdo->prepare("DELETE FROM deleted_documents WHERE member_id = ?")->execute([$del['original_id']]);

            // Log restore with gender
            $restoredAt = utcNow();
            $stmtLog = $pdo->prepare("
                INSERT INTO restore_log
                    (item_type, item_name, item_identifier, original_id, restored_by, deleted_record_id,
                     notes, restored_at, deleted_at, deletion_reason, gender, gender_custom)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ");
            $stmtLog->execute([
                'member',
                $del['full_name'],
                $del['member_id'],
                $newMemberId,
                $_SESSION['user_id'],
                $delId,
                "Restored from deleted_members",
                $restoredAt,
                $deletedAt,
                $deletionReason,
                $restore_gender,
                $restore_gender_custom
            ]);
            $message = "Member restored successfully.";
        } else {
            $error = "Record not found.";
        }
    }
}

// ==================== ADMIN RESTORE (with gender capture for restore log) ====================
if (isset($_GET['restore_admin'])) {
    $delId = (int)$_GET['restore_admin'];
    $stmtCheck = $pdo->prepare("SELECT is_super_admin FROM deleted_admins WHERE id = ?");
    $stmtCheck->execute([$delId]);
    $targetSuper = $stmtCheck->fetchColumn();
    if ($targetSuper === false) {
        $error = "Record not found.";
    } else {
        $allowed = false;
        if ($isPrimary) {
            $allowed = true;
        } elseif ($isSuper && $targetSuper == 0) {
            $allowed = true;
        }
        if (!$allowed) {
            $error = "You don't have permission to restore this admin.";
        } else {
            $stmt = $pdo->prepare("SELECT * FROM deleted_admins WHERE id = ?");
            $stmt->execute([$delId]);
            $del = $stmt->fetch();
            if ($del) {
                $deletedAt = $del['deleted_at'];
                $deletionReason = $del['reason'];

                // Capture gender from deleted_admins for restore log
                $restore_gender = $del['gender'] ?? null;
                $restore_gender_custom = $del['gender_custom'] ?? null;

                // Restore admin with all geographic fields AND gender fields
                $stmtIns = $pdo->prepare("
                    INSERT INTO admins
                        (admin_id, full_name, email, password, district, province, city, city_id,
                         phone, address, profile_pic, role, permissions, force_password_change,
                         is_super_admin, temp_password_expires, created_at, gender, gender_custom)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                ");
                $stmtIns->execute([
                    $del['admin_id'],
                    $del['full_name'],
                    $del['email'],
                    $del['password'],
                    $del['district'],
                    $del['province'],
                    $del['city'],
                    $del['city_id'],
                    $del['phone'],
                    $del['address'],
                    $del['profile_pic'],
                    $del['role'],
                    $del['permissions'],
                    $del['force_password_change'],
                    $del['is_super_admin'],
                    $del['temp_password_expires'],
                    $del['created_at'],
                    $del['gender'],
                    $del['gender_custom']
                ]);
                $newAdminId = $pdo->lastInsertId();
                $pdo->prepare("DELETE FROM deleted_admins WHERE id = ?")->execute([$delId]);

                // Log restore with gender
                $restoredAt = utcNow();
                $stmtLog = $pdo->prepare("
                    INSERT INTO restore_log
                        (item_type, item_name, item_identifier, original_id, restored_by, deleted_record_id,
                         notes, restored_at, deleted_at, deletion_reason, gender, gender_custom)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                ");
                $stmtLog->execute([
                    'admin',
                    $del['full_name'],
                    $del['admin_id'],
                    $newAdminId,
                    $_SESSION['user_id'],
                    $delId,
                    "Restored from deleted_admins",
                    $restoredAt,
                    $deletedAt,
                    $deletionReason,
                    $restore_gender,
                    $restore_gender_custom
                ]);
                $message = "Admin restored successfully.";
            } else {
                $error = "Record not found.";
            }
        }
    }
}

// Search parameters
$search = isset($_GET['search']) ? trim($_GET['search']) : '';

// Fetch deleted members (with deleter name)
$membersSql = "SELECT dm.*, a.full_name AS deleter_name
               FROM deleted_members dm
               LEFT JOIN admins a ON dm.deleted_by = a.id
               WHERE dm.full_name LIKE :search OR dm.member_id LIKE :search OR dm.email LIKE :search
               ORDER BY dm.deleted_at ASC";
$stmtMembers = $pdo->prepare($membersSql);
$stmtMembers->execute([':search' => "%$search%"]);
$deletedMembers = $stmtMembers->fetchAll();

// Fetch deleted admins – show to primary and secondary super (with deleter name)
$deletedAdmins = [];
if ($isPrimary || $isSuper) {
    $adminsSql = "SELECT da.*, a.full_name AS deleter_name
                  FROM deleted_admins da
                  LEFT JOIN admins a ON da.deleted_by = a.id
                  WHERE da.full_name LIKE :search OR da.admin_id LIKE :search OR da.email LIKE :search
                  ORDER BY da.deleted_at ASC";
    $stmtAdmins = $pdo->prepare($adminsSql);
    $stmtAdmins->execute([':search' => "%$search%"]);
    $deletedAdmins = $stmtAdmins->fetchAll();
}

// Navbar variables
$isLoggedIn = true;
$userRole = $_SESSION['role'];
$fullName = $_SESSION['full_name'];
$userId = $_SESSION['user_id'];
$hasGenerateReports = hasPermission('generate_reports');
$hasRestoreUsers = hasPermission('restore_users');
$baseUrl = BASE_URL;
$currentPage = 'restore';
$hideAdminLinks = false;
?>
<?php
// Set page title and optional custom styles
$page_title = 'Restore Deleted Records';
$page_styles = '
    <style>
      .filter-card { background: #f8f9fa; border-radius: 16px; }
      .navbar .dropdown-toggle {
            display: flex !important;
            align-items: center !important;
            gap: 3px !important;
            line-height: 1 !important;
        }
        .navbar .dropdown-toggle img,
        .navbar .dropdown-toggle i {
            display: inline-block;
            vertical-align: middle;
        }

      /* Removes the puffy bubble shape from the search text input fields */
      .filter-card .form-control {
          border-radius: 6px !important;
          height: 38px !important;
          margin-bottom: 0 !important;
      }

      /* FIXED CSS PROBLEM HERE: Set layout structure to standard baseline vertical box tracking */
      .filter-card .btn {
          border-radius: 6px !important;
          height: 38px !important;
          padding: 0 1.25rem !important;
          display: inline-block !important; /* Replaced flex with standard block rendering */
          line-height: 36px !important;     /* Centers text text vertically without pushing the button box down */
          vertical-align: middle !important; /* Aligns the button base box with input base box */
          text-align: center !important;
          margin-bottom: 0 !important;
          transition: all 0.15s ease-in-out !important;
      }

      /* New Premium Solid Dark Configuration for the Clear Button Layout */
      .filter-card .btn-dark {
          background-color: #212529 !important;
          border-color: #212529 !important;
          color: #ffffff !important;
          text-decoration: none !important; /* Stops link underline from messing with text spacing */
      }
      .filter-card .btn-dark:hover {
          background-color: #424649 !important;
          border-color: #373b3e !important;
          color: #ffffff !important;
      }
    </style>
';


// Include the global header
include '../includes/header.php';
?>

  <!-- Shared navbar (admin) -->
  <?php include '../includes/navbar.php'; ?>

  <main class="container my-5">
    <!-- ========== SUCCESS MESSAGE BLOCK ========== -->
      <?php if ($message): ?>
          <div class="alert alert-success d-flex align-items-center alert-dismissible fade show border-0 border-start border-4 border-success shadow-sm mb-4" role="alert">
              <!-- Modern Bootstrap SVG Check Circle Icon -->
              <svg xmlns="http://www.w3.org/2000/svg" width="22" height="22" fill="currentColor" class="bi bi-check-circle-fill me-3 flex-shrink-0" viewBox="0 0 16 16">
                  <path d="M16 8A8 8 0 1 1 0 8a8 8 0 0 1 16 0m-3.97-3.03a.75.75 0 0 0-1.08.022L7.477 9.417 5.384 7.323a.75.75 0 0 0-1.06 1.06L6.97 11.03a.75.75 0 0 0 1.079-.02l3.992-4.99a.75.75 0 0 0-.01-1.05z"/>
              </svg>
              <div class="small fw-semibold">
                  <?= $message ?>
              </div>
              <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
          </div>
      <?php endif; ?>

      <!-- ========== ERROR MESSAGE BLOCK ========== -->
      <?php if ($error): ?>
          <div class="alert alert-danger d-flex align-items-center border-0 border-start border-4 border-danger shadow-sm mb-4" role="alert">
              <!-- Modern Bootstrap SVG Exclamation Warning Icon -->
              <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="currentColor" class="bi bi-exclamation-triangle-fill me-3 flex-shrink-0" viewBox="0 0 16 16">
                  <path d="M8.982 1.566a1.13 1.13 0 0 0-1.96 0L.165 13.233c-.457.778.091 1.767.98 1.767h13.713c.889 0 1.438-.99.98-1.767zM8 5c.535 0 .954.462.9.995l-.35 3.507a.552.552 0 0 1-1.1 0L7.1 5.995A.905.905 0 0 1 8 5m.002 6a1 1 0 1 1 0 2 1 1 0 0 1 0-2"/>
              </svg>
              <div class="small fw-semibold">
                  <?= $error ?>
              </div>
          </div>
      <?php endif; ?>
        <div class="card shadow-sm border-0 rounded-4">
            <div class="card-body p-4">
              <h3 class="card-title text-center text-md-start">Search Deleted Records</h3>
                  <div class="filter-card p-3 mb-4">
                      <!--
                        - flex-column makes everything stack beautifully on mobile screens
                        - flex-md-row snaps everything back to side-by-side on desktop screens
                        - align-items-stretch forces full-width elements on mobile for a clean design
                      -->
                      <form method="GET" class="d-flex flex-column flex-md-row align-items-stretch align-items-md-center gap-3">
                          <!-- Max-width only applies on desktop screens, letting it scale smoothly on phone screens -->
                          <div class="flex-grow-1" style="max-width: 400px; width: 100%;">
                              <input type="text" name="search" class="form-control" placeholder="Search by Name, Email or ID" value="<?= htmlspecialchars($search) ?>" required>
                          </div>
                          <!-- Buttons form a clean horizontal group that spreads perfectly on smaller screen bounds -->
                          <div class="d-flex align-items-center gap-2 w-100 w-md-auto">
                              <button type="submit" class="btn btn-primary flex-fill flex-md-grow-0">Search</button>
                              <!-- Modern Clear Button styled exactly like the Search button -->
                              <a href="<?= BASE_URL ?>admin/restore" class="btn btn-dark flex-fill flex-md-grow-0 text-center">Clear</a>
                          </div>
                      </form>
                  </div>
                <!-- Deleted Members Table -->
                <h4>Deleted Members</h4>
                <div class="table-responsive">
                    <table class="table table-hover custom-admin-table">
                        <thead class="table-light">
                            <tr><th>Member ID</th><th>Name</th><th>Email</th><th>Deleted At</th><th>Deleted By</th><th>Reason</th><th>Actions</th></tr>
                        </thead>
                        <tbody>
                            <?php foreach ($deletedMembers as $dm): ?>
                            <tr class="opacity-75 bg-light">
                                <td><?= htmlspecialchars($dm['member_id']) ?></td>
                                <td><?= htmlspecialchars($dm['full_name']) ?></td>
                                <td><?= htmlspecialchars($dm['email']) ?></td>
                                <td data-utc-time="<?= $dm['deleted_at'] ?>"><?= $dm['deleted_at'] ?></td>
                                <td>
                                    <?php if (!empty($dm['deleter_name'])): ?>
                                        <?= htmlspecialchars($dm['deleter_name']) ?> (ID: <?= $dm['deleted_by'] ?>)
                                    <?php else: ?>
                                        User ID <?= $dm['deleted_by'] ?> (deleted member account)
                                    <?php endif; ?>
                                </td>
                                <td><?= htmlspecialchars($dm['reason']) ?></td>
                                <td>
                                    <?php if ($canRestoreMembers): ?>
                                        <a href="?restore_member=<?= $dm['id'] ?>" class="btn btn-sm btn-outline-success px-3 rounded-pill" onclick="return confirm('Restore this member?')">Restore</a>
                                    <?php endif; ?>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                            <?php if (empty($deletedMembers)): ?>
                                <tr><td colspan="8" class="text-center">No deleted members found. </td></tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
                <!-- Deleted Admins Table – shown to primary and secondary super admins -->
                <?php if ($isPrimary || $isSuper): ?>
                <h4 class="mt-4">Deleted Admins</h4>
                <div class="table-responsive">
                    <table class="table table-hover custom-admin-table">
                        <thead class="table-light">
                            <tr>
                                <th>Admin ID</th>
                                <th>Name</th>
                                <th>Email</th>
                                <th>Type</th>
                                <th>Gender</th>
                                <th>Deleted At</th>
                                <th>Deleted By</th>
                                <th>Reason</th>
                                <th>Status</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($deletedAdmins as $da): ?>
                            <tr class="opacity-75 bg-light">
                                <td><?= htmlspecialchars($da['admin_id']) ?></td>
                                <td><?= htmlspecialchars($da['full_name']) ?></td>
                                <td><?= htmlspecialchars($da['email']) ?></td>
                                <td><?= $da['is_super_admin'] ? 'Super Admin' : 'Regular Admin' ?></td>
                                <td>
                                    <?php
                                    if (!empty($da['gender'])) {
                                        $genderDisplay = htmlspecialchars($da['gender']);
                                        if ($da['gender'] == 'Other' && !empty($da['gender_custom'])) {
                                            $genderDisplay .= ' (' . htmlspecialchars($da['gender_custom']) . ')';
                                        }
                                        echo $genderDisplay;
                                    } else {
                                        echo '-';
                                    }
                                    ?>
                                </td>
                                <td data-utc-time="<?= $da['deleted_at'] ?>"><?= $da['deleted_at'] ?></td>
                                <td>
                                    <?php if (!empty($da['deleter_name'])): ?>
                                        <?= htmlspecialchars($da['deleter_name']) ?> (ID: <?= $da['deleted_by'] ?>)
                                    <?php else: ?>
                                        User ID <?= $da['deleted_by'] ?> (deleted admin account)
                                    <?php endif; ?>
                                </td>
                                <td><?= htmlspecialchars($da['reason']) ?></td>
                                <td>
                                    <span class="badge rounded-pill badge-deactivated">
                                        <i class="bi bi-person-x-fill"></i> Deactivated
                                    </span>
                                </td>
                                <td>
                                    <?php
                                    $showRestore = false;
                                    if ($isPrimary) {
                                        $showRestore = true;
                                    } elseif ($isSuper && $da['is_super_admin'] == 0) {
                                        $showRestore = true;
                                    }
                                    ?>
                                    <?php if ($showRestore): ?>
                                        <a href="?restore_admin=<?= $da['id'] ?>" class="btn btn-sm btn-outline-success px-3 rounded-pill" onclick="return confirm('Restore this admin?')">Restore</a>
                                    <?php else: ?>
                                        <span class="text-muted">—</span>
                                    <?php endif; ?>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                            <?php if (empty($deletedAdmins)): ?>
                                <tr><td colspan="10" class="text-center">No deleted admins found. </td></tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
                <?php endif; ?>
            </div>
        </div>
  </main>

  <!-- footer (admin) includes report issue modal -->
  <?php include '../includes/footer_admin.php'; ?>
