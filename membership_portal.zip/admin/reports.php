<?php
/**
 * Membership Portal.
 * Reports & Analytics Dashboard.
 * Access: only admins with 'generate_reports' permission.
 * Features:
 * - Quick date range buttons (Today, Last 7/30 days, This Week/Month/Year).
 * - Custom date range picker.
 * - Summary cards (total members, new in period).
 * - Bar chart: members per district (Chart.js).
 * - Donut chart: members by gender (with custom "Other" labels).
 * - Export to CSV (member list + gender stats).
 * - Print / PDF via browser print.
 * - Member list table (full details: province, district, city, gender, polling division, etc.)
 *
 * @package    MembershipPortal.
 * @author     Heshan Shibry <heshan.shib@gmail.com>
 * @copyright  2026 HESHAN SHIBRY.
 * @license    Proprietary - All rights reserved.
 * @version    1.0.0.
 */
require_once '../includes/auth.php';
$pdo = getDB();
validateAdminSession($pdo);
$isSuperAdmin = ($_SESSION['is_super_admin'] == 1);
$isPrimary = ($_SESSION['user_id'] == 1);
// Fetch profile picture for navbar avatar
$stmt = $pdo->prepare("SELECT profile_pic FROM admins WHERE id = ?");
$stmt->execute([$_SESSION['user_id']]);
$avatarPic = $stmt->fetchColumn();

// Variables required by shared navbar
$isLoggedIn = true;
$userRole = $_SESSION['role'];
$fullName = $_SESSION['full_name'];
$userId = $_SESSION['user_id'];
$hasGenerateReports = hasPermission('generate_reports');
$hasRestoreUsers = hasPermission('restore_users');
$baseUrl = BASE_URL; // defined in config/database.php

if (!hasPermission('generate_reports')) {
    redirect('admin/dashboard');
}

// Get filter dates (default to last 30 days)
$date_from = isset($_GET['from']) && !empty($_GET['from']) ? $_GET['from'] : date('Y-m-d', strtotime('-30 days'));
$date_to   = isset($_GET['to']) && !empty($_GET['to']) ? $_GET['to'] : date('Y-m-d');

// Validate dates
if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $date_from)) $date_from = date('Y-m-d', strtotime('-30 days'));
if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $date_to)) $date_to = date('Y-m-d');

$params = [':from' => $date_from, ':to' => $date_to];

// --- Member list query (all columns) ---
$sql = "SELECT
            id, member_id, full_name, email,
            province, district, city,
            phone, address,
            gender, gender_custom,
            polling_division, gn_division, assigned_polling_booth,
            created_at
        FROM members
        WHERE DATE(created_at) BETWEEN :from AND :to
        ORDER BY created_at ASC";
$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$members = $stmt->fetchAll();

// Summary statistics
$total_members = count($members);
$new_members = $total_members;

// --- District chart data ---
$district_sql = "SELECT district, COUNT(*) as cnt FROM members WHERE DATE(created_at) BETWEEN :from AND :to GROUP BY district ORDER BY cnt ASC";
$stmt_dist = $pdo->prepare($district_sql);
$stmt_dist->execute($params);
$districts = $stmt_dist->fetchAll();

$chart_labels = [];
$chart_data = [];
foreach ($districts as $d) {
    $chart_labels[] = $d['district'];
    $chart_data[] = $d['cnt'];
}

// --- Gender distribution data (for donut chart) ---
$gender_sql = "SELECT
    CASE
        WHEN gender = 'Male' THEN 'Male'
        WHEN gender = 'Female' THEN 'Female'
        WHEN gender = 'Prefer not to say' THEN 'Prefer not to say'
        WHEN gender = 'Other' AND gender_custom IS NOT NULL AND gender_custom != ''
            THEN CONCAT('Other (', gender_custom, ')')
        WHEN gender = 'Other' THEN 'Other'
        ELSE 'Not specified'
    END as gender_label,
    COUNT(*) as count
FROM members
WHERE DATE(created_at) BETWEEN :from AND :to
GROUP BY gender_label
ORDER BY count DESC";
$stmt_gender = $pdo->prepare($gender_sql);
$stmt_gender->execute($params);
$genderData = $stmt_gender->fetchAll();

$gender_labels = [];
$gender_counts = [];
foreach ($genderData as $g) {
    $gender_labels[] = $g['gender_label'];
    $gender_counts[] = (int)$g['count'];
}
?>
<?php
// Set page title and optional custom styles
$page_title = 'Reports & Analytics';
$page_styles = '
    <style>
    body { background: #f4f7fc; }
    .filter-card { background: #f8f9fa; border-radius: 16px; }
    .stat-card {
        background: white;
        border-radius: 20px;
        padding: 1.5rem;
        text-align: center;
        box-shadow: 0 4px 12px rgba(0,0,0,0.05);
        transition: transform 0.2s;
    }
    .stat-card:hover { transform: translateY(-3px); }
    .stat-number { font-size: 2.2rem; font-weight: 700; }
    .stat-label { color: #6c757d; margin-top: 0.5rem; }
    input[type="text"].form-control { cursor: pointer; }
    /* Fix vertical alignment of user avatar in navbar */
    .navbar .dropdown-toggle {
          display: flex !important;
          align-items: center !important;
          gap: 3px !important;
          line-height: 1 !important;
      }
      .navbar .dropdown-toggle img,
      .navbar .dropdown-toggle i {
          display: inline-block;
          vertical-align: middle;
      }
    /* Gender legend styling */
    .gender-stats-list {
        padding: 1rem;
        background: #f8f9fa;
        border-radius: 16px;
    }
    .gender-stats-list .bi-dot {
        font-size: 1.5rem;
        vertical-align: middle;
    }
    /* Print styles */
    @media print {
        .filter-card, .quick-select-scroller, .btn { display: none; }
        .card { box-shadow: none; border: 1px solid #ddd; }
        canvas { max-height: 300px; }
        .gender-stats-list { background: none; padding: 0; }
    }
    /* Removes the puffy bubble shape from the report form text inputs */
    #reportForm .form-control {
        border-radius: 6px !important;
        height: 38px !important;
        margin-bottom: 0 !important;
    }

    /* Strips away puffy pill configurations from the action button pair */
    #reportForm .btn {
        height: 38px !important;
        border-radius: 6px !important;
        padding: 0 1.25rem !important;
        display: inline-flex !important;
        align-items: center !important;
        justify-content: center !important;
        font-size: 0.875rem !important;
    }

    /* Default Mobile View: Lets text fields expand fluidly across device bounds */
    #reportForm .date-input-responsive {
        width: 100%;
    }

    /* Tablet & Desktop Screen Width Configurations Only (768px and up) */
    @media (min-width: 768px) {
        #reportForm .date-input-responsive {
            max-width: 300px !important; /* Forces input text box lines to stay sleek and short */
            min-width: 300px !important;
        }
    }
    </style>
';

// Include the global header
include '../includes/header.php';
?>

  <!-- Shared navbar (admin) -->
  <?php $currentPage = 'reports';
    include '../includes/navbar.php';
  ?>

  <main class="container my-5">
        <!-- Filter Form with Quick Buttons -->
        <div class="card shadow-sm border-0 rounded-4 mb-4">
            <div class="card-body">
                <h5 class="card-title"><i class="bi bi-funnel"></i> Filter by Registration Date</h5>

                <!-- Quick date buttons -->
                <div class="col-12">
                    <label class="form-label fw-semibold">Quick Select</label>
                    <div class="quick-select-scroller">
                        <button type="button" class="btn btn-sm btn-dark quick-date" data-days="0">Today</button>
                        <button type="button" class="btn btn-sm btn-dark quick-date" data-days="7">Last 7 Days</button>
                        <button type="button" class="btn btn-sm btn-dark quick-date" data-days="30">Last 30 Days</button>
                        <button type="button" class="btn btn-sm btn-dark" id="thisWeekBtn">This Week</button>
                        <button type="button" class="btn btn-sm btn-dark" id="thisMonthBtn">This Month</button>
                        <button type="button" class="btn btn-sm btn-dark" id="thisYearBtn">This Year</button>
                    </div>
                </div>

                <!-- Custom date range form -->
                <div class="filter-card p-3 mb-4">
                  <!-- Swapped row grid layout for responsive flex tracking line boundaries -->
                  <form method="GET" id="reportForm" class="d-flex flex-column flex-md-row align-items-stretch align-items-md-end gap-3">

                      <!-- Input wrapper elements stay fluid on mobile but snap to compact baseline widths on desktop viewports -->
                      <div class="flex-grow-1 flex-md-grow-0" >
                          <label class="form-label text-dark fw-semibold small mb-1">From Date</label>
                          <input type="text" name="from" class="form-control date-input-responsive" id="fromDate" placeholder="From Date" value="<?= $date_from ?>">
                      </div>

                      <div class="flex-grow-1 flex-md-grow-0" >
                          <label class="form-label text-dark fw-semibold small mb-1">To Date</label>
                          <input type="text" name="to" class="form-control date-input-responsive" id="toDate" placeholder="To Date" value="<?= $date_to ?>">
                      </div>

                      <!--
                        - Added ms-md-auto to push the buttons cleanly to the far right on widescreen layouts
                        - Uses horizontal inline companion layouts instead of stacking vertically
                      -->
                      <div class="d-flex align-items-center gap-2 w-100 w-md-auto ms-md-auto mt-2 mt-md-0">
                          <button type="submit" class="btn btn-primary px-3 fw-medium flex-fill flex-md-grow-0 text-nowrap">
                              <i class="bi bi-funnel"></i> Apply Filter
                          </button>
                          <a href="<?= BASE_URL ?>admin/reports" class="btn btn-outline-secondary px-3 fw-medium d-inline-flex align-items-center justify-content-center gap-1 flex-fill flex-md-grow-0 text-nowrap">
                              Clear
                          </a>
                      </div>
                  </form>
              </div>
            </div>
        </div>

        <!-- Statistics Cards (total and new members) -->
        <div class="row g-4 mb-4">
            <div class="col-md-6">
                <div class="stat-card">
                    <div class="stat-number"><?= $total_members ?></div>
                    <div class="stat-label">Total Members</div>
                </div>
            </div>
            <div class="col-md-6">
                <div class="stat-card">
                    <div class="stat-number"><?= $new_members ?></div>
                    <div class="stat-label">New Members (Period)</div>
                </div>
            </div>
        </div>

        <!-- District Chart -->
        <div class="card shadow-sm border-0 rounded-4 mb-4">
            <div class="card-body">
                <h5 class="card-title"><i class="bi bi-bar-chart-steps"></i> Members per District</h5>
                <canvas id="districtChart" width="400" height="200"></canvas>
            </div>
        </div>

        <!-- Gender Distribution Chart (Donut) -->
        <div class="card shadow-sm border-0 rounded-4 mb-4">
            <div class="card-body">
              <!-- Header Section (Fixed for BOTH Laptop and Mobile viewports) -->
                <div class="d-flex flex-column d-sm-flex flex-sm-row justify-content-sm-between align-items-sm-center gap-2 mb-3">
                  <h5 class="card-title mb-0"><i class="bi bi-gender-ambiguous"></i> Members by Gender</h5>
                  <div> <!-- Added wrapping div container to lock the button size on desktop -->
                      <button id="exportGenderBtn" class="btn btn-sm btn-outline-info w-100 w-sm-auto text-nowrap">
                          <i class="bi bi-file-earmark-spreadsheet"></i> Export Gender Stats
                      </button>
                  </div>
                </div>

                <!-- Dynamic Content Section -->
                <?php if (empty($genderData)): ?>
                      <!-- Balanced Center State: Shows when database is empty -->
                      <div class="d-flex flex-column align-items-center justify-content-center text-center py-5" style="min-height: 240px;">
                          <!-- Clean Modern Info Icon Graphic Element -->
                          <div class="bg-light text-info rounded-circle d-flex align-items-center justify-content-center mb-3 shadow-sm" style="width: 56px; height: 56px;">
                              <svg xmlns="http://www.w3.org/2000/svg" width="26" height="26" fill="currentColor" class="bi bi-info-circle-fill" viewBox="0 0 16 16">
                                  <path d="M8 16A8 8 0 1 0 8 0a8 8 0 0 0 0 16zm.93-9.412-1 4.705c-.07.34.029.533.304.533.194 0 .487-.07.686-.246l-.088.416c-.287.346-.92.598-1.465.598-.703 0-1.002-.422-.808-1.319l.738-3.468c.064-.293.006-.399-.287-.47l-.451-.081.082-.381 2.29-.287zM8 5.5a1 1 0 1 1 0-2 1 1 0 0 1 0 2z"/>
                              </svg>
                          </div>
                          <h6 class="text-secondary fw-bold mb-1">No Data Available</h6>
                          <p class="text-muted small mb-0 px-3" style="max-width: 320px;">No gender demographic data has been recorded for this specific selection period.</p>
                      </div>
                  <?php else: ?>

                    <!-- Standard Grid Layout: Shows automatically when data exists -->
                    <div class="row align-items-center">
                        <div class="col-md-7 mb-3 mb-md-0">
                            <canvas id="genderChart" width="400" height="200" style="cursor: pointer;"></canvas>
                        </div>
                        <div class="col-md-5">
                            <div class="gender-stats-list">
                                <?php foreach ($genderData as $g): ?>
                                    <div class="d-flex justify-content-between align-items-center mb-2">
                                        <span>
                                            <i class="bi bi-dot" style="color: #0d6efd;"></i>
                                            <?= htmlspecialchars($g['gender_label']) ?>
                                        </span>
                                        <span class="badge bg-secondary rounded-pill">
                                            <?= $g['count'] ?>
                                        </span>
                                    </div>
                                <?php endforeach; ?>
                            </div>
                        </div>
                    </div>
                <?php endif; ?>
            </div>
        </div>

        <!-- Member List Table (full details) -->
        <div class="card shadow-sm border-0 rounded-4">
            <div class="card-body">
              <!-- Header Section (Fixed to force title on a single line) -->
                <div class="d-flex flex-column d-sm-flex flex-sm-row justify-content-sm-between align-items-sm-center gap-3 mb-3">
                    <!-- Changed to text-nowrap and added a right margin (me-3) -->
                    <h5 class="card-title mb-0 text-nowrap me-3"><i class="bi bi-table"></i> Member List (Filtered)</h5>
                    <div class="d-flex flex-wrap gap-2 w-100 w-sm-auto justify-content-start justify-content-sm-end">
                        <button id="exportCSVBtn" class="btn btn-success flex-grow-1 flex-sm-grow-0">
                            <i class="bi bi-file-earmark-spreadsheet"></i> Export CSV
                        </button>
                        <button onclick="window.print();" class="btn btn-secondary flex-grow-1 flex-sm-grow-0">
                            <i class="bi bi-printer"></i> Print / PDF
                        </button>
                    </div>
                </div>

                <!-- The Responsive Table Wrapper -->
                <div class="table-responsive">
                    <table class="table table-hover align-middle custom-admin-table" id="membersReportTable">
                        <thead class="table-light">
                            <tr>
                                <th>ID</th>
                                <th>Member ID</th>
                                <th>Full Name</th>
                                <th>Email</th>
                                <th>Province</th>
                                <th>District</th>
                                <th>City/Town</th>
                                <th>Phone</th>
                                <th>Gender</th>
                                <th>Polling Division</th>
                                <th>Grama Niladhari Division</th>
                                <th>Assigned Polling Booth</th>
                                <th>Registered (UTC)</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (empty($members)): ?>
                                <tr>
                                    <td colspan="13" class="text-center text-muted">No members in this period.</td>
                                </tr>
                            <?php else: ?>
                                <?php foreach ($members as $m): ?>
                                <tr>
                                    <td><?= $m['id'] ?></td>
                                    <td><?= htmlspecialchars($m['member_id']) ?></td>
                                    <td><?= htmlspecialchars($m['full_name']) ?></td>
                                    <td><?= htmlspecialchars($m['email']) ?></td>
                                    <td><?= htmlspecialchars($m['province']) ?></td>
                                    <td><?= htmlspecialchars($m['district']) ?></td>
                                    <td><?= htmlspecialchars($m['city']) ?></td>
                                    <td><?= htmlspecialchars($m['phone']) ?></td>
                                    <td>
                                        <?php
                                        if (!empty($m['gender'])) {
                                            $genderDisplay = htmlspecialchars($m['gender']);
                                            if ($m['gender'] == 'Other' && !empty($m['gender_custom'])) {
                                                $genderDisplay .= ' (' . htmlspecialchars($m['gender_custom']) . ')';
                                            }
                                            echo $genderDisplay;
                                        } else {
                                            echo '-';
                                        }
                                        ?>
                                    </td>
                                    <td><?= htmlspecialchars($m['polling_division']) ?></td>
                                    <td><?= htmlspecialchars($m['gn_division']) ?></td>
                                    <td><?= htmlspecialchars($m['assigned_polling_booth']) ?></td>
                                    <td class="registration-date" data-utc-time="<?= $m['created_at'] ?>"><?= $m['created_at'] ?></td>
                                </tr>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
  </main>

  <script>
    window.genderData = <?= json_encode($genderData) ?>;
  </script>

    <script>
      document.addEventListener('DOMContentLoaded', function() {
          // 1. Safe extraction of PHP variables into JS primitives
          const totalMembers = Number("<?= (int)($total_members ?: 1) ?>");

          // Fetch dynamic arrays from PHP
          let dynamicLabels = <?= json_encode($chart_labels ?? []) ?>;
          let dynamicData = <?= json_encode($chart_data ?? []) ?>;

          // 2. FIXED: Fallback placeholders so grid lines NEVER disappear on empty data
          if (!dynamicLabels || dynamicLabels.length === 0) {
              dynamicLabels = ['']; // Forces Chart.js to generate the X-axis grid wrapper
              dynamicData = [0];
          }

          // 3. District Bar Chart
          const districtCanvas = document.getElementById('districtChart');
          if (districtCanvas) {
              const ctx = districtCanvas.getContext('2d');
              new Chart(ctx, {
                  type: 'bar',
                  data: {
                      labels: dynamicLabels, // Uses the safe label arrays
                      datasets: [{
                          label: 'Number of Members',
                          data: dynamicData,
                          backgroundColor: 'rgba(54, 162, 235, 0.8)',
                          borderColor: 'rgba(54, 162, 235, 1)',
                          borderWidth: 0,
                          borderRadius: 6,
                          borderSkipped: 'bottom',
                          barThickness: 'flex',
                          maxBarThickness: 32
                      }]
                  },
                  options: {
                      responsive: true,
                      maintainAspectRatio: true,
                      plugins: {
                          legend: {
                              position: 'top',
                              align: 'end',
                              labels: {
                                  boxWidth: 10,
                                  boxHeight: 10,
                                  usePointStyle: true,
                                  pointStyle: 'circle',
                                  padding: 20
                              }
                          }
                      },
                      scales: {
                          x: {
                              grid: {
                                  display: false
                              },
                              ticks: {
                                  color: '#94a3b8',
                                  maxRotation: 45,
                                  minRotation: 0
                              }
                          },
                          y: {
                              beginAtZero: true,
                              suggestedMax: 10, // <-- Restored: Guarantees 0-10 background lines when empty
                              ticks: {
                                  precision: 0, // Forces clean whole numbers
                                  color: '#94a3b8',
                                  padding: 10
                              },
                              grid: {
                                  display: true,
                                  color: '#e2e8f0', // Clean grey line colors
                                  drawTicks: false
                              },
                              border: {
                                  display: true,
                                  color: '#e2e8f0' // Solid vertical line
                              }
                          }
                      }
                  }
              });
          }

          // 4. Gender Donut Chart (Stays untouched)
          const genderCanvas = document.getElementById('genderChart');
          const genderLabels = <?= json_encode($gender_labels ?? []) ?>;

          if (genderCanvas && genderLabels.length > 0) {
              const genderCtx = genderCanvas.getContext('2d');
              new Chart(genderCtx, {
                  type: 'doughnut',
                  data: {
                      labels: genderLabels,
                      datasets: [{
                          data: <?= json_encode($gender_counts ?? []) ?>,
                          backgroundColor: ['#0d6efd', '#198754', '#ffc107', '#dc3545', '#6f42c1', '#fd7e14', '#20c997'],
                          borderWidth: 0,
                          hoverOffset: 10
                      }]
                  },
                  options: {
                      responsive: true,
                      maintainAspectRatio: true,
                      plugins: {
                          legend: { position: 'bottom' },
                          tooltip: {
                              callbacks: {
                                  label: function(ctx) {
                                      const value = Number(ctx.raw) || 0;
                                      const percentage = ((value / totalMembers) * 100).toFixed(1);
                                      return `${ctx.label}: ${value} members (${percentage}%)`;
                                  }
                              }
                          }
                      },
                      cutout: '60%'
                  }
              });
          }
      });
    </script>

    <!-- footer (admin) includes report issue modal -->
    <?php include '../includes/footer_admin.php'; ?>
