<?php
/**
 * Membership Portal.
 * Manage Permissions – Primary Admin only.
 * Allows the primary admin to create, edit, and delete permissions.
 * Permissions are atomic actions (e.g., view_members, edit_members, generate_reports).
 *
 * Features:
 * - Create new permission (name, display name, description).
 * - Edit existing permission (display name, description).
 * - Delete permission (with confirmation).
 * - Prevents creation/deletion of reserved permissions (manage_admins, manage_admin).
 *
 * @package    MembershipPortal.
 * @author     Heshan Shibry <heshan.shib@gmail.com>
 * @copyright  2026 HESHAN SHIBRY.
 * @license    Proprietary - All rights reserved.
 * @version    1.0.0.
 */
require_once '../includes/auth.php';
$pdo = getDB();
validateAdminSession($pdo);
$isSuperAdmin = ($_SESSION['is_super_admin'] == 1);
$isPrimary = ($_SESSION['user_id'] == 1);
// Fetch profile picture for navbar avatar
$stmt = $pdo->prepare("SELECT profile_pic FROM admins WHERE id = ?");
$stmt->execute([$_SESSION['user_id']]);
$avatarPic = $stmt->fetchColumn();

if ($_SESSION['user_id'] != 1) {
    redirect('admin/dashboard');
}

$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';

    if ($action === 'create') {
        $name = sanitize($_POST['name']);
        $display_name = sanitize($_POST['display_name']);
        $description = sanitize($_POST['description']);

        // Block reserved permission names
        $blocked = ['manage_admins', 'manage_admin'];
        if (in_array(strtolower($name), $blocked)) {
            $error = "The permission '{$name}' is reserved and cannot be created.";
        } else {
            $check = $pdo->prepare("SELECT id FROM permissions WHERE name = ?");
            $check->execute([$name]);
            if ($check->fetch()) {
                $error = "Permission name already exists.";
            } else {
                $stmt = $pdo->prepare("INSERT INTO permissions (name, display_name, description) VALUES (?, ?, ?)");
                if ($stmt->execute([$name, $display_name, $description])) {
                    $success = "Permission created successfully.";
                } else {
                    $error = "Failed to create permission.";
                }
            }
        }
    } elseif ($action === 'edit') {
        $id = (int)$_POST['id'];
        $display_name = sanitize($_POST['display_name']);
        $description = sanitize($_POST['description']);
        $stmt = $pdo->prepare("UPDATE permissions SET display_name = ?, description = ? WHERE id = ?");
        if ($stmt->execute([$display_name, $description, $id])) {
            $success = "Permission updated.";
        } else {
            $error = "Update failed.";
        }
    } elseif ($action === 'delete') {
        $id = (int)$_POST['id'];
        $stmt = $pdo->prepare("SELECT name FROM permissions WHERE id = ?");
        $stmt->execute([$id]);
        $perm = $stmt->fetch();
        $blocked = ['manage_admins', 'manage_admin'];
        if ($perm && in_array(strtolower($perm['name']), $blocked)) {
            $error = "Cannot delete the reserved permission.";
        } else {
            $stmt = $pdo->prepare("DELETE FROM permissions WHERE id = ?");
            if ($stmt->execute([$id])) {
                $success = "Permission deleted.";
            } else {
                $error = "Delete failed.";
            }
        }
    }
}

$permissions = $pdo->query("SELECT * FROM permissions ORDER BY id")->fetchAll();

$isLoggedIn = true;
$userRole = $_SESSION['role'];
$fullName = $_SESSION['full_name'];
$userId = $_SESSION['user_id'];
$hasGenerateReports = hasPermission('generate_reports');
$hasRestoreUsers = hasPermission('restore_users');
$baseUrl = BASE_URL;
$currentPage = 'manage_permissions';
$hideAdminLinks = false;
?>
<?php
// Set page title and optional custom styles
$page_title = 'Manage Permissions';
$page_styles = '
    <style>
    /* Fix vertical alignment of user avatar in navbar */
    .navbar .dropdown-toggle {
          display: flex !important;
          align-items: center !important;
          gap: 3px !important;
          line-height: 1 !important;
      }
      .navbar .dropdown-toggle img,
      .navbar .dropdown-toggle i {
          display: inline-block;
          vertical-align: middle;
      }
    </style>
';

// Include the global header
include '../includes/header.php';
?>

  <!-- Shared navbar (admin) -->
  <?php include '../includes/navbar.php'; ?>

  <main class="container my-5">
    <?php if ($error): ?>
          <div class="alert alert-danger d-flex align-items-center border-0 border-start border-4 border-danger shadow-sm mb-4" role="alert">
              <!-- Modern Bootstrap SVG Exclamation Warning Icon -->
              <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="currentColor" class="bi bi-exclamation-triangle-fill me-3 flex-shrink-0" viewBox="0 0 16 16">
                  <path d="M8.982 1.566a1.13 1.13 0 0 0-1.96 0L.165 13.233c-.457.778.091 1.767.98 1.767h13.713c.889 0 1.438-.99.98-1.767zM8 5c.535 0 .954.462.9.995l-.35 3.507a.552.552 0 0 1-1.1 0L7.1 5.995A.905.905 0 0 1 8 5m.002 6a1 1 0 1 1 0 2 1 1 0 0 1 0-2"/>
              </svg>
              <div class="small fw-semibold">
                  <?= $error ?>
              </div>
          </div>
      <?php endif; ?>

      <?php if ($success): ?>
            <div class="alert alert-success d-flex align-items-center alert-dismissible fade show border-0 border-start border-4 border-success shadow-sm mb-4" role="alert">
                <!-- Modern Bootstrap SVG Check Circle Icon -->
                <svg xmlns="http://www.w3.org/2000/svg" width="22" height="22" fill="currentColor" class="bi bi-check-circle-fill me-3 flex-shrink-0" viewBox="0 0 16 16">
                    <path d="M16 8A8 8 0 1 1 0 8a8 8 0 0 1 16 0m-3.97-3.03a.75.75 0 0 0-1.08.022L7.477 9.417 5.384 7.323a.75.75 0 0 0-1.06 1.06L6.97 11.03a.75.75 0 0 0 1.079-.02l3.992-4.99a.75.75 0 0 0-.01-1.05z"/>
                </svg>
                <div>
                    <div class="small fw-semibold">
                      <?= $success ?>
                    </div>
                </div>
                <!-- Native Bootstrap 5 Close Button -->
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php endif; ?>

        <!-- Create Permission Card -->
        <div class="card shadow-sm mb-4">
            <div class="card-header bg-secondary text-white">
                <i class="bi bi-plus-circle"></i> Create New Permission
            </div>
            <div class="card-body">
                <form method="POST" class="row g-3">
                    <input type="hidden" name="action" value="create">
                    <div class="col-md-4">
                        <label class="form-label">Permission Name (code)</label>
                        <input type="text" name="name" class="form-control" required placeholder="e.g., edit_news">
                        <small class="text-muted">Use snake_case, unique.</small>
                    </div>
                    <div class="col-md-4">
                        <label class="form-label">Display Name</label>
                        <input type="text" name="display_name" class="form-control" required placeholder="Edit News">
                    </div>
                    <div class="col-md-4">
                        <label class="form-label">Description</label>
                        <input type="text" name="description" class="form-control" placeholder="Can edit news articles">
                    </div>
                    <div class="col-12">
                        <button type="submit" class="btn btn-primary">Create Permission</button>
                    </div>
                </form>
            </div>
        </div>

        <!-- List Permissions Card -->
        <div class="card shadow-sm">
            <div class="card-header bg-secondary text-white">
                <i class="bi bi-list-ul"></i> Existing Permissions
            </div>
            <div class="card-body">
              <div class="table-responsive">
                  <table class="table table-hover align-middle custom-admin-table">
                      <thead class="table-light">
                          <tr>
                              <th class="ps-3" style="width: 80px;">ID</th>
                              <th>Permission Code</th>
                              <th>Display Name</th>
                              <th>Description</th>
                              <th class="text-end pe-3">Actions</th>
                          </tr>
                      </thead>
                      <tbody>
                          <?php foreach ($permissions as $perm): ?>
                          <tr>
                              <td class="ps-3 text-muted small">#<?= $perm['id'] ?></td>
                              <td>
                                  <code class="px-2 py-1 bg-light border rounded text-danger small">
                                      <?= htmlspecialchars($perm['name']) ?>
                                  </code>
                              </td>
                              <td>
                                  <div class="fw-bold text-dark">
                                      <i class="bi bi-key-fill me-2 text-warning"></i>
                                      <?= htmlspecialchars($perm['display_name']) ?>
                                  </div>
                              </td>
                              <td class="text-secondary small">
                                  <?= htmlspecialchars($perm['description']) ?>
                              </td>
                              <td class="text-end pe-3">
                                  <div class="d-flex justify-content-end gap-2">
                                      <!-- Edit Button -->
                                      <button type="button" class="btn btn-sm btn-outline-primary rounded-pill px-3"
                                          data-bs-toggle="modal" data-bs-target="#editPermModal"
                                          data-id="<?= $perm['id'] ?>"
                                          data-name="<?= htmlspecialchars($perm['name']) ?>"
                                          data-display="<?= htmlspecialchars($perm['display_name']) ?>"
                                          data-desc="<?= htmlspecialchars($perm['description']) ?>">
                                          <i class="bi bi-pencil-square me-1"></i> Edit
                                      </button>

                                      <!-- Delete Button -->
                                      <form method="POST" class="d-inline" onsubmit="return confirm('Delete this permission? This may affect roles that use it.');">
                                          <input type="hidden" name="action" value="delete">
                                          <input type="hidden" name="id" value="<?= $perm['id'] ?>">
                                          <button type="submit" class="btn btn-sm btn-outline-danger rounded-pill px-3">
                                              <i class="bi bi-trash"></i> Delete
                                          </button>
                                      </form>
                                  </div>
                              </td>
                          </tr>
                          <?php endforeach; ?>
                      </tbody>
                  </table>
                </div>
            </div>
        </div>
  </main>

    <!-- Edit Permission Modal (unchanged) -->
    <div class="modal fade" id="editPermModal" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <form method="POST">
                    <input type="hidden" name="action" value="edit">
                    <input type="hidden" name="id" id="edit_id">
                    <div class="modal-header bg-dark text-white">
                        <h5 class="modal-title">Edit Permission</h5>
                        <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                    </div>
                    <div class="modal-body">
                        <div class="mb-3">
                            <label class="form-label">Name (code) – read only</label>
                            <input type="text" id="edit_name" class="form-control bg-light" readonly>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Display Name</label>
                            <input type="text" name="display_name" id="edit_display" class="form-control" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Description</label>
                            <input type="text" name="description" id="edit_desc" class="form-control">
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                        <button type="submit" class="btn btn-primary">Save Changes</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- footer (admin) includes report issue modal -->
    <?php include '../includes/footer_admin.php'; ?>
