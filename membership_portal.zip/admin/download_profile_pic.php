<?php
/**
 * Membership Portal.
 * Download Profile Picture – Forces download of a member's profile picture.
 * Access: only admins with view_members permission.
 *
 * @package    MembershipPortal.
 * @author     Heshan Shibry <heshan.shib@gmail.com>
 * @copyright  2026 HESHAN SHIBRY.
 * @license    Proprietary - All rights reserved.
 * @version    1.0.0.
 */
require_once '../includes/auth.php';
$pdo = getDB();

if (!isset($_SESSION['user_id']) || !hasPermission(PERM_VIEW_MEMBERS)) {
    die('Unauthorized');
}

$memberId = isset($_GET['id']) ? (int)$_GET['id'] : 0;
if (!$memberId) die('Invalid member ID');

$stmt = $pdo->prepare("SELECT profile_pic, full_name FROM members WHERE id = ?");
$stmt->execute([$memberId]);
$member = $stmt->fetch();
if (!$member || !$member['profile_pic']) die('No profile picture');

$filePath = '../' . $member['profile_pic'];
if (!file_exists($filePath)) die('File not found');

// Create a safe filename
$safeName = 'profile_' . preg_replace('/[^a-zA-Z0-9]/', '_', $member['full_name']) . '.jpg';

header('Content-Description: File Transfer');
header('Content-Type: application/octet-stream');
header('Content-Disposition: attachment; filename="' . $safeName . '"');
header('Expires: 0');
header('Cache-Control: must-revalidate');
header('Pragma: public');
header('Content-Length: ' . filesize($filePath));
readfile($filePath);
exit;
?>
