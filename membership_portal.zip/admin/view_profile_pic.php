<?php
/**
 * Membership Portal.
 * View Profile Picture – Displays a member's profile picture inline.
 * Access: only admins with view_members permission.
 *
 * @package    MembershipPortal.
 * @author     Heshan Shibry <heshan.shib@gmail.com>
 * @copyright  2026 HESHAN SHIBRY.
 * @license    Proprietary - All rights reserved.
 * @version    1.0.0.
 */
require_once '../includes/auth.php';
$pdo = getDB();

if (!isset($_SESSION['user_id']) || !hasPermission(PERM_VIEW_MEMBERS)) {
    die('Unauthorized');
}

$memberId = isset($_GET['id']) ? (int)$_GET['id'] : 0;
if (!$memberId) die('Invalid member ID');

$stmt = $pdo->prepare("SELECT profile_pic FROM members WHERE id = ?");
$stmt->execute([$memberId]);
$profilePic = $stmt->fetchColumn();

if (!$profilePic) {
    // No profile picture – return a default image or 404
    header('HTTP/1.0 404 Not Found');
    die('No profile picture');
}

$filePath = '../' . $profilePic;
if (!file_exists($filePath)) {
    header('HTTP/1.0 404 Not Found');
    die('File not found');
}

// Determine MIME type
$finfo = finfo_open(FILEINFO_MIME_TYPE);
$mimeType = finfo_file($finfo, $filePath);
finfo_close($finfo);

header('Content-Type: ' . $mimeType);
header('Content-Disposition: inline; filename="profile.jpg"');
header('Content-Length: ' . filesize($filePath));
readfile($filePath);
exit;
?>
