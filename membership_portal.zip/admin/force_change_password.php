<?php
/**
 * Membership Portal.
 * Force Password Change Page
 * Redirected here after login if force_password_change = 1.
 * The new admin must set a new password AND complete their profile.
 * ALL fields (Full Name, Gender, Province, District, City, Phone, Address) are required.
 *
 * Gender field uses the same layout and JS as setup/register (no pre‑selected values).
 *
 * @package    MembershipPortal.
 * @author     Heshan Shibry <heshan.shib@gmail.com>
 * @copyright  2026 HESHAN SHIBRY.
 * @license    Proprietary - All rights reserved.
 * @version    1.0.0.
 */
require_once '../includes/auth.php';
$pdo = getDB();
validateAdminSession($pdo);

if (!isset($_SESSION['user_id'])) {
    redirect('admin');
    exit;
}

$userId = $_SESSION['user_id'];

// Fetch current admin data (to pre‑fill the form – only name and email exist)
$stmt = $pdo->prepare("SELECT * FROM admins WHERE id = ?");
$stmt->execute([$userId]);
$admin = $stmt->fetch();
if (!$admin) {
    redirect('admin');
    exit;
}

// Get current geographic IDs (province, district, city) from the stored city_id
$current_city_id = (int)$admin['city_id'];
$current_province_id = 0;
$current_district_id = 0;
if ($current_city_id) {
    $loc = $pdo->prepare("
        SELECT p.id as province_id, d.id as district_id
        FROM cities c
        JOIN districts d ON c.district_id = d.id
        JOIN provinces p ON d.province_id = p.id
        WHERE c.id = ?
    ");
    $loc->execute([$current_city_id]);
    $locData = $loc->fetch();
    if ($locData) {
        $current_province_id = $locData['province_id'];
        $current_district_id = $locData['district_id'];
    }
}

// Fetch all provinces for the dropdown
$provinces = $pdo->query("SELECT id, name_en, name_si, name_ta FROM provinces ORDER BY name_en")->fetchAll();

// Helper to format trilingual names
function formatTrilingual($name_en, $name_si, $name_ta) {
    $text = $name_en;
    if ($name_si && $name_ta) $text .= " ($name_si / $name_ta)";
    elseif ($name_si) $text .= " ($name_si)";
    elseif ($name_ta) $text .= " ($name_ta)";
    return htmlspecialchars($text);
}

// Parse stored phone (will be empty for new admin)
$phone_code = '';
$phone_number = '';
if (!empty($admin['phone'])) {
    $parts = explode(' ', $admin['phone'], 2);
    $phone_code = $parts[0] ?? '';
    $phone_number = $parts[1] ?? '';
}

$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // --- Profile fields (all required) ---
    $full_name = sanitize($_POST['full_name']);
    $address = sanitize($_POST['address']);

    // Geographic selections
    $province_id = isset($_POST['province']) ? (int)$_POST['province'] : 0;
    $district_id = isset($_POST['district']) ? (int)$_POST['district'] : 0;
    $city_id = isset($_POST['city']) ? (int)$_POST['city'] : 0;

    // Resolve names
    $province_name = '';
    $district_name = '';
    $city_name = '';
    if ($province_id > 0) {
        $stmt = $pdo->prepare("SELECT name_en FROM provinces WHERE id = ?");
        $stmt->execute([$province_id]);
        $province_name = $stmt->fetchColumn() ?: '';
    }
    if ($district_id > 0) {
        $stmt = $pdo->prepare("SELECT name_en FROM districts WHERE id = ?");
        $stmt->execute([$district_id]);
        $district_name = $stmt->fetchColumn() ?: '';
    }
    if ($city_id > 0) {
        $stmt = $pdo->prepare("SELECT name_en FROM cities WHERE id = ?");
        $stmt->execute([$city_id]);
        $city_name = $stmt->fetchColumn() ?: '';
    } else {
        $city_id = null;
    }

    // Phone (required)
    $phone_code = sanitize($_POST['phone_code'] ?? '');
    $phone_number = sanitize($_POST['phone_number'] ?? '');
    $phone = !empty($phone_code) && !empty($phone_number) ? $phone_code . ' ' . $phone_number : '';

    // Gender (required) – with custom text validation for "Other"
    $gender = sanitize($_POST['gender'] ?? '');
    $gender_custom = sanitize($_POST['gender_custom'] ?? '');
    $allowedGenders = ['Male', 'Female', 'Prefer not to say', 'Other'];
    if (!in_array($gender, $allowedGenders)) {
        $gender = null;
    }
    if ($gender !== 'Other') {
        $gender_custom = null;
    } else {
        $gender_custom = trim($gender_custom);
        if (strlen($gender_custom) > 50) $gender_custom = substr($gender_custom, 0, 50);
        if (empty($gender_custom)) {
            $error = "Please specify your gender when selecting 'Other'.";
        }
    }

    // --- Password fields (required) ---
    $new_password = $_POST['new_password'];
    $confirm = $_POST['confirm_password'];

    // --- Validation (all required) ---
    if (empty($error)) {
        if (empty($full_name)) {
            $error = "Full name is required.";
        } elseif (empty($gender)) {
            $error = "Gender is required.";
        } elseif (empty($province_id)) {
            $error = "Province is required.";
        } elseif (empty($district_id)) {
            $error = "District is required.";
        } elseif (empty($city_id)) {
            $error = "City/Town is required.";
        } elseif (empty($phone_code) || empty($phone_number)) {
            $error = "Phone number is required.";
        } elseif (empty($address)) {
            $error = "Address is required.";
        } elseif ($new_password !== $confirm) {
            $error = "Passwords do not match.";
        } elseif (!isStrongPassword($new_password)) {
            $error = "Password must be at least 8 characters and include uppercase, lowercase, digit, and special character (e.g., @, #, $, %).";
        } else {
            // Update all fields EXCEPT email (email never changes)
            $hashed = password_hash($new_password, PASSWORD_DEFAULT);
            $update = $pdo->prepare("
                UPDATE admins SET
                    password = ?, force_password_change = 0, temp_password_expires = NULL,
                    full_name = ?,
                    province = ?, district = ?, city = ?, city_id = ?,
                    phone = ?, address = ?,
                    gender = ?, gender_custom = ?
                WHERE id = ?
            ");
            if ($update->execute([
                $hashed, $full_name,
                $province_name, $district_name, $city_name, $city_id,
                $phone, $address,
                $gender, $gender_custom,
                $userId
            ])) {
                $_SESSION['full_name'] = $full_name;
                $success = "Profile created and password changed successfully. Redirecting to dashboard...";
                $dashboardUrl = BASE_URL . 'admin/dashboard';

                // Hide the form immediately on page load (form must have id="activationForm")
                echo '<script>
                    document.addEventListener("DOMContentLoaded", function() {
                        var form = document.getElementById("activationForm");
                        if (form) form.style.display = "none";
                    });
                </script>';

                // Auto‑redirect after 2 seconds
                echo '<meta http-equiv="refresh" content="2;url=' . $dashboardUrl . '">';
            } else {
                $error = "Failed to update. Please try again.";
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en" class="h-100">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Complete Your Profile & Change Password | National Movement</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../assets/css/style.css">
    <style>
        body { display: flex; flex-direction: column; min-height: 100vh; }
        main { flex: 1 0 auto; }
        footer { flex-shrink: 0; }
        .form-check {
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }
        .form-check-input {
            margin: 0;
            cursor: pointer;
        }
        select.form-select {
            cursor: pointer;
        }
        #genderSpecifyWrapper {
            display: none;
        }
        .form-select, .form-select option {
            text-overflow: ellipsis;
            overflow: hidden;
            white-space: nowrap;
        }
    </style>
</head>
<body class="bg-light d-flex flex-column min-vh-100">

    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <div class="container justify-content-center">
            <h4 class="text-white fw-bold mx-auto text-center">🔐 Complete Your Profile & Set New Password</h4>
        </div>
    </nav>

    <main class="container my-5">
        <div class="row justify-content-center">
            <div class="col-md-8 col-lg-7">
                <div class="card shadow-sm border-0 rounded-4">
                    <div class="card-body p-4 p-md-5">
                        <h2 class="card-title text-center mb-3">Welcome, <?= htmlspecialchars($admin['full_name']) ?>!</h2>
                        <p class="text-muted text-center mb-4">Please complete your profile and set a new secure password.<br>All fields are required.</p>
                        <hr>
                        <?php if ($error): ?>
                              <div class="alert alert-danger d-flex align-items-center border-0 border-start border-4 border-danger shadow-sm mb-4" role="alert">
                                  <!-- Modern Bootstrap SVG Exclamation Warning Icon -->
                                  <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="currentColor" class="bi bi-exclamation-triangle-fill me-3 flex-shrink-0" viewBox="0 0 16 16">
                                      <path d="M8.982 1.566a1.13 1.13 0 0 0-1.96 0L.165 13.233c-.457.778.091 1.767.98 1.767h13.713c.889 0 1.438-.99.98-1.767zM8 5c.535 0 .954.462.9.995l-.35 3.507a.552.552 0 0 1-1.1 0L7.1 5.995A.905.905 0 0 1 8 5m.002 6a1 1 0 1 1 0 2 1 1 0 0 1 0-2"/>
                                  </svg>
                                  <div class="small fw-semibold">
                                      <?= $error ?>
                                  </div>
                              </div>
                          <?php endif; ?>

                          <?php if ($success): ?>
                                <div class="alert alert-success d-flex align-items-center alert-dismissible fade show border-0 border-start border-4 border-success shadow-sm mb-4" role="alert">
                                    <!-- Modern Bootstrap SVG Check Circle Icon -->
                                    <svg xmlns="http://www.w3.org/2000/svg" width="22" height="22" fill="currentColor" class="bi bi-check-circle-fill me-3 flex-shrink-0" viewBox="0 0 16 16">
                                        <path d="M16 8A8 8 0 1 1 0 8a8 8 0 0 1 16 0m-3.97-3.03a.75.75 0 0 0-1.08.022L7.477 9.417 5.384 7.323a.75.75 0 0 0-1.06 1.06L6.97 11.03a.75.75 0 0 0 1.079-.02l3.992-4.99a.75.75 0 0 0-.01-1.05z"/>
                                    </svg>
                                    <div>
                                        <div class="small fw-semibold">
                                          <?= $success ?>
                                        </div>
                                    </div>
                                </div>
                            <?php endif; ?>
                            <form method="POST" autocomplete="off" id="activationForm">
                                <!-- Hidden dummy fields to prevent autofill -->
                                <input type="password" name="fakepasswordremembered" style="display:none">

                                <div class="row">
                                    <div class="col-md-6 mb-3">
                                        <label class="form-label fw-semibold">Full Name *</label>
                                        <input type="text" name="full_name" class="form-control" value="<?= htmlspecialchars($admin['full_name']) ?>" required>
                                    </div>
                                    <div class="col-md-6 mb-3">
                                        <label class="form-label fw-semibold">Email (read-only)</label>
                                        <input type="email" name="email" class="form-control bg-light" value="<?= htmlspecialchars($admin['email']) ?>" readonly disabled>
                                    </div>
                                </div>

                                <!-- Geographic Hierarchy (Province -> District -> City) – all required -->
                                <div class="row align-items-end g-3 mb-3">
                                    <div class="col-md-4">
                                        <label class="form-label fw-semibold">Province *</label>
                                        <select id="provinceSelect" name="province" class="form-select" required>
                                            <option value="">Select Province</option>
                                            <?php foreach ($provinces as $p): ?>
                                                <option value="<?= $p['id'] ?>" <?= ($current_province_id == $p['id']) ? 'selected' : '' ?>>
                                                    <?= formatTrilingual($p['name_en'], $p['name_si'], $p['name_ta']) ?>
                                                </option>
                                            <?php endforeach; ?>
                                        </select>
                                    </div>
                                    <div class="col-md-4">
                                        <label class="form-label fw-semibold">District *</label>
                                        <select id="districtSelect" name="district" class="form-select" <?= $current_district_id ? '' : 'disabled' ?> required>
                                            <option value="">Select...</option>
                                        </select>
                                    </div>
                                    <div class="col-md-4">
                                        <label class="form-label fw-semibold">City / Town *</label>
                                        <select id="citySelect" name="city" class="form-select" <?= $current_city_id ? '' : 'disabled' ?> required>
                                            <option value="">Select...</option>
                                        </select>
                                    </div>
                                </div>

                                <div class="col-md-4 mb-3">
                                    <label class="form-label fw-semibold">Admin ID (read-only)</label>
                                    <input type="text" class="form-control bg-light" value="<?= htmlspecialchars($admin['admin_id']) ?>" readonly disabled>
                                </div>

                                <!-- Gender Field – consistent with setup/register (vertical layout, no pre‑selected values) -->
                                <div class="mb-3">
                                    <label class="form-label fw-semibold">Gender *</label>
                                    <select id="genderSelect" name="gender" class="form-select" required>
                                        <option value="" selected>Select...</option>
                                        <option value="Male">Male</option>
                                        <option value="Female">Female</option>
                                        <option value="Prefer not to say">Prefer not to say</option>
                                        <option value="Other">Other</option>
                                    </select>
                                </div>
                                <div class="mb-3" id="genderSpecifyWrapper">
                                    <label class="form-label fw-semibold">Please specify *</label>
                                    <input type="text" id="genderSpecifyInput" name="gender_custom" class="form-control" placeholder="e.g., Non-binary">
                                </div>

                                <div class="col-md-5 mb-3">
                                    <label class="form-label fw-semibold">Phone Number *</label>
                                    <div class="row g-2">
                                        <div class="col-4">
                                            <select name="phone_code" class="form-select" required>
                                                <option value="+94" <?= $phone_code == '+94' ? 'selected' : '' ?>>+94</option>
                                                <option value="+91" <?= $phone_code == '+91' ? 'selected' : '' ?>>+91</option>
                                                <option value="+1" <?= $phone_code == '+1' ? 'selected' : '' ?>>+1</option>
                                                <option value="+44" <?= $phone_code == '+44' ? 'selected' : '' ?>>+44</option>
                                                <option value="+61" <?= $phone_code == '+61' ? 'selected' : '' ?>>+61</option>
                                                <option value="+971" <?= $phone_code == '+971' ? 'selected' : '' ?>>+971</option>
                                            </select>
                                        </div>
                                        <div class="col-8">
                                            <input type="tel" name="phone_number" class="form-control" placeholder="712345678" pattern="[0-9]{7,10}" title="7 to 10 digits" value="<?= htmlspecialchars($phone_number) ?>" required>
                                        </div>
                                    </div>
                                    <small class="text-muted">Select country code and enter local number (without leading zero).</small>
                                </div>
                                <div class="col-md-6 mb-4">
                                    <label class="form-label fw-semibold">Address *</label>
                                    <textarea name="address" rows="2" class="form-control" required><?= htmlspecialchars($admin['address']) ?></textarea>
                                </div>

                                <hr>
                                <h5 class="mb-3">Set New Password (required)</h5>
                                <p class="text-muted small mb-3 text-center">
                                    🔒 <strong>Password Requirements:</strong> Minimum 8 characters, a mix of UPPER and lower case, at least one digit, and a symbol (like @, #, $, %).
                                </p>
                                <div class="mb-3">
                                    <label class="form-label fw-semibold">New Password *</label>
                                    <input type="password" name="new_password" id="NewPassword" autocomplete="off" class="form-control" required>
                                    <div class="form-check mt-2">
                                        <input class="form-check-input" type="checkbox" id="showPasswordCheckbox1">
                                        <label class="form-check-label" for="showPasswordCheckbox1">
                                            Show password
                                        </label>
                                    </div>
                                </div>
                                <div class="mb-3">
                                    <label class="form-label fw-semibold">Confirm New Password *</label>
                                    <input type="password" name="confirm_password" id="ConfirmNewPassword" autocomplete="off" class="form-control" required>
                                    <div class="form-check mt-2">
                                        <input class="form-check-input" type="checkbox" id="showPasswordCheckbox2">
                                        <label class="form-check-label" for="showPasswordCheckbox2">
                                            Show password
                                        </label>
                                    </div>
                                </div>
                                <button type="submit" class="btn btn-dark w-100 py-2">Activate</button>
                            </form>
                    </div>
                </div>
            </div>
        </div>
    </main>

    <footer class="bg-dark text-white-50 text-center py-4 mt-auto">
        <p class="mb-0">National Movement – Setup Profile</p>
        <p class="mb-0 mt-2 small">&copy; <?= date('Y') ?> National Movement. All rights reserved.</p>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Show/hide password
        document.getElementById('showPasswordCheckbox1').addEventListener('change', function() {
            const pwd = document.getElementById('NewPassword');
            pwd.type = this.checked ? 'text' : 'password';
        });
        document.getElementById('showPasswordCheckbox2').addEventListener('change', function() {
            const pwd = document.getElementById('ConfirmNewPassword');
            pwd.type = this.checked ? 'text' : 'password';
        });

        // Restrict phone number to digits only
        const phoneInput = document.querySelector('input[name="phone_number"]');
        if (phoneInput) {
            phoneInput.addEventListener('input', function() {
                this.value = this.value.replace(/[^0-9]/g, '');
            });
        }

        // Gender toggle (show/hide custom field and set required attribute)
        (function() {
            const genderSelect = document.getElementById('genderSelect');
            const genderWrapper = document.getElementById('genderSpecifyWrapper');
            const genderInput = document.getElementById('genderSpecifyInput');

            function toggleGenderSpecifyField() {
                if (genderSelect.value === 'Other') {
                    genderWrapper.style.display = 'block';
                    if (genderInput) genderInput.required = true;
                } else {
                    genderWrapper.style.display = 'none';
                    if (genderInput) {
                        genderInput.value = '';
                        genderInput.required = false;
                    }
                }
            }

            if (genderSelect) {
                genderSelect.addEventListener('change', toggleGenderSpecifyField);
                toggleGenderSpecifyField(); // initialise on load (hidden, no required)
            }
        })();

        // Province → District → City cascade (trilingual)
        document.addEventListener('DOMContentLoaded', function () {
            const provinceSelect = document.getElementById('provinceSelect');
            const districtSelect = document.getElementById('districtSelect');
            const citySelect = document.getElementById('citySelect');

            function formatOption(name_en, name_si, name_ta) {
                let text = name_en;
                if (name_si && name_ta) text += ` (${name_si} / ${name_ta})`;
                else if (name_si) text += ` (${name_si})`;
                else if (name_ta) text += ` (${name_ta})`;
                return text;
            }

            provinceSelect.addEventListener('change', function() {
                const provinceId = this.value;
                districtSelect.innerHTML = '<option value="">Loading...</option>';
                districtSelect.disabled = true;
                citySelect.innerHTML = '<option value="">Select...</option>';
                citySelect.disabled = true;
                if (!provinceId) { districtSelect.innerHTML = '<option value="">Select...</option>'; return; }
                fetch(`<?= BASE_URL ?>get_locations.php?type=districts&province_id=${provinceId}`)
                    .then(res => res.json())
                    .then(data => {
                        districtSelect.innerHTML = '<option value="">Select District</option>';
                        data.forEach(item => {
                            districtSelect.innerHTML += `<option value="${item.id}">${formatOption(item.name_en, item.name_si, item.name_ta)}</option>`;
                        });
                        districtSelect.disabled = false;
                    })
                    .catch(err => { districtSelect.innerHTML = '<option value="">Error...</option>'; console.error(err); });
            });

            districtSelect.addEventListener('change', function() {
                const districtId = this.value;
                citySelect.innerHTML = '<option value="">Loading...</option>';
                citySelect.disabled = true;
                if (!districtId) { citySelect.innerHTML = '<option value="">Select...</option>'; return; }
                fetch(`<?= BASE_URL ?>get_locations.php?type=cities&district_id=${districtId}`)
                    .then(res => res.json())
                    .then(data => {
                        citySelect.innerHTML = '<option value="">Select City/Town</option>';
                        data.forEach(item => {
                            citySelect.innerHTML += `<option value="${item.id}">${formatOption(item.name_en, item.name_si, item.name_ta)}</option>`;
                        });
                        citySelect.disabled = false;
                    })
                    .catch(err => { citySelect.innerHTML = '<option value="">Error...</option>'; console.error(err); });
            });
        });

        // Real-time password checklist
        document.addEventListener('DOMContentLoaded', function() {
            const form = document.querySelector('form');
            const submitBtn = document.querySelector('button[type="submit"]');
            const passwordInput = document.querySelector('input[name="new_password"]');
            const confirmInput = document.querySelector('input[name="confirm_password"]');
            if (!passwordInput || !confirmInput) return;

            const checklistDiv = document.createElement('div');
            checklistDiv.className = 'mt-2 small';
            checklistDiv.style.padding = '10px';
            checklistDiv.style.backgroundColor = '#f8f9fa';
            checklistDiv.style.borderRadius = '8px';
            checklistDiv.style.border = '1px solid #e9ecef';
            checklistDiv.innerHTML = `
                <div id="force-length" style="color: #6c757d; font-weight: 500;">❌ Min 8 characters</div>
                <div id="force-upper" style="color: #6c757d; font-weight: 500;">❌ Uppercase & Lowercase letters</div>
                <div id="force-number" style="color: #6c757d; font-weight: 500;">❌ At least 1 number</div>
                <div id="force-special" style="color: #6c757d; font-weight: 500;">❌ Special character (@, #, $, etc.)</div>
                <div id="force-match" style="color: #6c757d; font-weight: 500; margin-top: 5px; border-top: 1px solid #dee2e6; padding-top: 5px;">❌ Passwords match</div>
            `;
            passwordInput.parentNode.insertBefore(checklistDiv, passwordInput.nextSibling);

            function checkPasswordRealTime() {
                const pass = passwordInput.value;
                const confirmPass = confirmInput.value;
                const hasLength = pass.length >= 8;
                const hasUpperLower = /[A-Z]/.test(pass) && /[a-z]/.test(pass);
                const hasNumber = /[0-9]/.test(pass);
                const hasSpecial = /[^A-Za-z0-9]/.test(pass);
                const isMatching = pass === confirmPass && pass.length > 0;

                const updateRule = (id, isValid) => {
                    const el = document.getElementById(id);
                    if (!el) return;
                    if (isValid) {
                        el.innerHTML = el.innerHTML.replace('❌', '✅');
                        el.style.color = '#198754';
                    } else {
                        el.innerHTML = el.innerHTML.replace('✅', '❌');
                        el.style.color = '#6c757d';
                    }
                };
                updateRule('force-length', hasLength);
                updateRule('force-upper', hasUpperLower);
                updateRule('force-number', hasNumber);
                updateRule('force-special', hasSpecial);
                updateRule('force-match', isMatching);

                if (pass.length > 0) {
                    passwordInput.style.borderColor = (hasLength && hasUpperLower && hasNumber && hasSpecial) ? '#198754' : '#dc3545';
                } else {
                    passwordInput.style.borderColor = '';
                }
                if (confirmPass.length > 0) {
                    confirmInput.style.borderColor = isMatching ? '#198754' : '#dc3545';
                } else {
                    confirmInput.style.borderColor = '';
                }

                const allValid = hasLength && hasUpperLower && hasNumber && hasSpecial && isMatching;
                if (submitBtn) {
                    submitBtn.disabled = !allValid;
                    submitBtn.style.opacity = allValid ? "1" : "0.5";
                    submitBtn.style.cursor = allValid ? "pointer" : "not-allowed";
                }
            }

            passwordInput.addEventListener('input', checkPasswordRealTime);
            confirmInput.addEventListener('input', checkPasswordRealTime);

            if (form && submitBtn) {
                form.addEventListener('submit', function() {
                    setTimeout(function() {
                        submitBtn.innerText = "Activating Account...";
                        submitBtn.style.opacity = "0.5";
                        submitBtn.style.pointerEvents = "none";
                    }, 0);
                });
            }
            checkPasswordRealTime();
        });
    </script>
</body>
</html>
