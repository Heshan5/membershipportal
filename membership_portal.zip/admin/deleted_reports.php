<?php
/**
 * Membership Portal.
 * Deleted Records Report with Restore Log.
 * Access: users with generate_reports permission.
 *
 * @package    MembershipPortal.
 * @author     Heshan Shibry <heshan.shib@gmail.com>
 * @copyright  2026 HESHAN SHIBRY.
 * @license    Proprietary - All rights reserved.
 * @version    1.0.0.
 */
require_once '../includes/auth.php';
$pdo = getDB();
validateAdminSession($pdo);

if (!hasPermission('generate_reports')) {
    redirect('admin/dashboard');
}

// Fetch profile picture for navbar avatar
$stmt = $pdo->prepare("SELECT profile_pic FROM admins WHERE id = ?");
$stmt->execute([$_SESSION['user_id']]);
$avatarPic = $stmt->fetchColumn();

// Variables required by shared navbar
$isLoggedIn = true;
$userRole = $_SESSION['role'];
$fullName = $_SESSION['full_name'];
$userId = $_SESSION['user_id'];
$hasGenerateReports = hasPermission('generate_reports');
$hasRestoreUsers = hasPermission('restore_users');
$baseUrl = BASE_URL;
$currentPage = 'deleted_reports';
$hideAdminLinks = false;

$isSuperAdmin = ($_SESSION['is_super_admin'] == 1);
$isPrimary = ($_SESSION['user_id'] == 1);

$date_from = isset($_GET['from']) ? $_GET['from'] : date('Y-m-d', strtotime('-30 days'));
$date_to = isset($_GET['to']) ? $_GET['to'] : date('Y-m-d');

// Fetch deleted members within date range (with deleter's name)
$stmtMembers = $pdo->prepare("SELECT dm.*, a.full_name AS deleter_name
                              FROM deleted_members dm
                              LEFT JOIN admins a ON dm.deleted_by = a.id
                              WHERE DATE(dm.deleted_at) BETWEEN :from AND :to
                              ORDER BY dm.deleted_at ASC");
$stmtMembers->execute([':from' => $date_from, ':to' => $date_to]);
$deletedMembers = $stmtMembers->fetchAll();

// Fetch deleted admins within date range (with deleter's name)
$stmtAdmins = $pdo->prepare("SELECT da.*, a.full_name AS deleter_name
                              FROM deleted_admins da
                              LEFT JOIN admins a ON da.deleted_by = a.id
                              WHERE DATE(da.deleted_at) BETWEEN :from AND :to
                              ORDER BY da.deleted_at ASC");
$stmtAdmins->execute([':from' => $date_from, ':to' => $date_to]);
$deletedAdmins = $stmtAdmins->fetchAll();

// Fetch restore logs within date range
$stmtRestore = $pdo->prepare("SELECT rl.*, a.full_name as restorer_name FROM restore_log rl LEFT JOIN admins a ON rl.restored_by = a.id WHERE DATE(restored_at) BETWEEN :from AND :to ORDER BY restored_at DESC");
$stmtRestore->execute([':from' => $date_from, ':to' => $date_to]);
$restoreLogs = $stmtRestore->fetchAll();

// No server‑side CSV export – we handle it client‑side
?>
<?php
// Set page title and optional custom styles
$page_title = 'Deleted Records Report';
$page_styles = '
    <style>
    body { background: #f4f7fc; display: flex; flex-direction: column; min-height: 100vh; }
    main { flex: 1 0 auto; }
    footer { flex-shrink: 0; }
    .filter-card { background: #f8f9fa; border-radius: 16px; }
    .card { border-radius: 20px; }
    input[type="text"].form-control {
        cursor: pointer;
    }
    /* Fix vertical alignment of user avatar in navbar */
    .navbar .dropdown-toggle {
          display: flex !important;
          align-items: center !important;
          gap: 3px !important;
          line-height: 1 !important;
      }
      .navbar .dropdown-toggle img,
      .navbar .dropdown-toggle i {
          display: inline-block;
          vertical-align: middle;
      }
      /* Styling for Deleted Reports Table */
      .table-responsive .text-muted tr {
          border-left: 4px solid #dee2e6; /* Adds a grey "archived" strip to the side */
      }

      .table-responsive .text-muted td {
          font-size: 0.85rem;
          color: #6c757d !important;
      }

    /* ==========================================================================
       ADDED UTILITIES: Fixes Filter Layout alignment, heights & bubbly elements
       ========================================================================= */

    /* 1. Aligns the inputs and buttons straight on a baseline on large displays */
    #filterForm {
        align-items: stretch !important; /* Stretches to full width on mobile viewports */
    }

    /* 2. Fixes the bubbly input look, making it crisp and clean */
    #filterForm .form-control {
        border-radius: 6px !important;
        padding: 0.35rem 0.75rem !important;
        height: 38px !important;
        margin-bottom: 0 !important;
    }

    /* 3. Fixes the buttons so they match the input height perfectly and support full width on mobile */
    #filterForm .btn {
        height: 38px !important;
        border-radius: 6px !important;
        padding: 0 1.25rem !important;
        display: inline-flex !important;
        align-items: center !important;
        justify-content: center !important;
        font-weight: 500 !important;
        font-size: 0.875rem !important;
        transition: all 0.15s ease-in-out !important; /* Smooth hover transition */
    }

    /* New premium solid dark configuration for the Clear Button */
    #filterForm .btn-dark {
        background-color: #212529 !important; /* Sleek native dark dark grey */
        border-color: #212529 !important;
        color: #ffffff !important;
    }
    #filterForm .btn-dark:hover {
        background-color: #424649 !important; /* Lightens slightly on hover to give visual feedback */
        border-color: #373b3e !important;
        color: #ffffff !important;
    }
    #filterForm .btn-success {
        background-color: #198754 !important;
        border-color: #198754 !important;
        color: #ffffff !important;
    }
    #filterForm .btn-success:hover {
        background-color: #157347 !important; /* Darker green hover */
        border-color: #146c43 !important;
    }

    /* DEFAULT MOBILE-FIRST SETUP: Inputs and buttons stretch full width (100%) by default */
    #filterForm .date-input-wrapper,
    #filterForm .date-input-responsive,
    #filterForm .responsive-filter-btn {
        width: 100% !important;
    }

    /* DESKTOP/LAPTOP VIEW ONLY (768px and up) */
    @media (min-width: 768px) {
        /* Snaps the main form container back to a clean baseline align grid */
        #filterForm {
            align-items: flex-end !important;
        }

        /* Shrinks the input container wrapper elements cleanly back to your 300px desktop choice */
        #filterForm .date-input-responsive {
            max-width: 300px !important;
            min-width: 300px !important;
        }

        /* Restores inline width for wrappers and buttons so they sit side-by-side */
        #filterForm .date-input-wrapper,
        #filterForm .responsive-filter-btn {
            width: auto !important;
        }
    }
    </style>
';

// Include the global header
include '../includes/header.php';
?>
    <!-- Shared navbar (admin) -->
    <?php include '../includes/navbar.php'; ?>

    <main class="container my-5 flex-grow-1">
      <div class="card shadow-sm">
          <div class="card-body">
              <h5 class="card-title">Filter by Deletion / Restore Date</h5>
              <div class="filter-card p-3 mb-4">
                <form method="GET" id="filterForm" class="d-flex flex-column flex-md-row align-items-stretch align-items-md-end gap-3">
                    <div class="w-100 w-md-auto date-input-wrapper">
                        <label class="form-label text-secondary small fw-semibold mb-1">From Date</label>
                        <input type="text" name="from" class="form-control date-input-responsive" id="fromDate" placeholder="From Date" value="<?= $date_from ?>">
                    </div>
                    <div class="w-100 w-md-auto date-input-wrapper">
                        <label class="form-label text-secondary small fw-semibold mb-1">To Date</label>
                        <input type="text" name="to" class="form-control date-input-responsive" id="toDate" placeholder="To Date" value="<?= $date_to ?>">
                    </div>
                    <!--
                      - Added 'flex-column flex-sm-row flex-md-row'
                      - On tiny screens: Stacks perfectly down into a straight vertical layout
                      - On larger screens: Snaps side-by-side automatically
                    -->
                    <div class="d-flex flex-column flex-sm-row flex-md-row align-items-stretch align-items-md-center gap-2 w-100 w-md-auto mt-2 mt-md-0">
                        <button type="submit" class="btn btn-primary px-3 fw-medium text-nowrap responsive-filter-btn">Apply Filter</button>
                        <!-- Modern Minimalist Clear Button -->
                        <a href="<?= BASE_URL ?>admin/deleted_reports" class="btn btn-dark px-3 fw-medium d-inline-flex align-items-center justify-content-center gap-1 text-nowrap responsive-filter-btn">
                            Clear
                        </a>
                        <button type="button" id="exportDeletedCSVBtn" class="btn btn-success fw-medium text-nowrap responsive-filter-btn">Export CSV</button>
                    </div>
                </form>
              </div>
              <h5>Deleted Members</h5>
              <div class="table-responsive">
                  <table class="table table-hover custom-admin-table" id="deletedMembersTable">
                      <thead><tr><th>Member ID</th><th>Name</th><th>Email</th><th>Gender</th><th>Deleted At</th><th>Deleted By</th><th>Reason</th></tr></thead>
                      <tbody>
                          <?php foreach ($deletedMembers as $dm): ?>
                          <tr class="text-muted opacity-75">
                              <td><?= htmlspecialchars($dm['member_id']) ?></td>
                              <td><?= htmlspecialchars($dm['full_name']) ?></td>
                              <td><?= htmlspecialchars($dm['email']) ?></td>
                              <td>
                                  <?php
                                  if (!empty($dm['gender'])) {
                                      $genderDisplay = htmlspecialchars($dm['gender']);
                                      if ($dm['gender'] == 'Other' && !empty($dm['gender_custom'])) {
                                          $genderDisplay .= ' (' . htmlspecialchars($dm['gender_custom']) . ')';
                                      }
                                      echo $genderDisplay;
                                  } else {
                                      echo '-';
                                  }
                                  ?>
                              </td>
                              <td data-utc-time="<?= $dm['deleted_at'] ?>"><?= $dm['deleted_at'] ?></td>
                              <td>
                                  <?php if (!empty($dm['deleter_name'])): ?>
                                      <?= htmlspecialchars($dm['deleter_name']) ?> (ID: <?= $dm['deleted_by'] ?>)
                                  <?php else: ?>
                                      User ID <?= $dm['deleted_by'] ?> (deleted admin account)
                                  <?php endif; ?>
                              </td>
                              <td><?= htmlspecialchars($dm['reason']) ?></td>
                          </tr>
                          <?php endforeach; ?>
                          <?php if (empty($deletedMembers)): ?>
                          <tr><td colspan="8" class="text-center text-muted">No deleted members in this period.</td></tr>
                          <?php endif; ?>
                      </tbody>
                  </table>
              </div>
              <h5 class="mt-4">Deleted Admins</h5>
              <div class="table-responsive">
                  <table class="table table-hover custom-admin-table" id="deletedAdminsTable">
                      <thead><tr><th>Admin ID</th><th>Name</th><th>Email</th><th>Gender</th><th>Deleted At</th><th>Deleted By</th><th>Reason</th></tr></thead>
                      <tbody>
                          <?php foreach ($deletedAdmins as $da): ?>
                          <tr class="text-muted opacity-75">
                              <td><?= htmlspecialchars($da['admin_id']) ?></td>
                              <td><?= htmlspecialchars($da['full_name']) ?></td>
                              <td><?= htmlspecialchars($da['email']) ?></td>
                              <td>
                                  <?php
                                  if (!empty($da['gender'])) {
                                      $genderDisplay = htmlspecialchars($da['gender']);
                                      if ($da['gender'] == 'Other' && !empty($da['gender_custom'])) {
                                          $genderDisplay .= ' (' . htmlspecialchars($da['gender_custom']) . ')';
                                      }
                                      echo $genderDisplay;
                                  } else {
                                      echo '-';
                                  }
                                  ?>
                              </td>
                              <td data-utc-time="<?= $da['deleted_at'] ?>"><?= $da['deleted_at'] ?></td>
                              <td>
                                  <?php if (!empty($da['deleter_name'])): ?>
                                      <?= htmlspecialchars($da['deleter_name']) ?> (ID: <?= $da['deleted_by'] ?>)
                                  <?php else: ?>
                                      User ID <?= $da['deleted_by'] ?> (deleted admin account)
                                  <?php endif; ?>
                              </td>
                              <td><?= htmlspecialchars($da['reason']) ?></td>
                          </tr>
                          <?php endforeach; ?>
                          <?php if (empty($deletedAdmins)): ?>
                          <tr><td colspan="8" class="text-center text-muted">No deleted admins in this period.</td></tr>
                          <?php endif; ?>
                      </tbody>
                  </table>
              </div>
              <h5 class="mt-4">Restore Log</h5>
                <div class="table-responsive">
                    <table class="table table-hover custom-admin-table" id="restoreLogTable">
                        <thead>
                            <tr>
                                <th>Type</th>
                                <th>Name</th>
                                <th>Identifier</th>
                                <th>Gender</th>
                                <th>Restored By</th>
                                <th>Restored At</th>
                                <th>Deleted At</th>
                                <th>Deletion Reason</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($restoreLogs as $log): ?>
                            <tr>
                                <td><?= ucfirst($log['item_type']) ?> </td>
                                <td><?= htmlspecialchars($log['item_name']) ?> </td>
                                <td><?= htmlspecialchars($log['item_identifier']) ?> </td>
                                <td>
                                    <?php
                                    if (!empty($log['gender'])) {
                                        $genderDisplay = htmlspecialchars($log['gender']);
                                        if ($log['gender'] == 'Other' && !empty($log['gender_custom'])) {
                                            $genderDisplay .= ' (' . htmlspecialchars($log['gender_custom']) . ')';
                                        }
                                        echo $genderDisplay;
                                    } else {
                                        echo '-';
                                    }
                                    ?>
                                </td>
                                <td><?= htmlspecialchars($log['restorer_name']) ?> (ID: <?= $log['restored_by'] ?>)</td>
                                <td data-utc-time="<?= $log['restored_at'] ?>"><?= $log['restored_at'] ?></td>
                                <td data-utc-time="<?= $log['deleted_at'] ?>"><?= $log['deleted_at'] ?></td>
                                <td><?= htmlspecialchars($log['deletion_reason'] ?: '-') ?> </td>
                            </tr>
                            <?php endforeach; ?>
                            <?php if (empty($restoreLogs)): ?>
                            <tr>
                                <td colspan="8" class="text-center text-muted">No restore logs in this period.</td>
                            </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
          </div>
      </div>
    </main>

    <!-- footer (admin) includes report issue modal -->
    <?php include '../includes/footer_admin.php'; ?>
