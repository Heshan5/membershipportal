<?php
/**
 * Membership Portal.
 * Admin Login Page.
 *
 * Authenticates administrators against the `admins` table.
 * Handles expired temporary accounts (1‑hour expiration) and redirects to
 * password change page if forced (force_password_change = 1).
 * On successful login, redirects to the admin dashboard.
 *
 * @package    MembershipPortal.
 * @author     Heshan Shibry <heshan.shib@gmail.com>
 * @copyright  2026 HESHAN SHIBRY.
 * @license    Proprietary - All rights reserved.
 * @version    1.0.0.
 */
require_once '../includes/auth.php';
$pdo = getDB();
$baseUrl = BASE_URL; // defined in config/database.php

if (!hasAdmin($pdo)) {
    header('Location: ' . BASE_URL . 'setup');
    exit;
}

$error = '';
$success = '';

// If there's a message about expired account from previous request, show it
if (isset($_SESSION['expired_account'])) {
    $error = $_SESSION['expired_account'];
    unset($_SESSION['expired_account']);
}

if (isset($_GET['setup']) && $_GET['setup'] === 'success') {
    $success = "Admin account created successfully! You can now log in.";
}

// Handle login attempt
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = sanitize($_POST['email']);
    $password = $_POST['password'];

    // First, check if the email belongs to an expired temporary account
    $stmt = $pdo->prepare("SELECT id FROM admins WHERE email = ? AND force_password_change = 1 AND temp_password_expires IS NOT NULL AND temp_password_expires < ?");
    $stmt->execute([$email, time()]);
    if ($stmt->fetch()) {
        // Delete the expired account (only this specific one)
        $delStmt = $pdo->prepare("DELETE FROM admins WHERE email = ? AND force_password_change = 1 AND temp_password_expires IS NOT NULL");
        $delStmt->execute([$email]);
        $_SESSION['expired_account'] = "Your temporary account has expired. Please contact a super admin to re‑create your account.";
        header('Location: ' . BASE_URL . 'admin');
        exit;
    }

    // Now attempt normal login
    if (login($email, $password, $pdo)) {
        $stmt = $pdo->prepare("SELECT force_password_change FROM admins WHERE id = ?");
        $stmt->execute([$_SESSION['user_id']]);
        $row = $stmt->fetch();
        if ($row && $row['force_password_change'] == 1) {
            redirect('admin/force_change_password');
        } else {
            redirect('admin/dashboard');
        }
    } else {
        $error = "Invalid email or password.";
    }
}
?>
<!DOCTYPE html>
<html lang="en" class="h-100">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Login | National Movement</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <link rel="stylesheet" href="../assets/css/style.css">
    <style>
        body { display: flex; flex-direction: column; min-height: 100vh; }
        main { flex: 1 0 auto; }
        footer { flex-shrink: 0; }
        .form-check {
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }
        .form-check-input {
            margin: 0;
            cursor: pointer;
        }
        .brand {
          text-align: left;
        }
        a.text-decoration-none:hover {
            text-decoration: underline !important;
            text-underline-offset: 4px;
        }
        .custom-link {
            color: #007bff; /* A nice standard blue */
            transition: color 0.2s ease; /* Makes the color change feel smooth, not jerky */
        }

        .custom-link:hover {
            color: #0056b3; /* A noticeably darker blue for the hover state */
        }
    </style>
</head>
<body class="bg-light d-flex flex-column min-vh-100">

<!-- custom navbar -->
<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
    <div class="container">
          <a class="navbar-brand fw-bold" href="<?= BASE_URL ?>">NATIONAL BUILDER · MOVEMENT</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ms-auto">
                <li class="nav-item"><a class="nav-link" href="<?= BASE_URL ?>">Home</a></li>
            </ul>
        </div>
    </div>
</nav>

      <main class="container my-5">
        <div class="row justify-content-center">
            <div class="col-md-6 col-lg-5">
                <div class="card shadow-sm border-0 rounded-4">
                    <div class="card-body p-4 p-md-5">
                        <h2 class="card-title text-center mb-4">🔐 Admin Login</h2>

                        <!-- Your existing database communication alerts -->
                        <?php if ($error): ?>
                              <div class="alert alert-danger d-flex align-items-center border-0 border-start border-4 border-danger shadow-sm mb-4" role="alert">
                                  <!-- Modern Bootstrap SVG Exclamation Warning Icon -->
                                  <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="currentColor" class="bi bi-exclamation-triangle-fill me-3 flex-shrink-0" viewBox="0 0 16 16">
                                      <path d="M8.982 1.566a1.13 1.13 0 0 0-1.96 0L.165 13.233c-.457.778.091 1.767.98 1.767h13.713c.889 0 1.438-.99.98-1.767zM8 5c.535 0 .954.462.9.995l-.35 3.507a.552.552 0 0 1-1.1 0L7.1 5.995A.905.905 0 0 1 8 5m.002 6a1 1 0 1 1 0 2 1 1 0 0 1 0-2"/>
                                  </svg>
                                  <div class="small fw-semibold">
                                      <?= $error ?>
                                  </div>
                              </div>
                          <?php endif; ?>

                          <?php if ($success): ?>
                                <div class="alert alert-success d-flex align-items-center alert-dismissible fade show border-0 border-start border-4 border-success shadow-sm mb-4" role="alert">
                                    <!-- Modern Bootstrap SVG Check Circle Icon -->
                                    <svg xmlns="http://www.w3.org/2000/svg" width="22" height="22" fill="currentColor" class="bi bi-check-circle-fill me-3 flex-shrink-0" viewBox="0 0 16 16">
                                        <path d="M16 8A8 8 0 1 1 0 8a8 8 0 0 1 16 0m-3.97-3.03a.75.75 0 0 0-1.08.022L7.477 9.417 5.384 7.323a.75.75 0 0 0-1.06 1.06L6.97 11.03a.75.75 0 0 0 1.079-.02l3.992-4.99a.75.75 0 0 0-.01-1.05z"/>
                                    </svg>
                                    <div>
                                        <div class="small fw-semibold">
                                          <?= $success ?>
                                        </div>
                                    </div>
                                    <!-- Native Bootstrap 5 Close Button -->
                                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                                </div>
                            <?php endif; ?>

                          <!-- Integrated Modern Inactivity Timeout Alert using Secure Session Validation -->
                          <?php if (isset($_SESSION['show_timeout_alert']) && $_SESSION['show_timeout_alert'] === true): ?>
                              <div class="alert alert-warning d-flex align-items-center alert-dismissible fade show border-0 border-start border-4 border-warning shadow-sm mb-4" role="alert">
                                  <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="currentColor" class="bi bi-shield-lock-fill me-3 flex-shrink-0" viewBox="0 0 16 16">
                                      <path fill-rule="evenodd" d="M8 0c-.69 0-1.843.265-2.928.56-1.11.3-2.229.655-2.887.87a1.54 1.54 0 0 0-1.044 1.262c-.596 4.477.787 7.795 2.465 9.99a11.8 11.8 0 0 0 2.517 2.453c.386.273.744.482 1.048.625.28.132.581.24.829.24s.548-.108.829-.24a7 7 0 0 0 1.048-.625 11.8 11.8 0 0 0 2.517-2.453c1.678-2.195 3.061-5.513 2.465-9.99a1.54 1.54 0 0 0-1.044-1.263 63 63 0 0 0-2.887-.87C9.843.266 8.69 0 8 0m0 5a1.5 1.5 0 0 1 .5 2.915V9.5a.5.5 0 0 1-1 0V7.915A1.5 1.5 0 0 1 8 5"/>
                                  </svg>
                                  <div>
                                      <h6 class="alert-heading fw-bold mb-1">Session Expired</h6>
                                      <p class="mb-0 small">For your security, you have been logged out due to 30 minutes of inactivity.</p>
                                  </div>
                                  <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                              </div>
                              <!-- Wipes the flash memory immediately after rendering the layout container -->
                              <?php unset($_SESSION['show_timeout_alert']); ?>
                          <?php endif; ?>

                        <!-- login form processing below -->
                        <form method="POST" autocomplete="off">
                            <div class="mb-3">
                                <label class="form-label fw-semibold">Email address</label>
                                <input type="email" name="email" class="form-control" required autofocus>
                            </div>
                            <div class="mb-3">
                                <label class="form-label fw-semibold">Password</label>
                                <!-- Hidden dummy fields to prevent autofill -->
                                <input type="password" name="password" style="display:none">
                                <input type="password" name="password" id="loginPassword" class="form-control" autocomplete="off" required>
                                <div class="form-check mt-2">
                                    <input class="form-check-input" type="checkbox" id="showPasswordCheckbox">
                                    <label class="form-check-label" for="showPasswordCheckbox">
                                        Show password
                                    </label>
                                </div>
                            </div>
                            <script>
                            document.getElementById('showPasswordCheckbox').addEventListener('change', function() {
                                const passwordField = document.getElementById('loginPassword');
                                if (this.checked) {
                                    passwordField.type = 'text';
                                } else {
                                    passwordField.type = 'password';
                                }
                            });
                            </script>
                            <div class="text-center mb-4">
                                <a href="<?= BASE_URL ?>admin/forgot_password" class="text-decoration-none custom-link small">Forgot password?</a>
                            </div>
                            <button type="submit" class="btn btn-dark w-100 py-2">Login</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
      </main>

    <footer class="bg-dark text-white-50 text-center py-4 mt-auto">
        <p class="mb-0">National Movement – Admin Login</p>
        <p class="mb-0 mt-2 small">
            &copy; <?= date('Y') ?> National Movement. All rights reserved.
        </p>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
    <script>
      document.addEventListener('click', function (event) {
          // Only run this if the screen width is mobile (less than 992px)
          if (window.innerWidth < 992) {
              const navbar = document.getElementById('navbarNav');
              const toggler = document.querySelector('.navbar-toggler');

              // Check if menu is open
              const isMenuOpen = navbar.classList.contains('show');

              // Check if the user clicked outside the menu and the hamburger button
              const isClickInside = navbar.contains(event.target) || toggler.contains(event.target);

              if (isMenuOpen && !isClickInside) {
                  const bsCollapse = new bootstrap.Collapse(navbar, {
                      toggle: false
                  });
                  bsCollapse.hide();
              }
          }
      });
      /*
       * ADMIN LOGIN: GREY OUT ONLY
       * This locks the button and fades it to prevent double-clicking,
       * but keeps your original button text visible.
       */
      document.addEventListener('DOMContentLoaded', function() {
          const form = document.querySelector('form');
          const submitBtn = document.querySelector('button[type="submit"]');

          if (form && submitBtn) {
              form.addEventListener('submit', function() {
                  setTimeout(function() {
                      // Button becomes grey and unclickable
                      submitBtn.style.opacity = "0.5";
                      submitBtn.style.pointerEvents = "none";
                      // Text remains unchanged
                  }, 0);
              });
          }
      });
    </script>
</body>
</html>
