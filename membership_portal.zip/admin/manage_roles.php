<?php
/**
 * Membership Portal.
 * Manage Roles – Create, edit, delete roles and assign permissions.
 * Only primary admin (id=1) can access this page.
 *
 * @package    MembershipPortal.
 * @author     Heshan Shibry <heshan.shib@gmail.com>
 * @copyright  2026 HESHAN SHIBRY.
 * @license    Proprietary - All rights reserved.
 * @version    1.0.0.
 */
require_once '../includes/auth.php';
$pdo = getDB();
validateAdminSession($pdo);
$isSuperAdmin = ($_SESSION['is_super_admin'] == 1);
// Fetch profile picture for navbar avatar
$stmt = $pdo->prepare("SELECT profile_pic FROM admins WHERE id = ?");
$stmt->execute([$_SESSION['user_id']]);
$avatarPic = $stmt->fetchColumn();

// Variables required by shared navbar
$isLoggedIn = true;
$userRole = $_SESSION['role'];
$fullName = $_SESSION['full_name'];
$userId = $_SESSION['user_id'];
$hasGenerateReports = hasPermission('generate_reports');
$hasRestoreUsers = hasPermission('restore_users');
$baseUrl = BASE_URL; // defined in config/database.php

// Allow primary and secondary super admins
if (!isset($_SESSION['user_id']) || ($_SESSION['user_id'] != 1 && $_SESSION['is_super_admin'] != 1)) {
    redirect('admin/dashboard');
}

$error = '';
$success = '';

// Handle role creation / deletion
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    if ($action === 'create_role') {
        $name = sanitize($_POST['name']);
        $desc = sanitize($_POST['description']);
        $check = $pdo->prepare("SELECT id FROM roles WHERE name = ?");
        $check->execute([$name]);
        if ($check->fetch()) {
            $error = "Role name already exists.";
        } else {
            $stmt = $pdo->prepare("INSERT INTO roles (name, description) VALUES (?, ?)");
            if ($stmt->execute([$name, $desc])) {
                $roleId = $pdo->lastInsertId();
                if (isset($_POST['perms']) && is_array($_POST['perms'])) {
                    $stmt2 = $pdo->prepare("INSERT INTO role_permissions (role_id, permission_id) VALUES (?, ?)");
                    foreach ($_POST['perms'] as $permId) {
                        $stmt2->execute([$roleId, $permId]);
                    }
                }
                $success = "Role created successfully.";
            } else {
                $error = "Failed to create role.";
            }
        }
      } elseif ($action === 'delete_role') {
        if ($_SESSION['user_id'] != 1) {
            $error = "Only the primary admin can delete roles.";
        } else {
            $roleId = (int)$_POST['role_id'];
            $stmt = $pdo->prepare("DELETE FROM roles WHERE id = ?");
            if ($stmt->execute([$roleId])) {
                $success = "Role deleted.";
            } else {
                $error = "Delete failed.";
            }
        }
    }
}

// Fetch all roles
$roles = $pdo->query("SELECT * FROM roles ORDER BY id")->fetchAll();

// Fetch permissions EXCLUDING 'manage_admins' and 'manage_admin'
$permissions = $pdo->query("SELECT * FROM permissions WHERE name NOT IN ('manage_admins', 'manage_admin') ORDER BY id")->fetchAll();
?>

<?php
// Set page title and optional custom styles
$page_title = 'Manage Roles';
$page_styles = '
    <style>
    body { background: #f4f7fc; }
    .card { border-radius: 20px; }

    /* Same checkbox styling as manage_admins.php */
    .form-check {
        display: flex !important;
        align-items: center !important;
        padding-left: 0 !important;
        margin-bottom: 10px;
    }
    .form-check .form-check-input {
        float: none !important;
        margin: 0 8px 0 0 !important;
        position: static !important;
        flex-shrink: 0;
        cursor: pointer;
    }
    .form-check .form-check-label {
        margin-left: 0 !important;
        font-weight: normal;
        line-height: 1.4;
    }
    /* Fix vertical alignment of user avatar in navbar */
    .navbar .dropdown-toggle {
          display: flex !important;
          align-items: center !important;
          gap: 3px !important;
          line-height: 1 !important;
      }
      .navbar .dropdown-toggle img,
      .navbar .dropdown-toggle i {
          display: inline-block;
          vertical-align: middle;
      }
    </style>
';

// Include the global header
include '../includes/header.php';
?>

  <!-- Shared navbar (admin) -->
  <?php $currentPage = 'manage_roles';
    include '../includes/navbar.php';
  ?>

  <main class="container my-5">
    <?php if ($error): ?>
          <div class="alert alert-danger d-flex align-items-center border-0 border-start border-4 border-danger shadow-sm mb-4" role="alert">
              <!-- Modern Bootstrap SVG Exclamation Warning Icon -->
              <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="currentColor" class="bi bi-exclamation-triangle-fill me-3 flex-shrink-0" viewBox="0 0 16 16">
                  <path d="M8.982 1.566a1.13 1.13 0 0 0-1.96 0L.165 13.233c-.457.778.091 1.767.98 1.767h13.713c.889 0 1.438-.99.98-1.767zM8 5c.535 0 .954.462.9.995l-.35 3.507a.552.552 0 0 1-1.1 0L7.1 5.995A.905.905 0 0 1 8 5m.002 6a1 1 0 1 1 0 2 1 1 0 0 1 0-2"/>
              </svg>
              <div class="small fw-semibold">
                  <?= $error ?>
              </div>
          </div>
      <?php endif; ?>

      <?php if ($success): ?>
            <div class="alert alert-success d-flex align-items-center alert-dismissible fade show border-0 border-start border-4 border-success shadow-sm mb-4" role="alert">
                <!-- Modern Bootstrap SVG Check Circle Icon -->
                <svg xmlns="http://www.w3.org/2000/svg" width="22" height="22" fill="currentColor" class="bi bi-check-circle-fill me-3 flex-shrink-0" viewBox="0 0 16 16">
                    <path d="M16 8A8 8 0 1 1 0 8a8 8 0 0 1 16 0m-3.97-3.03a.75.75 0 0 0-1.08.022L7.477 9.417 5.384 7.323a.75.75 0 0 0-1.06 1.06L6.97 11.03a.75.75 0 0 0 1.079-.02l3.992-4.99a.75.75 0 0 0-.01-1.05z"/>
                </svg>
                <div>
                    <div class="small fw-semibold">
                      <?= $success ?>
                    </div>
                </div>
                <!-- Native Bootstrap 5 Close Button -->
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php endif; ?>

        <!-- Create Role Card -->
        <div class="card shadow-sm mb-4">
            <div class="card-header bg-secondary text-white">
                <i class="bi bi-plus-circle"></i> Create New Role
            </div>
            <div class="card-body">
                <form method="POST">
                    <input type="hidden" name="action" value="create_role">
                    <div class="col-md-4 mb-3">
                        <label class="form-label fw-semibold">Role Name</label>
                        <input type="text" name="name" class="form-control" required>
                    </div>
                    <div class="col-md-4 mb-3">
                        <label class="form-label fw-semibold">Description</label>
                        <textarea name="description" class="form-control" rows="2"></textarea>
                    </div>
                    <div class="mb-3">
                        <label class="form-label fw-semibold">Permissions</label>
                        <div class="row g-3">
                            <?php foreach ($permissions as $p): ?>
                                <div class="col-md-3 col-sm-6">
                                    <div class="form-check">
                                        <input class="form-check-input" type="checkbox" name="perms[]" value="<?= $p['id'] ?>" id="perm_<?= $p['id'] ?>">
                                        <label class="form-check-label" for="perm_<?= $p['id'] ?>">
                                            <?= htmlspecialchars($p['display_name']) ?>
                                        </label>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    </div>
                    <button type="submit" class="btn btn-primary">Create Role</button>
                </form>
            </div>
        </div>

        <!-- Existing Roles Card -->
        <div class="card shadow-sm">
            <div class="card-header bg-secondary text-white">
                <i class="bi bi-list-ul"></i> Existing Roles
            </div>
            <div class="card-body">
              <div class="table-responsive">
                <table class="table table-hover align-middle custom-admin-table">
                    <thead class="table-light">
                        <tr>
                            <th class="ps-3" style="width: 80px;">ID</th>
                            <th style="width: 200px;">Role Name</th>
                            <th>Description</th>
                            <th>Permissions</th>
                            <th class="text-end pe-3">Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($roles as $role):
                            $stmt = $pdo->prepare("
                                SELECT p.display_name FROM role_permissions rp
                                JOIN permissions p ON rp.permission_id = p.id
                                WHERE rp.role_id = ? AND p.name NOT IN ('manage_admins', 'manage_admin')
                            ");
                            $stmt->execute([$role['id']]);
                            $permsList = $stmt->fetchAll(PDO::FETCH_COLUMN);
                        ?>
                        <tr>
                            <td class="ps-3 text-muted small">#<?= $role['id'] ?></td>
                            <td>
                                <div class="fw-bold text-dark d-flex align-items-center">
                                    <i class="bi bi-shield-check me-2 text-primary"></i>
                                    <?= htmlspecialchars($role['name']) ?>
                                </div>
                            </td>
                            <td class="text-secondary small"><?= htmlspecialchars($role['description']) ?></td>
                            <td>
                                <div class="d-flex flex-wrap gap-1">
                                    <?php if (!empty($permsList)): ?>
                                        <?php foreach ($permsList as $perm): ?>
                                            <span class="badge bg-light text-dark border rounded-pill fw-normal" style="font-size: 0.7rem;">
                                                <?= htmlspecialchars($perm) ?>
                                            </span>
                                        <?php endforeach; ?>
                                    <?php else: ?>
                                        <span class="text-muted small italic">No specific permissions</span>
                                    <?php endif; ?>
                                </div>
                            </td>
                            <td class="text-end pe-3">
                                <?php if ($_SESSION['user_id'] == 1): ?>
                                <form method="POST" onsubmit="return confirm('Delete this role? This will remove the role from all admins.')" class="d-inline">
                                    <input type="hidden" name="action" value="delete_role">
                                    <input type="hidden" name="role_id" value="<?= $role['id'] ?>">
                                    <button type="submit" class="btn btn-sm btn-outline-danger rounded-pill px-3">
                                        <i class="bi bi-trash3"></i> Delete
                                    </button>
                                </form>
                                <?php else: ?>
                                    <span class="badge bg-light text-muted border-0">Locked</span>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
              </div>
            </div>
        </div>
    </main>

    <!-- footer (admin) includes report issue modal -->
    <?php include '../includes/footer_admin.php'; ?>
