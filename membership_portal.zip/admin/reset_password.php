<?php
/**
 * Membership Portal.
 * Password Reset Handler.
 *
 * Validates the reset token from the URL, checks expiration (Unix timestamp),
 * and allows the admin to set a new password (must meet strength requirements).
 * On success, deletes the used token and updates the password in `admins` table.
 *
 * @package    MembershipPortal.
 * @author     Heshan Shibry <heshan.shib@gmail.com>
 * @copyright  2026 HESHAN SHIBRY.
 * @license    Proprietary - All rights reserved.
 * @version    1.0.0.
 */
session_start();
require_once '../includes/functions.php';
$pdo = getDB();
$baseUrl = BASE_URL;

// If no admin exists, redirect to setup
if (!hasAdmin($pdo)) {
    header('Location: ' . BASE_URL . 'setup');
    exit;
}

$error = '';
$success = '';

$token = $_GET['token'] ?? $_POST['token'] ?? '';
if (empty($token)) {
    die("Invalid reset link.");
}

$stmt = $pdo->prepare("SELECT * FROM password_resets WHERE token = ?");
$stmt->execute([$token]);
$reset = $stmt->fetch();

if (!$reset || $reset['expires_at'] < time()) {
    die("This password reset link is invalid or has expired. Please request a new one.");
}

$email = $reset['email'];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $new_password = $_POST['new_password'];
    $confirm = $_POST['confirm_password'];

    if ($new_password !== $confirm) {
        $error = "Passwords do not match.";
    } elseif (!isStrongPassword($new_password)) {
        $error = "Password must be at least 8 characters and include at least one uppercase letter, one lowercase letter, one digit, and one special character (e.g., @, #, $, %).";
    } else {
        $hashed = password_hash($new_password, PASSWORD_DEFAULT);
        $stmt = $pdo->prepare("UPDATE admins SET password = ? WHERE email = ?");
        if ($stmt->execute([$hashed, $email])) {
            $pdo->prepare("DELETE FROM password_resets WHERE token = ?")->execute([$token]);
            $success = "Your password has been reset successfully. You can now login with your new password.";
        } else {
            $error = "Failed to reset password. Please try again.";
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reset Password</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../assets/css/style.css">
    <style>
        body { background: #f4f7fc; }
        .form-check {
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }
        .form-check-input {
            margin: 0;
            cursor: pointer;
        }
    </style>
</head>
<body class="bg-light d-flex flex-column min-vh-100">

  <!-- custom navbar -->
  <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
      <div class="container justify-content-center">
          <h4 class="text-white fw-bold mx-auto text-center">NATIONAL BUILDER · MOVEMENT</h4>
      </div>
  </nav>

    <main class="flex-grow-1">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-md-6">
                    <div class="card shadow">
                        <div class="card-body p-4">
                            <h3 class="text-center mb-4">Reset Password</h3>
                            <!-- ========== ERROR ALERT BLOCK ========== -->
                              <?php if ($error): ?>
                                  <div class="alert alert-danger d-flex align-items-center border-0 border-start border-4 border-danger shadow-sm mb-4" role="alert">
                                      <!-- Modern Bootstrap SVG Exclamation Warning Icon -->
                                      <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="currentColor" class="bi bi-exclamation-triangle-fill me-3 flex-shrink-0" viewBox="0 0 16 16">
                                          <path d="M8.982 1.566a1.13 1.13 0 0 0-1.96 0L.165 13.233c-.457.778.091 1.767.98 1.767h13.713c.889 0 1.438-.99.98-1.767zM8 5c.535 0 .954.462.9.995l-.35 3.507a.552.552 0 0 1-1.1 0L7.1 5.995A.905.905 0 0 1 8 5m.002 6a1 1 0 1 1 0 2 1 1 0 0 1 0-2"/>
                                      </svg>
                                      <div class="small fw-semibold"><?= $error ?></div>
                                  </div>
                              <?php endif; ?>

                              <!-- ========== SUCCESS ALERT BLOCK ========== -->
                              <?php if ($success): ?>
                                  <div class="alert alert-success d-flex align-items-center alert-dismissible fade show border-0 border-start border-4 border-success shadow-sm mb-4" role="alert">
                                      <!-- Modern Bootstrap SVG Check Circle Icon -->
                                      <svg xmlns="http://www.w3.org/2000/svg" width="22" height="22" fill="currentColor" class="bi bi-check-circle-fill me-3 flex-shrink-0" viewBox="0 0 16 16">
                                          <path d="M16 8A8 8 0 1 1 0 8a8 8 0 0 1 16 0m-3.97-3.03a.75.75 0 0 0-1.08.022L7.477 9.417 5.384 7.323a.75.75 0 0 0-1.06 1.06L6.97 11.03a.75.75 0 0 0 1.079-.02l3.992-4.99a.75.75 0 0 0-.01-1.05z"/>
                                      </svg>
                                      <div class="small fw-semibold"><?= $success ?></div>
                                      <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                                  </div>

                                  <!-- Your Unaltered Action Button Container Element -->
                                  <div class="text-center mt-3">
                                      <a href="<?= $baseUrl ?>admin" class="btn btn-primary">Go to Admin Login</a>
                                  </div>
                              <?php else: ?>
                                <form method="POST" autocomplete="off">
                                    <!-- Hidden dummy fields to prevent autofill -->
                                    <input type="password" name="fakepasswordremembered" style="display:none">
                                    <input type="hidden" name="token" value="<?= htmlspecialchars($token) ?>">
                                    <div class="mb-3">
                                      <p class="text-muted small mb-3 text-center">
                                          🔒 <strong>Password Requirements:</strong> Minimum 8 characters, a mix of UPPER and lower case, at least one digit, and a symbol (like @, #, $, %).
                                      </p>
                                        <label class="form-label fw-semibold">New Password</label>
                                        <input type="password" name="new_password" id="NewPassword" autocomplete="off" class="form-control" required>
                                        <div class="form-check mt-2">
                                            <input class="form-check-input" type="checkbox" id="showPasswordCheckbox1">
                                            <label class="form-check-label" for="showPasswordCheckbox1">Show password</label>
                                        </div>
                                    </div>
                                    <div class="mb-3">
                                        <label class="form-label fw-semibold">Confirm Password</label>
                                        <input type="password" name="confirm_password" id="ConfirmPassword" autocomplete="off" class="form-control" required>
                                        <div class="form-check mt-2">
                                            <input class="form-check-input" type="checkbox" id="showPasswordCheckbox2">
                                            <label class="form-check-label" for="showPasswordCheckbox2">Show password</label>
                                        </div>
                                    </div>
                                    <script>
                                        document.getElementById('showPasswordCheckbox1').addEventListener('change', function() {
                                            const passwordField = document.getElementById('NewPassword');
                                            if (this.checked) {
                                                passwordField.type = 'text';
                                            } else {
                                                passwordField.type = 'password';
                                            }
                                        });
                                        document.getElementById('showPasswordCheckbox2').addEventListener('change', function() {
                                            const passwordField = document.getElementById('ConfirmPassword');
                                            if (this.checked) {
                                                passwordField.type = 'text';
                                            } else {
                                                passwordField.type = 'password';
                                            }
                                        });
                                    </script>
                                    <button type="submit" class="btn btn-primary w-100">Reset Password</button>
                                </form>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </main>

    <!-- custom footer -->
    <footer class="bg-dark text-white-50 text-center py-4 mt-auto">
        <p class="mb-0">National Movement – Reset Password</p>
        <p class="mb-0 mt-2 small">
            &copy; <?= date('Y') ?> National Movement. All rights reserved.
        </p>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
    <script>
      /*
       * RESET PASSWORD: MODERN REAL-TIME CHECKLIST & VALIDATOR
       * Real-time checks for security criteria, length, matching, and dynamic button locking.
       */
      document.addEventListener('DOMContentLoaded', function() {
          const form = document.querySelector('form');
          const submitBtn = document.querySelector('button[type="submit"]');

          // Select your password inputs (Matches standard name attributes)
          const passwordInput = document.querySelector('input[name="new_password"]');
          const confirmInput = document.querySelector('input[name="confirm_password"]');

          if (!passwordInput || !confirmInput) return; // Safety exit if fields don't exist

          // 1. Create and inject the Modern Checklist UI under the password field
          const checklistDiv = document.createElement('div');
          checklistDiv.className = 'mt-2 small';
          checklistDiv.style.padding = '10px';
          checklistDiv.style.backgroundColor = '#f8f9fa';
          checklistDiv.style.borderRadius = '8px';
          checklistDiv.style.border = '1px solid #e9ecef';

          checklistDiv.innerHTML = `
              <div id="reset-length" style="color: #6c757d; font-weight: 500;">❌ Min 8 characters</div>
              <div id="reset-upper" style="color: #6c757d; font-weight: 500;">❌ Uppercase & Lowercase letters</div>
              <div id="reset-number" style="color: #6c757d; font-weight: 500;">❌ At least 1 number</div>
              <div id="reset-special" style="color: #6c757d; font-weight: 500;">❌ Special character (@, #, $, etc.)</div>
              <div id="reset-match" style="color: #6c757d; font-weight: 500; margin-top: 5px; border-top: 1px solid #dee2e6; padding-top: 5px;">❌ Passwords match</div>
          `;

          // Inject the checklist box right below the first password field
          passwordInput.parentNode.insertBefore(checklistDiv, passwordInput.nextSibling);

          function checkPasswordRealTime() {
              const pass = passwordInput.value;
              const confirmPass = confirmInput.value;

              // Security Validation Flags
              const hasLength = pass.length >= 8;
              const hasUpperLower = /[A-Z]/.test(pass) && /[a-z]/.test(pass);
              const hasNumber = /[0-9]/.test(pass);
              const hasSpecial = /[^A-Za-z0-9]/.test(pass);
              const isMatching = pass === confirmPass && pass.length > 0;

              // Helper to update checklist symbols and colors dynamically
              const updateRule = (id, isValid) => {
                  const el = document.getElementById(id);
                  if (!el) return;
                  if (isValid) {
                      el.innerHTML = el.innerHTML.replace('❌', '✅');
                      el.style.color = '#198754'; // Modern Bootstrap Green
                  } else {
                      el.innerHTML = el.innerHTML.replace('✅', '❌');
                      el.style.color = '#6c757d'; // Default Gray
                  }
              };

              updateRule('reset-length', hasLength);
              updateRule('reset-upper', hasUpperLower);
              updateRule('reset-number', hasNumber);
              updateRule('reset-special', hasSpecial);
              updateRule('reset-match', isMatching);

              // Update borders dynamically based on input accuracy
              if (pass.length > 0) {
                  passwordInput.style.borderColor = (hasLength && hasUpperLower && hasNumber && hasSpecial) ? '#198754' : '#dc3545';
              } else {
                  passwordInput.style.borderColor = '';
              }

              if (confirmPass.length > 0) {
                  confirmInput.style.borderColor = isMatching ? '#198754' : '#dc3545';
              } else {
                  confirmInput.style.borderColor = '';
              }

              // Native button management: Disable until form requirements are met completely
              const allValid = hasLength && hasUpperLower && hasNumber && hasSpecial && isMatching;
              if (submitBtn) {
                  submitBtn.disabled = !allValid;
                  submitBtn.style.opacity = allValid ? "1" : "0.5";
                  submitBtn.style.cursor = allValid ? "pointer" : "not-allowed";
              }
          }

          // Attach immediate event handlers for real-time key capture
          passwordInput.addEventListener('input', checkPasswordRealTime);
          confirmInput.addEventListener('input', checkPasswordRealTime);

          // 2. Unbreakable button freeze on successful form dispatch
          if (form && submitBtn) {
              form.addEventListener('submit', function() {
                  setTimeout(function() {
                      submitBtn.innerText = "Updating Password...";
                      submitBtn.style.opacity = "0.5";
                      submitBtn.style.pointerEvents = "none";
                  }, 0);
              });
          }

          // Run evaluation loop on page instantiation to secure initial field states
          checkPasswordRealTime();
      });
    </script>
</body>
</html>
