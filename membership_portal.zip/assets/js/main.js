/**
 * Membership Portal.
 * Main JavaScript.
 *
 * Handles interactive features: password toggle, form validation,
 * dynamic UI updates, and other client‑side functionality.
 *
 * @package    MembershipPortal.
 * @author     Heshan Shibry <heshan.shib@gmail.com>
 * @copyright  2026 HESHAN SHIBRY.
 * @license    Proprietary - All rights reserved.
 * @version    1.0.0.
 */
/**
 * Membership Portal – Main JavaScript
 * Consolidated global functionality.
 * Load this script with `defer` in the `<head>` of every admin page.
 *
 * Convert UTC datetime strings (from MySQL) to user's local time.
 * Elements with data-utc-time attribute will have their content replaced.
 * Expected format: "2026-04-29 01:20:30" (UTC)
 */
(function() {
    // ===============================
    // 1. UTC to Local Time Conversion
    // ===============================
    document.addEventListener('DOMContentLoaded', function() {
        const timeElements = document.querySelectorAll('[data-utc-time]');
        timeElements.forEach(element => {
            let utcString = element.getAttribute('data-utc-time');
            if (utcString && utcString.trim() !== '') {
                let isoString = utcString.replace(' ', 'T') + 'Z';
                let date = new Date(isoString);
                if (!isNaN(date.getTime())) {
                    const localTimeString = date.toLocaleString(undefined, {
                        year: 'numeric',
                        month: 'short',
                        day: 'numeric',
                        hour: '2-digit',
                        minute: '2-digit',
                        second: '2-digit',
                        hour12: false
                    });
                    element.textContent = localTimeString;
                }
            }
        });
    });

    // ===============================
    // 2. Mobile Navbar: Close when clicking outside
    // ===============================
    document.addEventListener('click', function(event) {
        if (window.innerWidth < 992) {
            const navbar = document.getElementById('navbarNav');
            const toggler = document.querySelector('.navbar-toggler');
            if (navbar && toggler && navbar.classList.contains('show') && !navbar.contains(event.target) && !toggler.contains(event.target)) {
                const bsCollapse = bootstrap.Collapse.getInstance(navbar);
                if (bsCollapse) bsCollapse.hide();
            }
        }
    });

    // ===============================
    // 3. Phone number – only digits
    // ===============================
    const phoneInput = document.querySelector('input[name="phone_number"]');
    if (phoneInput) {
        phoneInput.addEventListener('input', function(e) {
            this.value = this.value.replace(/[^0-9]/g, '');
        });
    }

    // ===============================
    // 4. Email validation with live feedback (adds feedback div if missing)
    // ===============================
    const emailInput = document.querySelector('form input[name="email"]');
    if (emailInput) {
        let feedback = document.getElementById('emailFeedback');
        if (!feedback) {
            feedback = document.createElement('div');
            feedback.id = 'emailFeedback';
            feedback.className = 'invalid-feedback';
            emailInput.parentNode.appendChild(feedback);
        }
        emailInput.addEventListener('input', function() {
            const isValid = /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(this.value);
            if (!isValid && this.value.length > 0) {
                this.classList.add('is-invalid');
                feedback.textContent = 'Please enter a valid email address (e.g., name@example.com).';
            } else {
                this.classList.remove('is-invalid');
                feedback.textContent = '';
            }
        });
    }

    // ===============================
    // 5. Delete Member Modal
    // ===============================
    const deleteMemberModal = document.getElementById('deleteMemberModal');
    if (deleteMemberModal) {
        deleteMemberModal.addEventListener('show.bs.modal', function(event) {
            const button = event.relatedTarget;
            document.getElementById('delete_member_id').value = button.getAttribute('data-member-id');
            document.getElementById('delete_member_name').innerText = button.getAttribute('data-member-name');
            document.getElementById('delete_member_id_display').innerText = button.getAttribute('data-member-id-display');
        });
    }

    // ===============================
    // 6. Delete Admin Modal
    // ===============================
    const deleteAdminModal = document.getElementById('deleteAdminModal');
    if (deleteAdminModal) {
        deleteAdminModal.addEventListener('show.bs.modal', function(event) {
            const button = event.relatedTarget;
            document.getElementById('delete_admin_id').value = button.getAttribute('data-admin-id');
            document.getElementById('delete_admin_name').innerText = button.getAttribute('data-admin-name');
            document.getElementById('delete_admin_id_display').innerText = button.getAttribute('data-admin-id-display');
        });
    }

    // ===============================
    // 7. Role assignment logic (Manage Admins page)
    // ===============================
    const createAdminForm = document.getElementById('createAdminForm');
    if (createAdminForm) {
        const checkboxes = document.querySelectorAll('#createAdminForm .role-checkbox');
        const selectedRolesSpan = document.getElementById('selectedRolesText');
        const superAdminCheckbox = document.getElementById('is_super_admin');
        const superAdminHelp = document.getElementById('superAdminHelp');
        const dropdownBtn = document.getElementById('roleDropdownBtn'); // Reference the button
        const fullAccessCheckbox = Array.from(checkboxes).find(cb => cb.nextElementSibling && cb.nextElementSibling.innerText.trim() === 'full_access');

        // Prevent dropdown from closing when clicking inside it
        const dropdownMenu = document.querySelector('.role-dropdown-menu');
        if (dropdownMenu) {
            dropdownMenu.addEventListener('click', (e) => e.stopPropagation());
        }

        // FIX: If user clicks the checkbox/label while menu is closed, force it to expand
        function ensureExpanded(e) {
            if (dropdownBtn && !dropdownBtn.classList.contains('show')) {
                const bsDropdown = bootstrap.Dropdown.getOrCreateInstance(dropdownBtn);
                bsDropdown.show();
            }
        }

        function updateSelectedRolesText() {
            if (superAdminCheckbox && superAdminCheckbox.checked) {
                selectedRolesSpan.innerText = 'Roles ignored (Super Admin)';
                return;
            }
            const selected = [];
            checkboxes.forEach(cb => {
                if (cb.checked && !cb.disabled) {
                    const label = cb.nextElementSibling.innerText;
                    selected.push(label);
                }
            });
            if (selected.length === 0) selectedRolesSpan.innerText = 'Select roles...';
            else if (selected.length <= 2) selectedRolesSpan.innerText = selected.join(', ');
            else selectedRolesSpan.innerText = selected.length + ' roles selected';
        }

        function handleFullAccessExclusivity(changedCheckbox) {
            if (!fullAccessCheckbox) return;
            if (superAdminCheckbox && superAdminCheckbox.checked) return;
            if (changedCheckbox === fullAccessCheckbox) {
                if (fullAccessCheckbox.checked) {
                    checkboxes.forEach(cb => {
                        if (cb !== fullAccessCheckbox) {
                            cb.disabled = true;
                            cb.checked = false;
                        }
                    });
                } else {
                    checkboxes.forEach(cb => {
                        if (cb !== fullAccessCheckbox) {
                            cb.disabled = false;
                        }
                    });
                }
            } else {
                if (changedCheckbox && changedCheckbox.checked) {
                    fullAccessCheckbox.checked = false;
                    fullAccessCheckbox.disabled = true;
                } else {
                    const anyOtherChecked = Array.from(checkboxes).some(cb => cb !== fullAccessCheckbox && cb.checked);
                    if (!anyOtherChecked) fullAccessCheckbox.disabled = false;
                }
            }
            updateSelectedRolesText();
        }

        function toggleRoleCheckboxes() {
            const isSuper = superAdminCheckbox.checked;
            checkboxes.forEach(cb => {
                cb.disabled = isSuper;
                if (isSuper) cb.checked = false;
            });
            if (superAdminHelp) superAdminHelp.style.display = isSuper ? 'block' : 'none';
            updateSelectedRolesText();
            if (!isSuper) handleFullAccessExclusivity(null);
            else if (fullAccessCheckbox) fullAccessCheckbox.disabled = true;
        }

        if (superAdminCheckbox) {
            superAdminCheckbox.addEventListener('change', toggleRoleCheckboxes);
            toggleRoleCheckboxes();
        }

        checkboxes.forEach(cb => {
            // We add "click" to ensure the dropdown expands
            cb.addEventListener('click', ensureExpanded);
            cb.addEventListener('change', () => handleFullAccessExclusivity(cb));
            cb.addEventListener('change', updateSelectedRolesText);
        });

        handleFullAccessExclusivity(null);
        updateSelectedRolesText();
    }
    // ===============================
    // 8. Edit Roles Modal (Manage Admins)
    // ===============================
    const editRolesModal = document.getElementById('editRolesModal');
    if (editRolesModal) {
        let originalRoleIds = [];
        let hintElement = null;
        editRolesModal.addEventListener('show.bs.modal', function(event) {
            const button = event.relatedTarget;
            const adminId = button.getAttribute('data-admin-id');
            const adminName = button.getAttribute('data-admin-name');
            const roleIds = button.getAttribute('data-role-ids');
            const isSuper = button.getAttribute('data-is-super') === '1';
            document.getElementById('modal_admin_id').value = adminId;
            document.getElementById('modal_admin_name').innerText = adminName;
            originalRoleIds = roleIds ? roleIds.split(',') : [];
            const modalCheckboxes = editRolesModal.querySelectorAll('.modal-role-checkbox');
            modalCheckboxes.forEach(cb => cb.checked = false);
            if (originalRoleIds.length) {
                modalCheckboxes.forEach(cb => {
                    if (originalRoleIds.includes(cb.value)) cb.checked = true;
                });
            }
            const superModalCheckbox = document.getElementById('super_admin_modal_checkbox');
            if (superModalCheckbox) {
                superModalCheckbox.checked = isSuper;
                const changeEvent = new Event('change');
                superModalCheckbox.dispatchEvent(changeEvent);
            }
        });
        const superModalCheckbox = document.getElementById('super_admin_modal_checkbox');
        if (superModalCheckbox) {
            superModalCheckbox.addEventListener('change', function() {
                const isSuperChecked = this.checked;
                const roleCheckboxes = editRolesModal.querySelectorAll('.modal-role-checkbox');
                const container = document.getElementById('roles_checkboxes_container');
                if (isSuperChecked) {
                    roleCheckboxes.forEach(cb => {
                        cb.disabled = true;
                        cb.checked = false;
                        cb.closest('.col-md-6').style.opacity = '0.5';
                    });
                    if (!hintElement) {
                        hintElement = document.createElement('div');
                        hintElement.className = 'small text-muted mt-2 super-hint';
                        hintElement.innerHTML = '<i class="bi bi-info-circle"></i> Role selection is ignored for Super Admins.';
                        container.parentNode.insertBefore(hintElement, container.nextSibling);
                    } else {
                        hintElement.style.display = 'block';
                    }
                } else {
                    roleCheckboxes.forEach(cb => {
                        cb.disabled = false;
                        cb.closest('.col-md-6').style.opacity = '1';
                        cb.checked = originalRoleIds.includes(cb.value);
                    });
                    if (hintElement) hintElement.style.display = 'none';
                }
            });
        }
    }

    // ===============================
    // 9. Flatpickr initialisation (date pickers)
    // ===============================
    if (typeof flatpickr !== 'undefined') {
        const fromDate = document.getElementById('fromDate');
        const toDate = document.getElementById('toDate');
        if (fromDate && toDate) {
            flatpickr("#fromDate, #toDate", {
                dateFormat: "Y-m-d",
                allowInput: true,
                theme: "material_blue"
            });
        }
    }

    // ===============================
    // 10. Chart.js initialisation (Reports page)
    // ===============================
    const chartCanvas = document.getElementById('districtChart');
    if (chartCanvas && typeof Chart !== 'undefined') {
        // The chart data and labels are passed via PHP – this part must remain inline.
        // For simplicity, keep the inline chart initialisation on the reports page.
        // Here we only check that it exists; the actual initialisation will be done by an inline script
        // that can access PHP variables. We'll not duplicate that.
    }

    // ===============================
    // 11. Reports page – quick date buttons and CSV export
    // ===============================
    const reportForm = document.getElementById('reportForm');
    if (reportForm) {
        // Helper to format date as YYYY-MM-DD
        function formatDate(date) {
            let yyyy = date.getFullYear();
            let mm = String(date.getMonth() + 1).padStart(2, '0');
            let dd = String(date.getDate()).padStart(2, '0');
            return `${yyyy}-${mm}-${dd}`;
        }

        // Quick date buttons (data-days)
        document.querySelectorAll('.quick-date').forEach(btn => {
            btn.addEventListener('click', function() {
                let days = parseInt(this.getAttribute('data-days'));
                let to = new Date();
                let from = new Date();
                if (days === 0) from = to;
                else if (days > 0) from.setDate(to.getDate() - days);
                document.getElementById('fromDate').value = formatDate(from);
                document.getElementById('toDate').value = formatDate(to);
                reportForm.submit();
            });
        });

        // This Week button
        document.getElementById('thisWeekBtn')?.addEventListener('click', function() {
            let now = new Date();
            let day = now.getDay();
            let diff = day === 0 ? 6 : day - 1;
            let monday = new Date(now);
            monday.setDate(now.getDate() - diff);
            let sunday = new Date(monday);
            sunday.setDate(monday.getDate() + 6);
            document.getElementById('fromDate').value = formatDate(monday);
            document.getElementById('toDate').value = formatDate(sunday);
            reportForm.submit();
        });

        // This Month button
        document.getElementById('thisMonthBtn')?.addEventListener('click', function() {
            let now = new Date();
            let firstDay = new Date(now.getFullYear(), now.getMonth(), 1);
            let lastDay = new Date(now.getFullYear(), now.getMonth() + 1, 0);
            document.getElementById('fromDate').value = formatDate(firstDay);
            document.getElementById('toDate').value = formatDate(lastDay);
            reportForm.submit();
        });

        // This Year button
        document.getElementById('thisYearBtn')?.addEventListener('click', function() {
            let now = new Date();
            let firstDay = new Date(now.getFullYear(), 0, 1);
            let lastDay = new Date(now.getFullYear(), 11, 31);
            document.getElementById('fromDate').value = formatDate(firstDay);
            document.getElementById('toDate').value = formatDate(lastDay);
            reportForm.submit();
        });

        // CSV export for members (13 columns)
        const exportBtn = document.getElementById('exportCSVBtn');
        if (exportBtn) {
            exportBtn.addEventListener('click', function() {
                const table = document.getElementById('membersReportTable');
                if (!table) {
                    alert('Report table not found.');
                    return;
                }
                const rows = table.querySelectorAll('tbody tr');
                if (rows.length === 0 || (rows.length === 1 && rows[0].cells.length === 1 && rows[0].innerText.includes('No members'))) {
                    alert('No report data to export.');
                    return;
                }
                let csvRows = [];
                const escape = (str) => `"${String(str).replace(/"/g, '""')}"`;

                const headers = [
                    'ID', 'Member ID', 'Full Name', 'Email', 'Province', 'District', 'City/Town',
                    'Phone', 'Gender', 'Polling Division', 'GN Division', 'Assigned Booth', 'Registered (UTC)'
                ];
                csvRows.push(headers.map(escape).join(','));

                rows.forEach(row => {
                    const cells = row.querySelectorAll('td');
                    if (cells.length === 13) {
                        const rowData = Array.from(cells).map(cell => cell.innerText.trim());
                        csvRows.push(rowData.map(escape).join(','));
                    }
                });

                if (csvRows.length > 1) {
                    const blob = new Blob([csvRows.join('\n')], { type: 'text/csv;charset=utf-8;' });
                    const link = document.createElement('a');
                    const url = URL.createObjectURL(blob);
                    link.setAttribute('href', url);
                    link.setAttribute('download', 'members_report.csv');
                    document.body.appendChild(link);
                    link.click();
                    document.body.removeChild(link);
                    URL.revokeObjectURL(url);
                } else {
                    alert('No valid data rows found.');
                }
            });
        }

        // ===== NEW: Export Gender Stats (uses global window.genderData) =====
        const exportGenderBtn = document.getElementById('exportGenderBtn');
        if (exportGenderBtn && window.genderData) {
            exportGenderBtn.addEventListener('click', function() {
                const genderRows = window.genderData;
                if (!genderRows || !genderRows.length) {
                    alert('No gender data to export.');
                    return;
                }
                let csvContent = "Gender,Count\n";
                genderRows.forEach(row => {
                    csvContent += `"${row.gender_label}",${row.count}\n`;
                });
                const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
                const link = document.createElement('a');
                const url = URL.createObjectURL(blob);
                link.setAttribute('href', url);
                link.setAttribute('download', 'gender_count.csv');
                document.body.appendChild(link);
                link.click();
                document.body.removeChild(link);
                URL.revokeObjectURL(url);
            });
        }
    }

    // ===============================
    // 12. Deleted Reports page – CSV export (with gender)
    // ===============================
    const exportCSVBtnDeleted = document.getElementById('exportDeletedCSVBtn');
    if (exportCSVBtnDeleted) {
        exportCSVBtnDeleted.addEventListener('click', function() {
            let csvRows = [];
            const escape = (str) => `"${String(str).replace(/"/g, '""')}"`;
            let hasData = false;

            // ---- Deleted Members table (7 columns) ----
            const membersTable = document.getElementById('deletedMembersTable');
            if (membersTable) {
                const rows = membersTable.querySelectorAll('tbody tr');
                let hasMemberData = false;
                rows.forEach(row => {
                    const cells = row.querySelectorAll('td');
                    if (cells.length === 7 && !row.innerText.includes('No deleted members')) {
                        hasMemberData = true;
                    }
                });
                if (hasMemberData) {
                    hasData = true;
                    csvRows.push(['=== DELETED MEMBERS ===']);
                    csvRows.push(['Member ID', 'Name', 'Email', 'Gender', 'Deleted At', 'Deleted By', 'Reason']);
                    rows.forEach(row => {
                        const cells = row.querySelectorAll('td');
                        if (cells.length === 7 && !row.innerText.includes('No deleted members')) {
                            csvRows.push([
                                cells[0].innerText.trim(),
                                cells[1].innerText.trim(),
                                cells[2].innerText.trim(),
                                cells[3].innerText.trim(),
                                cells[4].innerText.trim(),
                                cells[5].innerText.trim(),
                                cells[6].innerText.trim()
                            ].map(escape).join(','));
                        }
                    });
                    csvRows.push([]);
                }
            }

            // ---- Deleted Admins table (7 columns) ----
            const adminsTable = document.getElementById('deletedAdminsTable');
            if (adminsTable) {
                const rows = adminsTable.querySelectorAll('tbody tr');
                let hasAdminData = false;
                rows.forEach(row => {
                    const cells = row.querySelectorAll('td');
                    if (cells.length === 7 && !row.innerText.includes('No deleted admins')) {
                        hasAdminData = true;
                    }
                });
                if (hasAdminData) {
                    hasData = true;
                    csvRows.push(['=== DELETED ADMINS ===']);
                    csvRows.push(['Admin ID', 'Name', 'Email', 'Gender', 'Deleted At', 'Deleted By', 'Reason']);
                    rows.forEach(row => {
                        const cells = row.querySelectorAll('td');
                        if (cells.length === 7 && !row.innerText.includes('No deleted admins')) {
                            csvRows.push([
                                cells[0].innerText.trim(),
                                cells[1].innerText.trim(),
                                cells[2].innerText.trim(),
                                cells[3].innerText.trim(),
                                cells[4].innerText.trim(),
                                cells[5].innerText.trim(),
                                cells[6].innerText.trim()
                            ].map(escape).join(','));
                        }
                    });
                    csvRows.push([]);
                }
            }

            // ---- Restore Log table (8 columns) ----
            const restoreTable = document.getElementById('restoreLogTable');
            if (restoreTable) {
                const rows = restoreTable.querySelectorAll('tbody tr');
                let hasRestoreData = false;
                rows.forEach(row => {
                    const cells = row.querySelectorAll('td');
                    if (cells.length === 8 && !row.innerText.includes('No restore logs')) {
                        hasRestoreData = true;
                    }
                });
                if (hasRestoreData) {
                    hasData = true;
                    csvRows.push(['=== RESTORE LOG ===']);
                    csvRows.push(['Type', 'Name', 'Identifier', 'Gender', 'Restored By', 'Restored At', 'Deleted At', 'Deletion Reason']);
                    rows.forEach(row => {
                        const cells = row.querySelectorAll('td');
                        if (cells.length === 8 && !row.innerText.includes('No restore logs')) {
                            csvRows.push([
                                cells[0].innerText.trim(),
                                cells[1].innerText.trim(),
                                cells[2].innerText.trim(),
                                cells[3].innerText.trim(),
                                cells[4].innerText.trim(),
                                cells[5].innerText.trim(),
                                cells[6].innerText.trim(),
                                cells[7].innerText.trim()
                            ].map(escape).join(','));
                        }
                    });
                    // No extra empty row after restore log
                }
            }

            if (!hasData) {
                alert('No deleted report data to export.');
                return;
            }

            const blob = new Blob([csvRows.join('\n')], { type: 'text/csv;charset=utf-8;' });
            const link = document.createElement('a');
            const url = URL.createObjectURL(blob);
            link.setAttribute('href', url);
            link.setAttribute('download', 'deleted_records.csv');
            document.body.appendChild(link);
            link.click();
            document.body.removeChild(link);
            URL.revokeObjectURL(url);
        });
    }

    // ===============================
    // Admin profile – file size validation for profile picture
    // ===============================
    (function() {
        const profilePicInput = document.querySelector('input[name="profile_pic"]');
        if (!profilePicInput) return; // exit if not on profile page

        // Get or create error container (outside the flex column)
        function getErrorContainer() {
            let errorSpan = document.querySelector('.profile-pic-error');
            if (!errorSpan) {
                errorSpan = document.createElement('div');
                errorSpan.className = 'profile-pic-error text-danger small mt-2';
                errorSpan.style.textAlign = 'center'; // center the error text
                // Insert after the upload-hint div
                const hintDiv = document.querySelector('.upload-hint');
                if (hintDiv) {
                    hintDiv.parentNode.insertBefore(errorSpan, hintDiv.nextSibling);
                } else {
                    // Fallback: append to parent of profilePicInput
                    profilePicInput.parentNode.appendChild(errorSpan);
                }
            }
            return errorSpan;
        }

        function showError(message) {
            const errorSpan = getErrorContainer();
            errorSpan.innerText = message;
        }

        function clearError() {
            const errorSpan = document.querySelector('.profile-pic-error');
            if (errorSpan) errorSpan.innerText = '';
        }

        profilePicInput.addEventListener('change', function() {
            const file = this.files[0];
            clearError();
            if (file) {
                const maxBytes = 2 * 1024 * 1024; // 2MB
                if (file.size > maxBytes) {
                    showError(`Profile picture must be less than 2MB. Selected file is ${(file.size / 1024 / 1024).toFixed(2)}MB.`);
                    this.value = ''; // clear the selection – prevents auto‑submit
                    return;
                }
            }
            // If file is valid, the existing auto‑submit code will run
        });
    })();

    // ===============================
    // 13. Profile page – profile picture upload click & password toggle
    // ===============================
    const profileImgDiv = document.querySelector('.profile-img');
    const fileInput = document.getElementById('fileInput');
    if (profileImgDiv && fileInput) {
        profileImgDiv.addEventListener('click', () => fileInput.click());
        fileInput.addEventListener('change', function() {
            if (this.files.length > 0) document.getElementById('uploadForm').submit();
        });
    }

    const showPassword1 = document.getElementById('showPasswordCheckbox1');
    const newPassword = document.getElementById('NewPassword');
    if (showPassword1 && newPassword) {
        showPassword1.addEventListener('change', () => newPassword.type = showPassword1.checked ? 'text' : 'password');
    }
    const showPassword2 = document.getElementById('showPasswordCheckbox2');
    const confirmPassword = document.getElementById('ConfirmNewPassword');
    if (showPassword2 && confirmPassword) {
        showPassword2.addEventListener('change', () => confirmPassword.type = showPassword2.checked ? 'text' : 'password');
    }

    // ===============================
    // 14. Edit Permissions Modal (manage_permissions page)
    // ===============================
    const editPermModal = document.getElementById('editPermModal');
    if (editPermModal) {
        editPermModal.addEventListener('show.bs.modal', function(event) {
            const button = event.relatedTarget;
            document.getElementById('edit_id').value = button.getAttribute('data-id');
            document.getElementById('edit_name').value = button.getAttribute('data-name');
            document.getElementById('edit_display').value = button.getAttribute('data-display');
            document.getElementById('edit_desc').value = button.getAttribute('data-desc');
        });
    }

    // ===============================
    // Helper: format YYYY-MM-DD
    // ===============================
    function formatDate(date) {
        let d = new Date(date);
        let month = '' + (d.getMonth() + 1);
        let day = '' + d.getDate();
        let year = d.getFullYear();
        if (month.length < 2) month = '0' + month;
        if (day.length < 2) day = '0' + day;
        return [year, month, day].join('-');
    }
})();

      /**
      * Gender toggle – shows/hides the custom "Other" text field
      * and sets the `required` attribute on the custom input.
      *
      * Works on any page that has:
      * - <select id="genderSelect"> with options: Male, Female, Prefer not to say, Other
      * - <div id="genderSpecifyWrapper"> containing the custom text <input>
      * - <input id="genderSpecifyInput">
      *
      * When "Other" is selected: wrapper becomes visible and the input is required.
      * For any other selection: wrapper hidden, input cleared, required removed.
      */
     function toggleGenderSpecifyField() {
     const genderSelect = document.getElementById('genderSelect');
     const genderWrapper = document.getElementById('genderSpecifyWrapper');
     const genderInput = document.getElementById('genderSpecifyInput');

     if (genderSelect && genderSelect.value === 'Other') {
         if (genderWrapper) genderWrapper.style.display = 'block';
         if (genderInput) genderInput.required = true;   // custom text required
     } else {
         if (genderWrapper) genderWrapper.style.display = 'none';
         if (genderInput) {
             genderInput.value = '';
             genderInput.required = false;
         }
     }
 }

 // Initialise on page load
 if (document.readyState === 'loading') {
     document.addEventListener('DOMContentLoaded', function() {
         toggleGenderSpecifyField();
     });
 } else {
     toggleGenderSpecifyField();
 }

 // Listen for changes (delegated, works for dynamically added selects)
 document.addEventListener('change', function(e) {
     if (e.target && e.target.id === 'genderSelect') {
         toggleGenderSpecifyField();
     }
 });
