<?php
/**
 * Membership Portal.
 * - Setup Wizard – Creates the first (primary) super admin account.
 * - This page is only accessible when no admin exists in the database.
 * - The primary admin gets is_super_admin = 1 and full permissions.
 *
 * @package    MembershipPortal.
 * @author     Heshan Shibry <heshan.shib@gmail.com>
 * @copyright  2026 HESHAN SHIBRY.
 * @license    Proprietary - All rights reserved.
 * @version    1.0.0.
 */
session_start();
require_once 'includes/functions.php';
$pdo = getDB();
$baseUrl = BASE_URL;

// If any admin already exists, redirect to admin login
if (hasAdmin($pdo)) {
    header('Location: ' . BASE_URL . 'admin');
    exit;
}

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $full_name = sanitize($_POST['full_name']);
    $email = sanitize($_POST['email']);
    $password = $_POST['new_password'];
    $confirm = $_POST['confirm_password'];

    // Default values for removed fields (district is NOT NULL, so provide a default)
    $district = 'Not Specified';
    $phone = null;
    $address = null;

    // ----- GENDER HANDLING -----
    $gender = sanitize($_POST['gender'] ?? '');
    $gender_custom = sanitize($_POST['gender_custom'] ?? '');

    $allowedGenders = ['Male', 'Female', 'Prefer not to say', 'Other'];
    if (!in_array($gender, $allowedGenders)) {
        $gender = null;
    }

    if ($gender !== 'Other') {
        $gender_custom = null;
    } else {
        $gender_custom = trim($gender_custom);
        if (strlen($gender_custom) > 50) {
            $gender_custom = substr($gender_custom, 0, 50);
        }
        if (empty($gender_custom)) {
            $error = "Please specify your gender when selecting 'Other'.";
        }
    }
    // ---------------------------

    if (empty($error)) { // only proceed if no previous error
        if ($password !== $confirm) {
            $error = "Passwords do not match.";
        } elseif (empty($gender)) {
            $error = "Please select a gender.";
        } elseif (!isStrongPassword($password)) {
            $error = "Password must be at least 8 characters and include at least one uppercase letter, one lowercase letter, one digit, and one special character (e.g., @, #, $, %).";
        } else {
            // Check if email already exists
            $stmt = $pdo->prepare("SELECT id FROM admins WHERE email = ?");
            $stmt->execute([$email]);
            if ($stmt->fetch()) {
                $error = "Email already exists. Please use a different email.";
            } else {
                $admin_id = generateAdminId($pdo);
                $hashed = password_hash($password, PASSWORD_DEFAULT);
                $permissions = json_encode(['all']);
                $createdAt = utcNow(); // UTC timestamp

                $stmt = $pdo->prepare("INSERT INTO admins (admin_id, full_name, email, password, district, phone, address, role, permissions, is_super_admin, force_password_change, created_at, gender, gender_custom) VALUES (?, ?, ?, ?, ?, ?, ?, 'primary', ?, 1, 0, ?, ?, ?)");
                if ($stmt->execute([$admin_id, $full_name, $email, $hashed, $district, $phone, $address, $permissions, $createdAt, $gender, $gender_custom])) {
                    // === FIX: Destroy session to prevent timeout message on login ===
                    session_unset();     // Clear all session variables
                    session_destroy();   // Destroy the session file

                    // Also delete the session cookie from the browser
                    if (isset($_COOKIE[session_name()])) {
                        setcookie(session_name(), '', time() - 3600, '/');
                    }

                    // Redirect with only the success parameter
                    header('Location: ' . $baseUrl . 'admin?setup=success');
                    exit;
                } else {
                    $error = "Failed to create admin account. Please try again.";
                }
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en" class="h-100">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Installation - Create Admin Account | National Movement</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="assets/css/style.css">
    <style>
        body { display: flex; flex-direction: column; min-height: 100vh; }
        main { flex: 1 0 auto; }
        footer { flex-shrink: 0; }
        .form-check {
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }
        .form-check-input {
            margin: 0;
            cursor: pointer;
        }
        select.form-select {
            cursor: pointer;
        }
        #genderSpecifyWrapper {
            display: none;
        }
    </style>
</head>
<body class="bg-light d-flex flex-column min-vh-100">

    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <div class="container justify-content-center">
            <h4 class="text-white fw-bold mx-auto text-center">🏛️ NATIONAL BUILDER . INSTALLATION</h4>
        </div>
    </nav>

    <main class="container my-5">
        <div class="row justify-content-center">
            <div class="col-md-6 col-lg-5">
                <div class="card shadow-sm border-0 rounded-4">
                    <div class="card-body p-4 p-md-5">
                        <h2 class="card-title text-center mb-3">🚀 Welcome!</h2>
                        <p class="text-center text-muted mb-4">Create the first administrator account to start managing the portal.</p>
                        <?php if ($error): ?>
                              <div class="alert alert-danger d-flex align-items-center border-0 border-start border-4 border-danger shadow-sm mb-4" role="alert">
                                  <!-- Modern Bootstrap SVG Exclamation Warning Icon -->
                                  <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="currentColor" class="bi bi-exclamation-triangle-fill me-3 flex-shrink-0" viewBox="0 0 16 16">
                                      <path d="M8.982 1.566a1.13 1.13 0 0 0-1.96 0L.165 13.233c-.457.778.091 1.767.98 1.767h13.713c.889 0 1.438-.99.98-1.767zM8 5c.535 0 .954.462.9.995l-.35 3.507a.552.552 0 0 1-1.1 0L7.1 5.995A.905.905 0 0 1 8 5m.002 6a1 1 0 1 1 0 2 1 1 0 0 1 0-2"/>
                                  </svg>
                                  <div class="small fw-semibold"><?= $error ?></div>
                              </div>
                          <?php endif; ?>
                        <form method="POST" id="setup">
                            <div class="mb-3">
                                <label class="form-label fw-semibold">Full Name *</label>
                                <input type="text" name="full_name" class="form-control" required>
                            </div>
                            <div class="mb-3">
                                <label class="form-label fw-semibold">Email *</label>
                                <input type="email" name="email" class="form-control" required>
                            </div>

                            <!-- Gender Field (required) -->
                            <div class="mb-3">
                                <label class="form-label fw-semibold">Gender *</label>
                                <select id="genderSelect" name="gender" class="form-select" required>
                                    <option value="" selected>Select...</option>
                                    <option value="Male">Male</option>
                                    <option value="Female">Female</option>
                                    <option value="Prefer not to say">Prefer not to say</option>
                                    <option value="Other">Other</option>
                                </select>
                            </div>
                            <div class="mb-3" id="genderSpecifyWrapper">
                                <label class="form-label fw-semibold">Please specify *</label>
                                <input type="text" id="genderSpecifyInput" name="gender_custom" class="form-control" placeholder="e.g., Non-binary">
                            </div>

                            <div class="mb-3">
                                <p class="text-muted small mb-3 text-center">
                                    🔒 <strong>Password Requirements:</strong> Minimum 8 characters, a mix of UPPER and lower case, at least one digit, and a symbol (like @, #, $, %).
                                </p>
                                <label class="form-label fw-semibold">New Password *</label>
                                <!-- Hidden dummy fields to prevent autofill -->
                                <input type="password" name="new_password" style="display:none">
                                <input type="password" name="new_password" id="newPassword" class="form-control" autocomplete="off" required>
                                <div class="form-check mt-2">
                                    <input class="form-check-input" type="checkbox" id="showPasswordCheckbox1">
                                    <label class="form-check-label" for="showPasswordCheckbox1">
                                        Show password
                                    </label>
                                </div>
                            </div>
                            <div class="mb-3">
                                <label class="form-label fw-semibold">Confirm New Password *</label>
                                <input type="password" name="confirm_password" style="display:none">
                                <input type="password" name="confirm_password" id="confirmnewPassword" class="form-control" autocomplete="off" required>
                                <div class="form-check mt-2">
                                    <input class="form-check-input" type="checkbox" id="showPasswordCheckbox2">
                                    <label class="form-check-label" for="showPasswordCheckbox2">
                                        Show password
                                    </label>
                                </div>
                            </div>
                            <button type="submit" class="btn btn-dark w-100 py-2">Create Admin Account</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </main>

    <footer class="bg-dark text-white-50 text-center py-4 mt-auto">
        <p class="mb-0">National Movement Admin – Installation Wizard</p>
        <p class="mb-0 mt-2 small">&copy; <?= date('Y') ?> National Movement. All rights reserved.</p>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Gender toggle: show/hide custom text field when "Other" is selected
        (function() {
            const genderSelect = document.getElementById('genderSelect');
            const genderWrapper = document.getElementById('genderSpecifyWrapper');
            const genderInput = document.getElementById('genderSpecifyInput');

            function toggleGenderSpecifyField() {
                if (genderSelect.value === 'Other') {
                    genderWrapper.style.display = 'block';
                    if (genderInput) genderInput.required = true;
                } else {
                    genderWrapper.style.display = 'none';
                    if (genderInput) {
                        genderInput.value = '';
                        genderInput.required = false;
                    }
                }
            }

            if (genderSelect) {
                genderSelect.addEventListener('change', toggleGenderSpecifyField);
                toggleGenderSpecifyField();
            }
        })();

        // Show/hide password for New Password field
        document.getElementById('showPasswordCheckbox1').addEventListener('change', function() {
            const pwd = document.getElementById('newPassword');
            pwd.type = this.checked ? 'text' : 'password';
        });
        document.getElementById('showPasswordCheckbox2').addEventListener('change', function() {
            const pwd = document.getElementById('confirmnewPassword');
            pwd.type = this.checked ? 'text' : 'password';
        });

        // Email validation for create admin form
        const createEmailInput = document.querySelector('#setup input[name="email"]');
        if (createEmailInput) {
            const emailFeedback = document.createElement('div');
            emailFeedback.className = 'invalid-feedback';
            createEmailInput.parentNode.appendChild(emailFeedback);
            createEmailInput.addEventListener('input', function() {
                const email = this.value;
                const isValid = /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
                if (!isValid && email.length > 0) {
                    this.classList.add('is-invalid');
                    emailFeedback.textContent = 'Please enter a valid email address (e.g., name@example.com).';
                } else {
                    this.classList.remove('is-invalid');
                    emailFeedback.textContent = '';
                }
            });
        }

        /*
         * MODERN REAL-TIME PASSWORD VALIDATOR
         * Real-time checks for criteria match, length, and formatting.
         */
        document.addEventListener('DOMContentLoaded', function() {
            const form = document.getElementById('setup');
            const submitBtn = document.querySelector('button[type="submit"]');
            const passwordInput = document.getElementById('newPassword');
            const confirmInput = document.getElementById('confirmnewPassword');

            // 1. Create and inject the Modern Checklist UI under the password field
            const checklistDiv = document.createElement('div');
            checklistDiv.className = 'mt-2 small';
            checklistDiv.style.padding = '10px';
            checklistDiv.style.backgroundColor = '#f8f9fa';
            checklistDiv.style.borderRadius = '8px';
            checklistDiv.style.border = '1px solid #e9ecef';

            checklistDiv.innerHTML = `
                <div id="check-length" style="color: #6c757d; font-weight: 500;">❌ Min 8 characters</div>
                <div id="check-upper" style="color: #6c757d; font-weight: 500;">❌ Uppercase & Lowercase letters</div>
                <div id="check-number" style="color: #6c757d; font-weight: 500;">❌ At least 1 number</div>
                <div id="check-special" style="color: #6c757d; font-weight: 500;">❌ Special character (@, #, $, etc.)</div>
                <div id="check-match" style="color: #6c757d; font-weight: 500; margin-top: 5px; border-top: 1px solid #dee2e6; padding-top: 5px;">❌ Passwords match</div>
            `;

            // Inject the list right above your show password checkbox
            passwordInput.parentNode.insertBefore(checklistDiv, passwordInput.nextSibling.nextSibling);

            function checkPasswordRealTime() {
                const pass = passwordInput.value;
                const confirmPass = confirmInput.value;

                // Validation Flags
                const hasLength = pass.length >= 8;
                const hasUpperLower = /[A-Z]/.test(pass) && /[a-z]/.test(pass);
                const hasNumber = /[0-9]/.test(pass);
                const hasSpecial = /[^A-Za-z0-9]/.test(pass);
                const isMatching = pass === confirmPass && pass.length > 0;

                // Helper to update checklist visuals dynamically
                const updateRule = (id, isValid) => {
                    const el = document.getElementById(id);
                    if (isValid) {
                        el.innerHTML = el.innerHTML.replace('❌', '✅');
                        el.style.color = '#198754'; // Modern Bootstrap Green
                    } else {
                        el.innerHTML = el.innerHTML.replace('✅', '❌');
                        el.style.color = '#6c757d'; // Reset to gray
                    }
                };

                updateRule('check-length', hasLength);
                updateRule('check-upper', hasUpperLower);
                updateRule('check-number', hasNumber);
                updateRule('check-special', hasSpecial);
                updateRule('check-match', isMatching);

                // Update borders dynamically based on status
                if (pass.length > 0) {
                    passwordInput.style.borderColor = (hasLength && hasUpperLower && hasNumber && hasSpecial) ? '#198754' : '#dc3545';
                } else {
                    passwordInput.style.borderColor = '';
                }

                if (confirmPass.length > 0) {
                    confirmInput.style.borderColor = isMatching ? '#198754' : '#dc3545';
                } else {
                    confirmInput.style.borderColor = '';
                }

                // Disable button natively until everything matches completely
                const allValid = hasLength && hasUpperLower && hasNumber && hasSpecial && isMatching;
                submitBtn.disabled = !allValid;
                submitBtn.style.opacity = allValid ? "1" : "0.5";
                submitBtn.style.cursor = allValid ? "pointer" : "not-allowed";
            }

            // Attach immediate real-time listening loops
            passwordInput.addEventListener('input', checkPasswordRealTime);
            confirmInput.addEventListener('input', checkPasswordRealTime);

            // 2. Form submission trigger logic
            if (form && submitBtn) {
                form.addEventListener('submit', function() {
                    setTimeout(function() {
                        submitBtn.innerText = "Creating Account...";
                        submitBtn.style.opacity = "0.5";
                        submitBtn.style.pointerEvents = "none";
                    }, 0);
                });
            }

            // Run once on load to ensure button is locked appropriately
            checkPasswordRealTime();
        });
    </script>
</body>
</html>
