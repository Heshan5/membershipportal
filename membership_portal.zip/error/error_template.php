<?php
/**
 * Membership Portal.
 * - error/error_template.php – common error page layout.
 *
 * @package    MembershipPortal.
 * @author     Heshan Shibry <heshan.shib@gmail.com>
 * @copyright  2026 HESHAN SHIBRY.
 * @license    Proprietary - All rights reserved.
 * @version    1.0.0.
 */

// Dynamically detect the base URL (works in root or subfolder)
$protocol = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http';
$host = $_SERVER['HTTP_HOST'];
$scriptDir = rtrim(dirname($_SERVER['SCRIPT_NAME']), '/');
// SCRIPT_NAME is e.g. /error/404.php or /subfolder/error/404.php
$basePath = str_replace('/error', '', $scriptDir);
$BASE_URL = rtrim($protocol . '://' . $host . $basePath, '/') . '/';

$error_code = isset($error_code) ? $error_code : 500;
$error_title = isset($error_title) ? $error_title : 'Server Error';
$error_message = isset($error_message) ? $error_message : 'Something went wrong. Please try again later.';
?>
<!DOCTYPE html>
<html lang="en" class="h-100">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= $error_code ?> – <?= $error_title ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../assets/css/style.css">
    <style>
        body { display: flex; flex-direction: column; min-height: 100vh; }
        main { flex: 1 0 auto; }
        footer { flex-shrink: 0; }
        .error-box {
            background: white;
            border-radius: 28px;
            box-shadow: 0 12px 28px rgba(0,0,0,0.08);
            padding: 2rem;
            text-align: center;
        }
        .error-code {
            font-size: 6rem;
            font-weight: 700;
            color: #0a2f44;
        }
    </style>
</head>
<body class="bg-light d-flex flex-column min-vh-100">

    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <div class="container">
            <a class="navbar-brand fw-bold" href="<?= $BASE_URL ?>">NATIONAL BUILDER · MOVEMENT</a>
        </div>
    </nav>

    <main class="container my-5">
        <div class="row justify-content-center">
            <div class="col-md-6">
                <div class="error-box">
                    <div class="error-code"><?= $error_code ?></div>
                    <h2 class="mt-3"><?= $error_title ?></h2>
                    <p class="text-muted"><?= $error_message ?></p>
                    <a href="<?= $BASE_URL ?>" class="btn btn-dark mt-3">Return Home</a>
                </div>
            </div>
        </div>
    </main>

    <footer class="bg-dark text-white-50 text-center py-4 mt-auto">
        <p class="mb-0">National Movement – Secure Cloud Platform</p>
        <p class="mb-0 mt-2 small">&copy; <?= date('Y') ?> National Movement. All rights reserved.</p>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>