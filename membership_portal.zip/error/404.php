<?php
/**
 * Membership Portal.
 * 404 Not Found Error Page.
 *
 * @package    MembershipPortal.
 * @author     Heshan Shibry <heshan.shib@gmail.com>
 * @copyright  2026 HESHAN SHIBRY.
 * @license    Proprietary - All rights reserved.
 * @version    1.0.0.
 */
$error_code = 404;
$error_title = 'Page Not Found';
$error_message = 'The page you are looking for does not exist or has been moved.';
include 'error_template.php';
?>