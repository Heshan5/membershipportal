<?php
/**
 * Membership Portal.
 * 500 Internal Server Error Page.
 *
 * @package    MembershipPortal.
 * @author     Heshan Shibry <heshan.shib@gmail.com>
 * @copyright  2026 HESHAN SHIBRY.
 * @license    Proprietary - All rights reserved.
 * @version    1.0.0.
 */
$error_code = 500;
$error_title = 'Internal Server Error';
$error_message = 'Something went wrong on our end. Please try again later.';
include 'error_template.php';
?>