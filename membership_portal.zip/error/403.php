<?php
/**
 * Membership Portal.
 * 403 Forbidden Error Page.
 *
 * @package    MembershipPortal.
 * @author     Heshan Shibry <heshan.shib@gmail.com>
 * @copyright  2026 HESHAN SHIBRY.
 * @license    Proprietary - All rights reserved.
 * @version    1.0.0.
 */
$error_code = 403;
$error_title = 'Access Forbidden';
$error_message = 'You do not have permission to access this page.';
include 'error_template.php';
?>