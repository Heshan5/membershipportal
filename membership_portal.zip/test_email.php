<?php
/**
 * Membership Portal.
 * Test Email Script (Development Only).
 *
 * Sends a test email using the Brevo API to verify email configuration.
 * Access should be restricted or removed in production.
 *
 * @package    MembershipPortal.
 * @author     Heshan Shibry <heshan.shib@gmail.com>
 * @copyright  2026 HESHAN SHIBRY.
 * @license    Proprietary - All rights reserved.
 * @version    1.0.0.
 */
$secret = 'your_hard_to_guess_token';
if (!isset($_GET['key']) || $_GET['key'] !== $secret) {
    die('Access denied');
}

session_start();
require_once 'includes/functions.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $testEmail = sanitize($_POST['test_email']);
    $result = sendEmail($testEmail, 'Test Email from Your Portal', 'This is a test email to confirm Brevo is working correctly on your system.');

    if ($result['success']) {
        $message = "Test email sent successfully to $testEmail!";
        $messageType = 'success';
    } else {
        $message = "Failed to send test email. Check your API key and sender configuration.";
        $messageType = 'danger';
    }
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Test Brevo Email</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light d-flex flex-column min-vh-100">
    <div class="container mt-5">
        <div class="row justify-content-center">
            <div class="col-md-6">
                <div class="card shadow">
                    <div class="card-header bg-dark text-white">
                        <h4>Test Brevo Email Configuration</h4>
                    </div>
                    <div class="card-body">
                        <?php if (isset($message)): ?>
                            <div class="alert alert-<?= $messageType ?>"><?= $message ?></div>
                        <?php endif; ?>
                        <form method="POST">
                            <div class="mb-3">
                                <label class="form-label">Enter your email address to receive a test email</label>
                                <input type="email" name="test_email" class="form-control" required>
                            </div>
                            <button type="submit" class="btn btn-dark w-100">Send Test Email</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>
</html>
